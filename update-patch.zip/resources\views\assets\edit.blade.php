@extends('layouts.app')

@section('title', 'แก้ไขครุภัณฑ์ ' . $asset->asset_code)
@section('page-title', 'แก้ไขข้อมูลครุภัณฑ์ IT')
@section('breadcrumb', 'ระบบพัสดุและคลัง / ทะเบียนครุภัณฑ์ IT / แก้ไขข้อมูล ' . $asset->asset_code)

@section('topbar-actions')
<a href="{{ route('assets.show', $asset) }}" class="topbar-btn" title="กลับไปหน้ารายละเอียด">
    <i class="bi bi-arrow-left"></i>
    <span>กลับหน้ารายละเอียด</span>
</a>
@endsection

@push('styles')
<style>
    .btn-prefix-pill {
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11.5px;
        font-weight: 600;
        cursor: pointer;
        background: #f1f5f9;
        color: #475569;
        border: 1px solid #cbd5e1;
        transition: all 0.2s ease;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        user-select: none;
    }
    .btn-prefix-pill.active {
        background: #0d9488;
        color: #ffffff;
        border-color: #0f766e;
        box-shadow: 0 2px 6px rgba(13, 148, 136, 0.3);
    }
    .btn-prefix-pill:hover:not(.active) {
        background: #e2e8f0;
        color: #0f172a;
    }

    .form-section-card {
        background: #ffffff;
        border-radius: 14px;
        border: 1px solid var(--border);
        box-shadow: 0 2px 8px rgba(0,0,0,0.02);
        margin-bottom: 22px;
        overflow: hidden;
        transition: all 0.2s ease;
    }

    .form-section-card:hover {
        box-shadow: 0 4px 16px rgba(0,0,0,0.04);
        border-color: #cbd5e1;
    }

    .form-section-header {
        padding: 16px 22px;
        background: linear-gradient(to right, #f8fafc, #f1f5f9);
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 10px;
    }

    .form-section-title {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 15px;
        font-weight: 700;
        color: #0f172a;
    }

    .form-section-icon {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    .form-section-body {
        padding: 22px;
    }

    /* Type Selector Chips */
    .type-pill-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 13px;
        border-radius: 999px;
        border: 1px solid #cbd5e1;
        background: #ffffff;
        font-size: 12.5px;
        font-weight: 500;
        color: #334155;
        cursor: pointer;
        transition: all 0.18s ease;
        user-select: none;
    }

    .type-pill-btn:hover {
        background: #f1f5f9;
        border-color: #94a3b8;
        transform: translateY(-1px);
    }

    .type-pill-btn.active {
        background: #0d9488;
        border-color: #0d9488;
        color: #ffffff;
        font-weight: 600;
        box-shadow: 0 2px 8px rgba(13, 148, 136, 0.25);
    }

    /* Status Radio Cards */
    .status-card-group {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(135px, 1fr));
        gap: 10px;
    }

    .status-radio-card {
        border: 2px solid #e2e8f0;
        border-radius: 10px;
        padding: 10px 12px;
        text-align: center;
        cursor: pointer;
        transition: all 0.2s ease;
        background: #ffffff;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
    }

    .status-radio-card:hover {
        border-color: #cbd5e1;
        background: #f8fafc;
    }

    .status-radio-card input {
        display: none;
    }

    .status-radio-card.active-status {
        border-color: #0d9488;
        background: #f0fdfa;
        box-shadow: 0 2px 10px rgba(13, 148, 136, 0.15);
    }

    .status-radio-card.active-status.status-spare {
        border-color: #0284c7;
        background: #f0f9ff;
    }

    .status-radio-card.active-status.status-repairing {
        border-color: #f59e0b;
        background: #fffbeb;
    }

    .status-radio-card.active-status.status-broken {
        border-color: #ef4444;
        background: #fef2f2;
    }

    .status-radio-card.active-status.status-disposed {
        border-color: #64748b;
        background: #f1f5f9;
    }

    /* Quick Preset Buttons */
    .quick-tag {
        font-size: 11px;
        padding: 2px 8px;
        border-radius: 4px;
        background: #f1f5f9;
        border: 1px solid #cbd5e1;
        color: #475569;
        cursor: pointer;
        transition: all 0.15s;
    }

    .quick-tag:hover {
        background: #e2e8f0;
        color: #0f172a;
    }

    /* Image Dropzone */
    .image-dropzone {
        border: 2px dashed #cbd5e1;
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        background: #f8fafc;
        cursor: pointer;
        transition: all 0.2s;
    }

    .image-dropzone:hover {
        border-color: #0d9488;
        background: #f0fdfa;
    }
</style>
@endpush

@section('content')
<div style="max-width: 960px; margin: 0 auto; padding-bottom: 60px;">

    {{-- Header Banner --}}
    <div style="margin-bottom: 22px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
        <div style="display: flex; align-items: center; gap: 14px;">
            <div style="width: 48px; height: 48px; border-radius: 14px; background: #e0f2fe; color: #0284c7; display: flex; align-items: center; justify-content: center; font-size: 24px; flex-shrink: 0;">
                <i class="bi bi-pencil-square"></i>
            </div>
            <div>
                <h2 style="font-size: 20px; font-weight: 700; color: #0f172a; margin: 0 0 4px 0;">
                    แก้ไขข้อมูลครุภัณฑ์: <span style="color: #0284c7;">{{ $asset->asset_code }}</span>
                </h2>
                <p style="font-size: 13.5px; color: #64748b; margin: 0;">
                    {{ $asset->name }} &bull; ประจำหน่วยงาน {{ $asset->department->name ?? 'ไม่ระบุ' }}
                </p>
            </div>
        </div>
        <div style="display: flex; gap: 8px;">
            <a href="{{ route('assets.show', $asset) }}" class="btn btn-secondary btn-sm" style="display: inline-flex; align-items: center; gap: 6px;">
                <i class="bi bi-arrow-left"></i> ย้อนกลับ
            </a>
            <a href="{{ route('assets.label', $asset) }}" class="btn btn-outline-primary btn-sm" target="_blank" style="display: inline-flex; align-items: center; gap: 6px;">
                <i class="bi bi-qr-code"></i> พิมพ์สติกเกอร์
            </a>
        </div>
    </div>

    {{-- Edit Form --}}
    <form action="{{ route('assets.update', $asset) }}" method="POST" enctype="multipart/form-data" id="editAssetForm">
        @csrf
        @method('PUT')

        {{-- SECTION 1: ข้อมูลพื้นฐานและการจำแนกประเภท (Asset Identity) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #e0f2fe; color: #0284c7;">
                        <i class="bi bi-tag-fill"></i>
                    </div>
                    <span>1. ข้อมูลพื้นฐานและประเภทครุภัณฑ์ (Asset Identification)</span>
                </div>
                <span style="font-size: 12px; color: #0284c7; font-weight: 600; background: #e0f2fe; padding: 2px 8px; border-radius: 6px;">
                    ข้อมูลจำเป็น *
                </span>
            </div>

            <div class="form-section-body">
                {{-- Quick Device Type Chips --}}
                <div style="margin-bottom: 18px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <label class="form-label" style="font-size: 12.5px; color: #64748b; margin-bottom: 0;">
                            เลือกประเภทอุปกรณ์ด่วน:
                        </label>
                        @if(auth()->check() && auth()->user()->isAdmin())
                        <a href="{{ route('device-types.index') }}" target="_blank" style="font-size: 11.5px; color: #0284c7; text-decoration: none; font-weight: 500;">
                            <i class="bi bi-gear-fill me-1"></i>จัดการประเภทอุปกรณ์
                        </a>
                        @endif
                    </div>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                        @foreach($deviceTypes as $type)
                            @php
                                $icon = $type->icon ?: 'bi-device-hdd';
                                if (empty($type->icon)) {
                                    $lower = mb_strtolower($type->name);
                                    if (str_contains($lower, 'ตั้งโต๊ะ') || str_contains($lower, 'pc')) $icon = 'bi-pc-display';
                                    elseif (str_contains($lower, 'โน้ตบุ๊ก') || str_contains($lower, 'notebook') || str_contains($lower, 'laptop')) $icon = 'bi-laptop';
                                    elseif (str_contains($lower, 'all-in-one') || str_contains($lower, 'aio')) $icon = 'bi-display';
                                    elseif (str_contains($lower, 'server') || str_contains($lower, 'เซิร์ฟเวอร์')) $icon = 'bi-server';
                                    elseif (str_contains($lower, 'พิมพ์') || str_contains($lower, 'printer')) $icon = 'bi-printer';
                                    elseif (str_contains($lower, 'สแกนเนอร์') || str_contains($lower, 'scanner')) $icon = 'bi-scanner';
                                    elseif (str_contains($lower, 'เครือข่าย') || str_contains($lower, 'switch') || str_contains($lower, 'router')) $icon = 'bi-hdd-network';
                                }
                                $isActiveType = (old('device_type_id', $asset->device_type_id) == $type->id);
                            @endphp
                            <button type="button" class="type-pill-btn {{ $isActiveType ? 'active' : '' }}"
                                    data-type-id="{{ $type->id }}"
                                    data-type-name="{{ $type->name }}"
                                    onclick="selectDeviceType('{{ $type->id }}', this)">
                                <i class="bi {{ $icon }}"></i>
                                <span>{{ $type->name }}</span>
                            </button>
                        @endforeach
                    </div>
                </div>

                {{-- Dual Identifiers Setup: รหัสคุมไอที & รหัสพัสดุ --}}
                <div style="background: linear-gradient(135deg, #f0fdfa 0%, #f8fafc 100%); border: 1.5px solid #99f6e4; border-radius: 12px; padding: 16px; margin-bottom: 20px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <div style="width: 28px; height: 28px; border-radius: 7px; background: #0d9488; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 14px;">
                                <i class="bi bi-tag-fill"></i>
                            </div>
                            <div>
                                <strong style="font-size: 13.5px; color: #0f766e;">การกำหนดรหัสประจำตัวครุภัณฑ์ (Dual-Code Identification)</strong>
                                <span style="font-size: 11.5px; color: #64748b; margin-left: 4px;">รหัสคุมฝ่ายไอที + รหัสทะเบียนพัสดุราชการ</span>
                            </div>
                    </div>

                    @php
                        $curTag = old('it_code', old('it_asset_code', $asset->it_code));
                        $defaultMode = 'auto';
                        if ($asset->is_rented || str_starts_with((string)$curTag, 'RENT')) {
                            $defaultMode = 'rent';
                        } elseif ($asset->is_donated || str_starts_with((string)$curTag, 'DON')) {
                            $defaultMode = 'don';
                        }
                    @endphp

                    {{-- Prefix Selector: มาตรฐาน (ไม่ผูกแผนก), RENT (เครื่องเช่า), DON (รับบริจาค), กำหนดเอง --}}
                    <div style="background: #ffffff; border: 1px solid #ccfbf1; border-radius: 8px; padding: 10px 14px; margin-bottom: 14px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <span style="font-size: 12px; font-weight: 700; color: #0f766e;">หมวด / Prefix รหัสคุม:</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;" id="prefixButtonGroup">
                            <label class="btn-prefix-pill {{ $defaultMode === 'auto' ? 'active' : '' }}" onclick="setPrefixMode('auto')">
                                <input type="radio" name="prefix_mode" value="auto" {{ $defaultMode === 'auto' ? 'checked' : '' }} style="display: none;">
                                <i class="bi bi-tag-fill"></i> มาตรฐาน [ประเภท][ปีงบ][ลำดับ] (ไม่ผูกแผนก)
                            </label>
                            <label class="btn-prefix-pill {{ $defaultMode === 'rent' ? 'active' : '' }}" onclick="setPrefixMode('rent')">
                                <input type="radio" name="prefix_mode" value="rent" {{ $defaultMode === 'rent' ? 'checked' : '' }} style="display: none;">
                                <i class="bi bi-printer"></i> RENT (เครื่องเช่า)
                            </label>
                            <label class="btn-prefix-pill {{ $defaultMode === 'don' ? 'active' : '' }}" onclick="setPrefixMode('don')">
                                <input type="radio" name="prefix_mode" value="don" {{ $defaultMode === 'don' ? 'checked' : '' }} style="display: none;">
                                <i class="bi bi-gift"></i> DON (รับบริจาค)
                            </label>
                            <label class="btn-prefix-pill {{ $defaultMode === 'custom' ? 'active' : '' }}" onclick="setPrefixMode('custom')">
                                <input type="radio" name="prefix_mode" value="custom" style="display: none;">
                                <i class="bi bi-pencil"></i> กำหนดเอง
                            </label>
                        </div>
                    </div>

                    <div class="form-row" style="margin-bottom: 0;">
                        {{-- 1. Official Asset Code (Primary Source) --}}
                        <div class="form-group" style="flex: 1.3;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <label class="form-label" for="asset_code">
                                    <i class="bi bi-file-earmark-text text-primary"></i> หมายเลขครุภัณฑ์พัสดุ (Asset No.)
                                </label>
                                <label style="font-size: 11.5px; color: #64748b; display: inline-flex; align-items: center; gap: 4px; cursor: pointer; user-select: none;">
                                    <input type="checkbox" id="no_asset_code" name="no_asset_code" value="1" {{ !$asset->has_official_asset_code ? 'checked' : '' }} onchange="toggleNoAssetCode(this)">
                                    <span style="color: #ea580c; font-weight: 600;">ไม่มีเลขพัสดุ (เครื่องเช่า / บริจาค)</span>
                                </label>
                            </div>
                            <input type="text" id="asset_code" name="asset_code" class="form-control"
                                   value="{{ old('asset_code', $asset->has_official_asset_code ? $asset->asset_code : '') }}" 
                                   placeholder="เช่น 7440-001-0005/66 หรือ 7440-002-0001/67" 
                                   style="font-family: monospace; font-size: 13.5px;"
                                   oninput="handleAssetCodeInput(this.value)"
                                   {{ !$asset->has_official_asset_code ? 'disabled style=background-color:#f1f5f9;' : '' }}>
                            <span class="form-text" id="asset_code_hint">พิมพ์เลขพัสดุเพื่อผูกรหัส IT Tag อัตโนมัติ (เช่น 7440-001-0005/66 &rarr; ลำดับ 0005, ปี 66)</span>
                        </div>

                        {{-- 2. IT Asset Tag (Random Alphanumeric + Barcode) --}}
                        <div class="form-group" style="flex: 1.2;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                                <label class="form-label required" for="it_code" style="color: #0f766e; margin-bottom: 0;">
                                    <i class="bi bi-upc-scan text-primary"></i> รหัสคุมครุภัณฑ์ไอที (IT Code / Barcode)
                                </label>
                                <span id="itBindingBadge" class="badge" style="background: #0d9488; color: white; font-size: 10px;">
                                    <i class="bi bi-dice-5-fill"></i> สุ่มรหัสอัตโนมัติ
                                </span>
                            </div>
                            <div style="position: relative;">
                                <input type="text" id="it_code" name="it_code" class="form-control"
                                       value="{{ old('it_code', old('it_asset_code', $asset->it_code)) }}" placeholder="เช่น PC-K9M2X4"
                                       readonly
                                       style="font-family: 'JetBrains Mono', 'SFMono-Regular', Consolas, monospace; font-size: 15px; font-weight: 800; color: #0f766e; background: #f8fafc; border-color: #0d9488; cursor: default; letter-spacing: 0.5px; padding-right: 175px;"
                                       oninput="handleManualTagInput()">
                                <div style="position: absolute; right: 6px; top: 50%; transform: translateY(-50%); display: flex; gap: 4px;">
                                    <button type="button" id="btnRandomizeTag" onclick="randomizeNewItCode()" 
                                            style="background: #0d9488; border: 1px solid #0f766e; color: #ffffff; border-radius: 4px; padding: 4px 9px; font-size: 11px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 4px;" 
                                            title="สุ่มรหัส 6 หลักใหม่ทันที">
                                        <i class="bi bi-shuffle"></i> <span>สุ่มรหัสใหม่</span>
                                    </button>
                                    <button type="button" id="btnToggleManualTag" onclick="toggleManualTag()" 
                                            style="background: #f0fdfa; border: 1px solid #ccfbf1; color: #0d9488; border-radius: 4px; padding: 4px 8px; font-size: 11px; font-weight: 600; cursor: pointer;" 
                                            title="คลิกเพื่อปลดล็อกแก้ไขรหัสเอง หรือซิงค์อัตโนมัติ">
                                        <i class="bi bi-lock-fill" id="manualTagIcon"></i> <span id="manualTagLabel">แก้ไขเอง</span>
                                    </button>
                                </div>
                            </div>
                            <span class="form-text" id="it_tag_hint" style="color: #0f766e; font-size: 11.5px;">
                                โครงสร้าง: [รหัสย่อประเภท]-[สุ่ม 6 หลัก อักษรพิมพ์ใหญ่+ตัวเลข] &bull; พร้อมสร้าง Barcode (Code 128) อัตโนมัติ
                            </span>

                            {{-- Live Barcode Preview --}}
                            <div id="barcodePreviewBox" style="margin-top: 8px; background: #ffffff; border: 1px dashed #0d9488; border-radius: 6px; padding: 6px 12px; display: inline-flex; align-items: center; gap: 12px;">
                                <div id="barcodeSvgTarget" style="min-width: 140px; height: 38px; display: flex; align-items: center;">
                                    @if($asset->it_code)
                                        {!! \App\Services\BarcodeService::generateSvg($asset->it_code, 38, 2, false) !!}
                                    @else
                                        <span style="font-size: 10px; color: #94a3b8;"><i class="bi bi-hourglass-split"></i> กำลังโหลดบาร์โค้ด...</span>
                                    @endif
                                </div>
                                <div style="font-size: 10.5px; color: #64748b; line-height: 1.2;">
                                    <span style="font-weight: 700; color: #0f766e;"><i class="bi bi-upc"></i> Barcode 1D (Code 128)</span><br>
                                    <span>สแกนด้วยเครื่องอ่านบาร์โค้ดได้ทันที</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-row">

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="serial_number">Serial Number (S/N)</label>
                        <input type="text" id="serial_number" name="serial_number" class="form-control"
                               value="{{ old('serial_number', $asset->serial_number) }}" placeholder="เช่น S/N บนตัวเครื่อง">
                    </div>

                    <div class="form-group" style="flex: 1.2;">
                        <label class="form-label required" for="device_type_id">ประเภทอุปกรณ์ (Device Type)</label>
                        <select name="device_type_id" id="device_type_id" class="form-select" required onchange="handleTypeDropdownChange(this)">
                            <option value="">-- กรุณาเลือกประเภท --</option>
                            @foreach($deviceTypes as $type)
                                <option value="{{ $type->id }}" data-code="{{ $type->code }}" {{ old('device_type_id', $asset->device_type_id) == $type->id ? 'selected' : '' }}>
                                    {{ $type->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                {{-- ICT Standard Catalog Selector (เกณฑ์ราคากลางกระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม) --}}
                <div style="background: linear-gradient(135deg, #f8fafc 0%, #f0fdfa 100%); border: 1.5px solid #99f6e4; border-radius: 12px; padding: 16px; margin-bottom: 20px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <div style="width: 28px; height: 28px; border-radius: 7px; background: #0d9488; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 14px;">
                                <i class="bi bi-bookmark-check-fill"></i>
                            </div>
                            <div>
                                <strong style="font-size: 13.5px; color: #0f766e;">ปรับชื่อรายการตามเกณฑ์ราคากลางและคุณลักษณะพื้นฐานฯ</strong>
                                <span style="font-size: 11.5px; color: #64748b; margin-left: 4px;">(กระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม)</span>
                            </div>
                        </div>
                        <span id="ictStandardBadge" style="display: none; background: #ccfbf1; color: #0f766e; border: 1px solid #5eead4; font-size: 11.5px; font-weight: 600; padding: 3px 10px; border-radius: 999px;">
                            <i class="bi bi-patch-check-fill text-success me-1"></i> ตรงตามเกณฑ์มาตรฐานภาครัฐ
                        </span>
                    </div>

                    {{-- Grouped Select by Category --}}
                    <div style="margin-bottom: 10px;">
                        <select id="ict_standard_select" class="form-select" onchange="handleIctStandardSelect(this.value)" style="border-color: #5eead4; background-color: #ffffff; font-size: 13.5px; font-weight: 500;">
                            <option value="">-- คลิกเพื่อเลือกปรับชื่อตามเกณฑ์ราคากลาง ICT (มีสเปคและราคากลางแนะนำ) --</option>
                            @if(isset($ictStandardsGrouped))
                                @foreach($ictStandardsGrouped as $category => $items)
                                    <optgroup label="📁 {{ $category }}">
                                        @foreach($items as $item)
                                            <option value="{{ $item['code'] }}">
                                                {{ $item['name'] }} (ราคากลาง: {{ number_format($item['standard_price']) }} บาท)
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endforeach
                            @endif
                        </select>
                    </div>

                    {{-- Quick Popular Standard Pills --}}
                    <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center;">
                        <span style="font-size: 11px; font-weight: 600; color: #0d9488;">เกณฑ์ยอดนิยม:</span>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PC-PROC-2')">💻 PC ประมวลผล (แบบ 2 - 27,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PC-OFFICE')">💻 PC สำนักงาน (17,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('NB-PROC')">💻 โน้ตบุ๊กประมวลผล (26,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('NB-OFFICE')">💻 โน้ตบุ๊ก สนง. (21,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('AIO-PROC')">🖥️ All-in-One (23,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-LASER-NET')">🖨️ เลเซอร์ Network (8,500 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-MFP-MONO')">🖨️ มัลติฟังก์ชันเลเซอร์ (7,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-INK-TANK')">🖨️ Ink Tank แท้ (5,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-LABEL-BARCODE')">🏷️ พิมพ์สติกเกอร์ยา (12,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('UPS-800VA')">🔋 UPS 800VA (2,500 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('SCN-SMART-CARD')">💳 อ่านบัตร ปชช. (500 บ.)</button>
                    </div>

                    {{-- Description & Specs Hint Box (Appears when item selected) --}}
                    <div id="ictInfoBox" style="display: none; margin-top: 10px; padding: 10px 14px; background: #ffffff; border: 1px solid #99f6e4; border-radius: 8px; font-size: 12px; color: #334155;">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; flex-wrap: wrap;">
                            <div style="flex: 1; min-width: 240px;">
                                <strong id="ictInfoTitle" style="color: #0f766e; font-size: 12.5px;">-</strong>
                                <div id="ictInfoDesc" style="color: #64748b; margin-top: 2px; line-height: 1.4;">-</div>
                            </div>
                            <div style="text-align: right; flex-shrink: 0;">
                                <span style="font-size: 11px; color: #64748b;">ราคากลางมาตรฐาน:</span>
                                <div id="ictInfoPrice" style="font-size: 14.5px; font-weight: 700; color: #0284c7;">-</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group" style="flex: 1.5;">
                        <label class="form-label required" for="name">
                            ชื่อรายการครุภัณฑ์ (Asset Name)
                            <small class="text-muted" style="font-weight: 400;">(สามารถเลือกจากเกณฑ์ด้านบน หรือพิมพ์แก้ไขต่อท้ายได้)</small>
                        </label>
                        <input type="text" id="name" name="name" class="form-control"
                               value="{{ old('name', $asset->name) }}" required>
                        <span class="form-text">ชื่อทางการสำหรับทะเบียนพัสดุและรายงานตามระเบียบราชการ</span>
                    </div>

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="brand">ยี่ห้อ (Brand)</label>
                        <input type="text" id="brand" name="brand" class="form-control" list="brand_suggestions"
                               value="{{ old('brand', $asset->brand) }}" placeholder="เช่น Dell, HP, Lenovo, Brother">
                        <datalist id="brand_suggestions">
                            <option value="Dell">
                            <option value="HP">
                            <option value="Lenovo">
                            <option value="Acer">
                            <option value="Asus">
                            <option value="Brother">
                            <option value="Canon">
                            <option value="Epson">
                            <option value="Cisco">
                            <option value="Ruijie">
                            <option value="MikroTik">
                        </datalist>
                    </div>

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="model">รุ่น (Model)</label>
                        <input type="text" id="model" name="model" class="form-control"
                               value="{{ old('model', $asset->model) }}" placeholder="เช่น OptiPlex 7010, ThinkCentre">
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 2: คุณลักษณะเฉพาะทางฮาร์ดแวร์ & สเปคเครื่อง (Hardware Specifications) --}}
        <div class="form-section-card" id="hardwareSpecsSection">
            <div class="form-section-header" style="background: linear-gradient(to right, #f0fdfa, #f8fafc);">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #ccfbf1; color: #0d9488;">
                        <i class="bi bi-cpu-fill"></i>
                    </div>
                    <span>2. คุณลักษณะและสเปคฮาร์ดแวร์ (Hardware Specifications)</span>
                </div>
                <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                    <button type="button" class="btn btn-sm btn-primary" onclick="openClientHardwareModal('deep')" style="font-size: 12px; font-weight: 600; padding: 4px 12px; border-radius: 7px; display: inline-flex; align-items: center; gap: 5px; background: linear-gradient(135deg, #0d9488 0%, #0284c7 100%); border: none;">
                        <i class="bi bi-shield-check"></i> ⚡ สแกนสเปคจริง 100%
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-success" onclick="pasteHardwareSpecsFromClipboard()" style="font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 7px; display: inline-flex; align-items: center; gap: 4px; background: #ffffff;">
                        <i class="bi bi-clipboard-check"></i> วางสเปค
                    </button>
                    <span style="font-size: 11.5px; color: #0f766e; background: #e6fffa; border: 1px solid #99f6e4; padding: 2px 8px; border-radius: 6px;">
                        สำหรับ PC, โน้ตบุ๊ก, All-in-One, Server
                    </span>
                </div>
            </div>

            <div class="form-section-body" style="padding-bottom: 12px;">
                @include('assets._specs_form', ['asset' => $asset])
            </div>
        </div>

        {{-- SECTION 3: สถานที่ติดตั้งและผู้ครอบครอง (Location & Custodian) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #ede9fe; color: #7c3aed;">
                        <i class="bi bi-geo-alt-fill"></i>
                    </div>
                    <span>3. สถานที่ติดตั้งและผู้ครอบครอง (Location & Custodian)</span>
                </div>
            </div>

            <div class="form-section-body">
                <div class="form-row">
                    <div class="form-group" style="flex: 1.2;">
                        <label class="form-label" for="department_id">
                            <i class="bi bi-building text-secondary"></i> แผนก / หน่วยงานที่รับผิดชอบ
                        </label>
                        <select name="department_id" id="department_id" class="form-select" onchange="handleDepartmentChange(this)">
                            <option value="">-- ไม่ระบุแผนก --</option>
                            @foreach($departments as $dept)
                                <option value="{{ $dept->id }}" data-code="{{ $dept->code }}" {{ old('department_id', $asset->department_id) == $dept->id ? 'selected' : '' }}>
                                    {{ $dept->name }} {{ $dept->code ? '['.$dept->code.']' : '' }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group" style="flex: 1.2;">
                        <label class="form-label" for="location_detail">
                            <i class="bi bi-pin-map text-danger"></i> จุดที่ตั้ง / ห้องทำงาน
                        </label>
                        <input type="text" id="location_detail" name="location_detail" class="form-control"
                               value="{{ old('location_detail', $asset->location_detail) }}" placeholder="เช่น เคาน์เตอร์พยาบาล, โต๊ะทำงานชั้น 2">
                        <div style="display: flex; gap: 6px; margin-top: 6px; flex-wrap: wrap; align-items: center;">
                            <span style="font-size: 11px; color: #64748b;">ตำแหน่งด่วน:</span>
                            <span class="quick-tag" onclick="setLocation('เคาน์เตอร์พยาบาล')">เคาน์เตอร์พยาบาล</span>
                            <span class="quick-tag" onclick="setLocation('ห้องตรวจแพทย์ 1')">ห้องตรวจแพทย์ 1</span>
                            <span class="quick-tag" onclick="setLocation('ห้องจ่ายยา / เภสัชกรรม')">ห้องจ่ายยา</span>
                            <span class="quick-tag" onclick="setLocation('ห้องการเงินและบัญชี')">ห้องการเงิน</span>
                            <span class="quick-tag" onclick="setLocation('ห้องเซิร์ฟเวอร์ / งาน IT')">งาน IT</span>
                        </div>
                    </div>

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="custodian_name">
                            <i class="bi bi-person-fill text-primary"></i> ชื่อผู้ครอบครอง / ผู้ดูแล
                        </label>
                        <input type="text" id="custodian_name" name="custodian_name" class="form-control"
                               value="{{ old('custodian_name', $asset->custodian_name) }}" placeholder="เช่น พว.สุดาพร ใจดี">
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 4: การเชื่อมต่อเครือข่าย (Network Settings) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #e0f2fe; color: #0369a1;">
                        <i class="bi bi-hdd-network-fill"></i>
                    </div>
                    <span>4. การเชื่อมต่อเครือข่าย (Network Settings)</span>
                </div>
                <span style="font-size: 12px; color: #64748b;">Subnet รพ.ทุ่งหัวช้าง 192.168.2.x</span>
            </div>

            <div class="form-section-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="ip_address">
                            <i class="bi bi-router text-primary"></i> IP Address
                        </label>
                        <input type="text" id="ip_address" name="ip_address" class="form-control"
                               value="{{ old('ip_address', $asset->ip_address) }}" placeholder="เช่น 192.168.2.55">
                        <span class="form-text">IP Address ภายในระบบ LAN โรงพยาบาล</span>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="mac_address">
                            <i class="bi bi-ethernet text-secondary"></i> MAC Address
                        </label>
                        <input type="text" id="mac_address" name="mac_address" class="form-control"
                               value="{{ old('mac_address', $asset->mac_address) }}" placeholder="เช่น 00:1A:2B:3C:4D:5E">
                        <span class="form-text">Hardware Address การ์ดแลน / Wi-Fi</span>
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 5: การจัดซื้อ, ประกัน & สถานะ (Procurement & Status) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #fef3c7; color: #d97706;">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <span>5. ข้อมูลการจัดซื้อ ประกัน และสถานะครุภัณฑ์ (Procurement & Status)</span>
                </div>
            </div>

            <div class="form-section-body">
                {{-- Status Selection --}}
                <div style="margin-bottom: 20px;">
                    <label class="form-label required" style="margin-bottom: 8px;">สถานะครุภัณฑ์ (Asset Status)</label>
                    <div class="status-card-group">
                        @php $currentStatus = old('status', $asset->status); @endphp
                        <label class="status-radio-card {{ $currentStatus == 'active' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="active" {{ $currentStatus == 'active' ? 'checked' : '' }} required>
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #065f46;">ใช้งานปกติ</strong>
                            <span style="font-size: 11px; color: #64748b;">Active</span>
                        </label>

                        <label class="status-radio-card status-spare {{ $currentStatus == 'spare' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="spare" {{ $currentStatus == 'spare' ? 'checked' : '' }}>
                            <i class="bi bi-shield-check text-info" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #0284c7;">เครื่องสำรอง</strong>
                            <span style="font-size: 11px; color: #64748b;">Spare</span>
                        </label>

                        <label class="status-radio-card status-repairing {{ $currentStatus == 'repairing' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="repairing" {{ $currentStatus == 'repairing' ? 'checked' : '' }}>
                            <i class="bi bi-tools text-warning" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #d97706;">ส่งซ่อม</strong>
                            <span style="font-size: 11px; color: #64748b;">In Repair</span>
                        </label>

                        <label class="status-radio-card status-broken {{ $currentStatus == 'broken' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="broken" {{ $currentStatus == 'broken' ? 'checked' : '' }}>
                            <i class="bi bi-exclamation-octagon-fill text-danger" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #dc2626;">ชำรุดรอซ่อม</strong>
                            <span style="font-size: 11px; color: #64748b;">Broken</span>
                        </label>

                        <label class="status-radio-card status-disposed {{ $currentStatus == 'disposed' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="disposed" {{ $currentStatus == 'disposed' ? 'checked' : '' }}>
                            <i class="bi bi-archive-fill text-secondary" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #475569;">รอแทงจำหน่าย</strong>
                            <span style="font-size: 11px; color: #64748b;">Disposed</span>
                        </label>
                    </div>
                </div>

                {{-- วิธีการได้มา แหล่งเงิน และกรรมสิทธิ์ (Acquisition, Funding & Ownership) --}}
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px 18px; margin-bottom: 20px;">
                    <div style="font-size: 13.5px; font-weight: 700; color: #1e293b; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                        <i class="bi bi-wallet2 text-primary"></i>
                        <span>วิธีการได้มา แหล่งเงินงบประมาณ และกรรมสิทธิ์การครอบครอง</span>
                    </div>
                    
                    <div class="form-row" style="margin-bottom: 12px;">
                        {{-- วิธีการได้มาของครุภัณฑ์ --}}
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label" for="acquisition_method_id">
                                วิธีการได้มาของครุภัณฑ์
                                <a href="{{ route('acquisition-methods.index') }}" target="_blank" class="text-primary text-decoration-none ms-1" style="font-size: 11px;" title="จัดการวิธีการได้มา">+ จัดการตัวเลือก</a>
                            </label>
                            <select id="acquisition_method_id" name="acquisition_method_id" class="form-select" onchange="handleAcquisitionMethodChange(this)">
                                <option value="">-- ไม่ระบุ / ระบุภายหลัง --</option>
                                @foreach($acquisitionMethods as $method)
                                    <option value="{{ $method->id }}" 
                                            data-code="{{ $method->code }}"
                                            {{ old('acquisition_method_id', $asset->acquisition_method_id) == $method->id ? 'selected' : '' }}>
                                        {{ $method->name }} {{ $method->code ? '('.$method->code.')' : '' }}
                                    </option>
                                @endforeach
                            </select>
                            <span class="form-text" style="font-size: 11.5px; color: #64748b;">เช่น จัดซื้อจัดจ้าง, ได้รับบริจาค, เช่าใช้บริการ, รับโอน</span>
                        </div>

                        {{-- แหล่งเงินที่ใช้ซื้อ --}}
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label" for="budget_source_id">
                                แหล่งเงินที่ใช้ซื้อ / แหล่งงบประมาณ
                                <a href="{{ route('budget-sources.index') }}" target="_blank" class="text-primary text-decoration-none ms-1" style="font-size: 11px;" title="จัดการแหล่งเงินงบประมาณ">+ จัดการตัวเลือก</a>
                            </label>
                            <select id="budget_source_id" name="budget_source_id" class="form-select">
                                <option value="">-- ไม่ระบุ / ระบุภายหลัง --</option>
                                @foreach($budgetSources as $source)
                                    <option value="{{ $source->id }}" 
                                            {{ old('budget_source_id', $asset->budget_source_id) == $source->id ? 'selected' : '' }}>
                                        {{ $source->name }} {{ $source->code ? '('.$source->code.')' : '' }}
                                    </option>
                                @endforeach
                            </select>
                            <span class="form-text" style="font-size: 11.5px; color: #64748b;">เช่น เงิน UC, เงินเก็บค่าบริการ (เงินบำรุง), เงินงบประมาณแผ่นดิน</span>
                        </div>

                        {{-- ประเภทกรรมสิทธิ์ / การครอบครอง --}}
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label required" for="ownership_type">ประเภทกรรมสิทธิ์ / การครอบครอง</label>
                            @php $curOwnership = old('ownership_type', $asset->ownership_type ?? 'owned'); @endphp
                            <select id="ownership_type" name="ownership_type" class="form-select" onchange="toggleRentalBox(this.value)" required>
                                <option value="owned" {{ $curOwnership == 'owned' ? 'selected' : '' }}>🏢 เป็นของ รพ. (ซื้อขาด)</option>
                                <option value="rented" {{ $curOwnership == 'rented' ? 'selected' : '' }}>🖨️ เช่าใช้ (เครื่องเช่า / สัญญาเช่า)</option>
                                <option value="donated" {{ $curOwnership == 'donated' ? 'selected' : '' }}>🎁 ได้รับบริจาค</option>
                                <option value="borrowed" {{ $curOwnership == 'borrowed' ? 'selected' : '' }}>🔄 ยืมใช้งานภายนอก</option>
                            </select>
                            <span class="form-text" style="font-size: 11.5px; color: #64748b;">เลือก "เช่าใช้" สำหรับเครื่องพิมพ์หรืออุปกรณ์ที่เช่ารายเดือน/รายปี</span>
                        </div>
                    </div>

                    {{-- Collapsible Rental Contract Details Box (เครื่องเช่า เช่น เครื่องพิมพ์เช่า) --}}
                    <div id="rentalContractBox" style="display: {{ $curOwnership == 'rented' ? 'block' : 'none' }}; background: #fffaf5; border: 1.5px dashed #fdba74; border-radius: 10px; padding: 16px; margin-top: 14px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px dashed #fed7aa; padding-bottom: 8px;">
                            <div style="font-size: 13px; font-weight: 700; color: #c2410c; display: flex; align-items: center; gap: 6px;">
                                <i class="bi bi-printer-fill" style="font-size: 16px;"></i>
                                <span>ข้อมูลสัญญาเช่าและบริษัทผู้ให้เช่า (Lease / Rental Contract Details)</span>
                            </div>
                            <span class="badge" style="background: #ffedd5; color: #c2410c; border: 1px solid #fdba74; font-size: 11px;">
                                สำหรับควบคุมเครื่องเช่า & เครื่องพิมพ์เช่า
                            </span>
                        </div>

                        <div class="form-row" style="margin-bottom: 10px;">
                            <div class="form-group" style="flex: 1.2;">
                                <label class="form-label" for="rental_contract_no">เลขที่สัญญาเช่า</label>
                                <input type="text" id="rental_contract_no" name="rental_contract_no" class="form-control" 
                                       placeholder="เช่น CN-IT-2567/012, สัญญาเช่าที่ 45/2567" 
                                       value="{{ old('rental_contract_no', $asset->rental_contract_no) }}">
                            </div>

                            <div class="form-group" style="flex: 1.5;">
                                <label class="form-label" for="rental_vendor">บริษัทผู้ให้เช่า / คู่สัญญา</label>
                                <input type="text" id="rental_vendor" name="rental_vendor" class="form-control" 
                                       placeholder="เช่น บจก. ฟูจิฟิล์ม บิสซิเนสฯ, ริโก้ (ประเทศไทย), แคนนอน" 
                                       value="{{ old('rental_vendor', $asset->rental_vendor) }}">
                            </div>

                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_contact_phone">เบอร์ติดต่อบริษัท/ช่างบริการ</label>
                                <input type="text" id="rental_contact_phone" name="rental_contact_phone" class="form-control" 
                                       placeholder="เช่น 02-xxx-xxxx, 081-xxx-xxxx" 
                                       value="{{ old('rental_contact_phone', $asset->rental_contact_phone) }}">
                            </div>
                        </div>

                        <div class="form-row" style="margin-bottom: 10px;">
                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_start_date">วันเริ่มสัญญาเช่า</label>
                                <input type="date" id="rental_start_date" name="rental_start_date" class="form-control" 
                                       value="{{ old('rental_start_date', $asset->rental_start_date?->format('Y-m-d')) }}">
                            </div>

                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_end_date">วันสิ้นสุดสัญญาเช่า</label>
                                <input type="date" id="rental_end_date" name="rental_end_date" class="form-control" 
                                       value="{{ old('rental_end_date', $asset->rental_end_date?->format('Y-m-d')) }}">
                            </div>

                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_monthly_fee">ค่าเช่ารายเดือน/งวด (บาท)</label>
                                <div style="position: relative;">
                                    <input type="number" step="0.01" id="rental_monthly_fee" name="rental_monthly_fee" class="form-control" 
                                           placeholder="เช่น 2500.00" 
                                           value="{{ old('rental_monthly_fee', $asset->rental_monthly_fee) }}" style="padding-right: 42px;">
                                    <span style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 12px; color: #94a3b8;">บาท</span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="rental_conditions">เงื่อนไขสัญญาและบริการ (Conditions & Service Level)</label>
                            <textarea id="rental_conditions" name="rental_conditions" class="form-control" rows="2" 
                                      placeholder="เช่น รวมหมึกพิมพ์ทุกสีและค่าบริการซ่อมบำรุง, โควตาพิมพ์ขาวดำ 5,000 แผ่น/เดือน, สี 1,000 แผ่น/เดือน ส่วนเกินแผ่นละ 0.50 บาท">{{ old('rental_conditions', $asset->rental_conditions) }}</textarea>
                        </div>
                    </div>
                </div>

                {{-- Financial & Dates --}}
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="purchase_date">วันที่ตรวจรับ / ซื้อ</label>
                        <input type="date" id="purchase_date" name="purchase_date" class="form-control"
                               value="{{ old('purchase_date', $asset->purchase_date?->format('Y-m-d')) }}" onchange="handlePurchaseDateChange(this.value)">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="price">ราคาจัดซื้อ (บาท)</label>
                        <div style="position: relative;">
                            <input type="number" step="0.01" id="price" name="price" class="form-control"
                                   value="{{ old('price', $asset->price) }}" placeholder="เช่น 24500.00" style="padding-right: 42px;">
                            <span style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 13px; color: #94a3b8;">บาท</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="warranty_expire_date">วันหมดประกัน</label>
                        <input type="date" id="warranty_expire_date" name="warranty_expire_date" class="form-control"
                               value="{{ old('warranty_expire_date', $asset->warranty_expire_date?->format('Y-m-d')) }}">
                        <div style="display: flex; gap: 6px; margin-top: 6px; flex-wrap: wrap; align-items: center;">
                            <span style="font-size: 11px; color: #64748b;">คำนวณ:</span>
                            <span class="quick-tag" onclick="addWarrantyYears(1)">+1 ปี</span>
                            <span class="quick-tag" onclick="addWarrantyYears(3)">+3 ปี</span>
                            <span class="quick-tag" onclick="addWarrantyYears(5)">+5 ปี</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="budget_year">ปีงบประมาณ</label>
                        <input type="text" id="budget_year" name="budget_year" class="form-control"
                               value="{{ old('budget_year', $asset->budget_year) }}" 
                               placeholder="เช่น 2567, 2568 (หากว่าง ระบบจะใช้ XX อัตโนมัติ)"
                               oninput="if (!isManualTagOverride) updateSmartBoundItTag()"
                               onchange="if (!isManualTagOverride) updateSmartBoundItTag()">
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 6: รูปถ่ายและหมายเหตุเพิ่มเติม (Photo & Notes) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #f1f5f9; color: #475569;">
                        <i class="bi bi-camera-fill"></i>
                    </div>
                    <span>6. รูปถ่ายครุภัณฑ์และหมายเหตุ (Photo & Notes)</span>
                </div>
            </div>

            <div class="form-section-body">
                <div class="form-row">
                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="image">รูปถ่ายครุภัณฑ์ (Asset Image)</label>
                        <div class="image-dropzone" onclick="document.getElementById('image').click()">
                            <input type="file" id="image" name="image" class="form-control" accept="image/*" style="display: none;" onchange="previewAssetImage(event)">
                            <div id="imageUploadPrompt" style="{{ $asset->image ? 'display: none;' : '' }}">
                                <i class="bi bi-cloud-arrow-up text-primary" style="font-size: 28px;"></i>
                                <div style="font-size: 13px; font-weight: 600; color: #1e293b; margin-top: 4px;">คลิกเพื่อเปลี่ยนรูปถ่าย</div>
                                <div style="font-size: 11.5px; color: #64748b;">รองรับไฟล์ JPG, PNG สูงสุด 3MB</div>
                            </div>
                            <div id="imagePreviewBox" style="display: {{ $asset->image ? 'flex' : 'none' }}; align-items: center; justify-content: center; gap: 12px; margin-top: 8px;">
                                <img id="imagePreviewImg" src="{{ $asset->image ? asset($asset->image) : '' }}" alt="รูปถ่ายครุภัณฑ์" style="max-height: 110px; border-radius: 8px; border: 1px solid #cbd5e1; box-shadow: 0 2px 6px rgba(0,0,0,0.1);">
                                <button type="button" class="btn btn-sm btn-light border text-danger" onclick="removeAssetImage(event)" title="ลบรูป">
                                    <i class="bi bi-trash"></i> ลบรูป
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group" style="flex: 1.5;">
                        <label class="form-label" for="notes">หมายเหตุเพิ่มเติม (Notes)</label>
                        <textarea id="notes" name="notes" class="form-control" rows="4" placeholder="บันทึกข้อมูลเพิ่มเติม เช่น ประวัติการโยกย้าย, รหัสพัสดุเดิม...">{{ old('notes', $asset->notes) }}</textarea>
                    </div>
                </div>
            </div>
        </div>

        {{-- Form Actions Bar --}}
        <div style="background: #ffffff; border: 1px solid var(--border); border-radius: 14px; padding: 18px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px; box-shadow: 0 4px 16px rgba(0,0,0,0.04);">
            <a href="{{ route('assets.show', $asset) }}" class="btn btn-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                <i class="bi bi-x-circle"></i>
                <span>ยกเลิก</span>
            </a>

            <div style="display: flex; align-items: center; gap: 10px;">
                <button type="submit" class="btn btn-primary btn-lg" style="display: inline-flex; align-items: center; gap: 8px; padding: 10px 24px; font-weight: 600; box-shadow: 0 4px 14px rgba(13, 148, 136, 0.3);">
                    <i class="bi bi-floppy-fill"></i>
                    <span>บันทึกการแก้ไขข้อมูล</span>
                </button>
            </div>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script>
    // Set Device Type from Pills
    function selectDeviceType(typeId, buttonElem) {
        const select = document.getElementById('device_type_id');
        if (select) {
            select.value = typeId;
            handleTypeDropdownChange(select);
        }

        // Update pills active class
        document.querySelectorAll('.type-pill-btn').forEach(btn => btn.classList.remove('active'));
        if (buttonElem) {
            buttonElem.classList.add('active');
        }
    }

    function handleTypeDropdownChange(selectElem) {
        const typeId = selectElem.value;
        const selectedText = selectElem.options[selectElem.selectedIndex]?.text?.toLowerCase() || '';

        // Sync pills active state
        document.querySelectorAll('.type-pill-btn').forEach(btn => {
            if (btn.getAttribute('data-type-id') === typeId) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        // Highlight hardware section if computer/notebook/server
        const hwSection = document.getElementById('hardwareSpecsSection');
        const isComputer = selectedText.includes('คอมพิวเตอร์') || 
                           selectedText.includes('โน้ตบุ๊ก') || 
                           selectedText.includes('notebook') || 
                           selectedText.includes('all-in-one') || 
                           selectedText.includes('server');

        if (hwSection) {
            if (isComputer) {
                hwSection.style.border = '2px solid #0d9488';
                hwSection.style.boxShadow = '0 6px 20px rgba(13, 148, 136, 0.12)';
            } else {
                hwSection.style.border = '1px solid var(--border)';
                hwSection.style.boxShadow = '0 2px 8px rgba(0,0,0,0.02)';
            }
        }

        if (typeof updateSmartBoundItTag === 'function') {
            updateSmartBoundItTag();
        }
    }

    function setLocation(val) {
        const input = document.getElementById('location_detail');
        if (input) input.value = val;
    }

    // Status Radio Card Selector
    function selectStatusCard(cardElem) {
        document.querySelectorAll('.status-radio-card').forEach(c => c.classList.remove('active-status'));
        cardElem.classList.add('active-status');
        const radio = cardElem.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
    }

    // Auto Warranty Calculation
    function addWarrantyYears(years) {
        const purchaseInput = document.getElementById('purchase_date');
        const warrantyInput = document.getElementById('warranty_expire_date');
        if (!purchaseInput || !purchaseInput.value) {
            alert('กรุณาระบุ วันที่ตรวจรับ/ซื้อ ก่อนคำนวณวันหมดประกัน');
            return;
        }

        const date = new Date(purchaseInput.value);
        date.setFullYear(date.getFullYear() + years);
        warrantyInput.value = date.toISOString().split('T')[0];
    }

    function handlePurchaseDateChange(val) {
        const budgetYearInput = document.getElementById('budget_year');
        if (val && budgetYearInput) {
            const date = new Date(val);
            const gregorianYear = date.getFullYear();
            const month = date.getMonth() + 1;
            const budgetYear = (month >= 10 ? gregorianYear + 1 : gregorianYear) + 543;
            budgetYearInput.value = budgetYear;
            if (!isManualTagOverride && typeof updateSmartBoundItTag === 'function') {
                updateSmartBoundItTag();
            }
        }
    }

    // Image Upload & Preview
    function previewAssetImage(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(evt) {
                document.getElementById('imagePreviewImg').src = evt.target.result;
                document.getElementById('imageUploadPrompt').style.display = 'none';
                document.getElementById('imagePreviewBox').style.display = 'flex';
            };
            reader.readAsDataURL(file);
        }
    }

    function removeAssetImage(e) {
        if (e) e.stopPropagation();
        const input = document.getElementById('image');
        if (input) input.value = '';
        document.getElementById('imagePreviewImg').src = '';
        document.getElementById('imagePreviewBox').style.display = 'none';
        document.getElementById('imageUploadPrompt').style.display = 'block';
    }

    // ICT Standard Catalog Integration
    const ictCatalog = @json($ictStandardsAll ?? []);

    function selectIctByCode(code) {
        const select = document.getElementById('ict_standard_select');
        if (select) {
            select.value = code;
            handleIctStandardSelect(code);
        }
    }

    function handleIctStandardSelect(code) {
        if (!code) {
            document.getElementById('ictStandardBadge').style.display = 'none';
            document.getElementById('ictInfoBox').style.display = 'none';
            return;
        }

        const item = ictCatalog.find(i => i.code === code);
        if (!item) return;

        // 1. Update Name
        const nameInput = document.getElementById('name');
        if (nameInput) {
            nameInput.value = item.name;
        }

        // 2. Select Matching Device Type
        if (item.device_type_code) {
            const devSelect = document.getElementById('device_type_id');
            if (devSelect) {
                const opt = Array.from(devSelect.options).find(o => o.getAttribute('data-code') === item.device_type_code);
                if (opt) {
                    devSelect.value = opt.value;
                    handleTypeDropdownChange(devSelect);
                }
            }
        }

        // 3. Suggest Standard Price if empty
        const priceInput = document.getElementById('price');
        if (priceInput && !priceInput.value) {
            priceInput.value = parseFloat(item.standard_price).toFixed(2);
        }

        // 4. Fill Recommended Specs (if fields are currently empty)
        if (item.specs) {
            const fillIfEmpty = (id, val) => {
                const elem = document.getElementById(id);
                if (elem && !elem.value && val !== undefined && val !== null && val !== '') {
                    elem.value = val;
                }
            };

            fillIfEmpty('cpu_model', item.specs.cpu_model);
            fillIfEmpty('cpu_speed', item.specs.cpu_speed);
            fillIfEmpty('ram_capacity', item.specs.ram_capacity);
            fillIfEmpty('ram_type', item.specs.ram_type);
            fillIfEmpty('ram_bus', item.specs.ram_bus);
            fillIfEmpty('ram_slots', item.specs.ram_slots);
            fillIfEmpty('storage_type', item.specs.storage_type);
            fillIfEmpty('storage_capacity', item.specs.storage_capacity);
            fillIfEmpty('storage_second', item.specs.storage_second);
            fillIfEmpty('os_name', item.specs.os_name);
            fillIfEmpty('os_license', item.specs.os_license);
            fillIfEmpty('gpu_model', item.specs.gpu_model);
            fillIfEmpty('monitor_size', item.specs.monitor_size);

            if (typeof updateLiveSpecsPreview === 'function') {
                updateLiveSpecsPreview();
            }
        }

        // 5. Display ICT Info Box & Badge
        const badge = document.getElementById('ictStandardBadge');
        if (badge) {
            badge.style.display = 'inline-flex';
            badge.innerHTML = '<i class="bi bi-patch-check-fill text-success me-1"></i> เกณฑ์มาตรฐาน ICT (ราคากลาง ' + Number(item.standard_price).toLocaleString() + ' บาท)';
        }

        const infoBox = document.getElementById('ictInfoBox');
        if (infoBox) {
            infoBox.style.display = 'block';
            document.getElementById('ictInfoTitle').textContent = item.name;
            document.getElementById('ictInfoDesc').textContent = item.description || 'คุณลักษณะพื้นฐานตามเกณฑ์กระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม';
            document.getElementById('ictInfoPrice').textContent = Number(item.standard_price).toLocaleString() + ' บาท';
        }
    }

    // Initial check on load: if asset name matches any ICT standard, show badge
    document.addEventListener('DOMContentLoaded', function() {
        const currentName = document.getElementById('name')?.value || '';
        if (currentName) {
            const matched = ictCatalog.find(i => i.name.trim() === currentName.trim() || currentName.includes(i.short_name));
            if (matched) {
                const badge = document.getElementById('ictStandardBadge');
                if (badge) {
                    badge.style.display = 'inline-flex';
                    badge.innerHTML = '<i class="bi bi-patch-check-fill text-success me-1"></i> เกณฑ์มาตรฐาน ICT: ' + matched.short_name;
                }
                const select = document.getElementById('ict_standard_select');
                if (select) select.value = matched.code;
            }
        }
    });

    let currentPrefixMode = '{{ $defaultMode ?? 'dept' }}';
    let isManualTagOverride = false;
    const currentAssetId = '{{ $asset->id }}';

    /**
     * วิเคราะห์รหัสครุภัณฑ์พัสดุราชการ (Client-side Parser)
     * สอดคล้อง 100% กับ ItAssetCodeGeneratorService::parseOfficialAssetCode ของฝั่ง Backend
     */
    function parseAssetCodeJs(code) {
        if (!code) return { hasCode: false, seq: null, year: null };
        let c = code.trim().toUpperCase();
        c = c.replace(/(\d{4})-(\d{3})\/(\d{4})\/(\d+)/, '$1-$2-$3/$4');

        if (c.startsWith('RENT-') || c.startsWith('DON-') || c.startsWith('PENDING-') || c.startsWith('TEMP-') || c.startsWith('NO-ASSET') || c.startsWith('NOASSET-')) {
            return { hasCode: false, seq: null, year: null };
        }

        // รูปแบบที่ 1: รหัสพัสดุมาตรฐาน 4 ส่วน เช่น 7440-001-0010/67 หรือ 7440-001-0008/1
        const m1 = c.match(/^(\d{4})-(\d{3})-(\d+)\/(\d+)$/);
        if (m1) {
            const part3 = m1[3];
            const part4 = m1[4];
            const p4Int = parseInt(part4, 10);
            const isFiscalYear = (part4.length === 2 && p4Int >= 60 && p4Int <= 75) ||
                                 (part4.length === 4 && p4Int >= 2560 && p4Int <= 2575);
            if (isFiscalYear) {
                return { hasCode: true, seq: part3, year: part4.slice(-2) };
            } else {
                return { hasCode: true, seq: `${part3}/${part4}`, year: null };
            }
        }

        // รูปแบบที่ 2: รหัสพัสดุที่มี slash ทั่วไป เช่น .../67 หรือ .../17
        const m2 = c.match(/(?:^|[^\d])(\d+)\/(\d+)$/);
        if (m2) {
            const p1 = m2[1];
            const p2 = m2[2];
            const p2Int = parseInt(p2, 10);
            const isFiscalYear = (p2.length === 2 && p2Int >= 60 && p2Int <= 75) ||
                                 (p2.length === 4 && p2Int >= 2560 && p2Int <= 2575);
            if (isFiscalYear) {
                return { hasCode: true, seq: p1, year: p2.slice(-2) };
            } else {
                return { hasCode: true, seq: `${p1}/${p2}`, year: null };
            }
        }

        // รูปแบบที่ 3: มาตรฐาน 7440-xxx-xxxx (ไม่มี slash)
        const m3 = c.match(/^7440-\d+-(\d+)$/i);
        if (m3) {
            return { hasCode: true, seq: m3[1], year: null };
        }

        // รูปแบบที่ 4: ลงท้ายด้วยขีดตามด้วยตัวเลข (ไม่เกิน 6 หลัก)
        const m4 = c.match(/-(\d{1,6})$/i);
        if (m4) {
            return { hasCode: true, seq: m4[1], year: null };
        }

        return { hasCode: true, seq: null, year: null };
    }

    function resolveSelectedTypeCode() {
        const typeSelect = document.getElementById('device_type_id');
        const selectedOption = typeSelect ? typeSelect.options[typeSelect.selectedIndex] : null;
        let typeCode = selectedOption ? (selectedOption.getAttribute('data-code') || '') : '';
        if (!typeCode && selectedOption && selectedOption.value) {
            const text = selectedOption.text.toLowerCase();
            if (text.includes('pc') || text.includes('ตั้งโต๊ะ')) typeCode = 'PC';
            else if (text.includes('โน้ต') || text.includes('nb') || text.includes('laptop')) typeCode = 'NB';
            else if (text.includes('all-in-one') || text.includes('aio')) typeCode = 'AIO';
            else if (text.includes('สติกเกอร์') || text.includes('ความร้อน')) typeCode = 'THM';
            else if (text.includes('พิมพ์') || text.includes('printer')) typeCode = 'PRN';
            else if (text.includes('สำรองไฟ') || text.includes('ups')) typeCode = 'UPS';
            else if (text.includes('เครือข่าย') || text.includes('switch')) typeCode = 'NET';
            else if (text.includes('สแกน') || text.includes('scanner')) typeCode = 'SCN';
            else if (text.includes('server') || text.includes('เซิร์ฟ')) typeCode = 'SRV';
            else typeCode = 'DEV';
        }
        return typeCode || 'DEV';
    }

    function resolveSelectedDeptCode() {
        const deptSelect = document.getElementById('department_id');
        const selectedDept = deptSelect ? deptSelect.options[deptSelect.selectedIndex] : null;
        let code = selectedDept ? (selectedDept.getAttribute('data-code') || '') : '';
        if (!code && selectedDept && selectedDept.value) {
            const name = selectedDept.text.toLowerCase();
            if (name.includes('it') || name.includes('สารสนเทศ')) code = 'IT';
            else if (name.includes('er') || name.includes('ฉุกเฉิน')) code = 'ER';
            else if (name.includes('opd') || name.includes('ผู้ป่วยนอก')) code = 'OPD';
            else if (name.includes('ipd') || name.includes('ผู้ป่วยใน')) code = 'IPD';
            else if (name.includes('lab') || name.includes('ชันสูตร')) code = 'LAB';
            else if (name.includes('phar') || name.includes('เภสัช')) code = 'PHAR';
            else if (name.includes('xray') || name.includes('รังสี')) code = 'XRAY';
            else if (name.includes('dent') || name.includes('ทันต')) code = 'DENT';
            else if (name.includes('adm') || name.includes('บริหาร')) code = 'ADM';
        }
        return code || '{{ $asset->department?->code ?: "THC" }}';
    }

    function resolveBudgetYearShort() {
        const bYearInput = document.getElementById('budget_year');
        if (bYearInput && bYearInput.value && bYearInput.value.trim() !== '') {
            const val = bYearInput.value.trim();
            if (val.length >= 2) {
                return val.slice(-2);
            }
        }
        const assetCodeInput = document.getElementById('asset_code');
        if (assetCodeInput && assetCodeInput.value) {
            const parsed = parseAssetCodeJs(assetCodeInput.value);
            if (parsed && parsed.year) {
                return parsed.year;
            }
        }
        return 'XX';
    }

    /**
     * ระบบสุ่มรหัสคุมครุภัณฑ์ไอที (IT Code) รูปแบบใหม่:
     * [รหัสย่อประเภท]-[สุ่ม 6 หลัก อักษรพิมพ์ใหญ่+ตัวเลข] พร้อม Barcode (Code 128)
     */
    function generateClientRandomToken(length = 6) {
        const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        const digits = '23456789';
        const all = letters + digits;
        let token = '';
        let hasLetter = false;
        let hasDigit = false;
        do {
            token = '';
            hasLetter = false;
            hasDigit = false;
            for (let i = 0; i < length; i++) {
                const char = all.charAt(Math.floor(Math.random() * all.length));
                token += char;
                if (letters.includes(char)) hasLetter = true;
                if (digits.includes(char)) hasDigit = true;
            }
        } while (!hasLetter || !hasDigit);
        return token;
    }

    let barcodeDebounceTimer = null;
    function refreshBarcodePreview(code) {
        const target = document.getElementById('barcodeSvgTarget');
        if (!target) return;
        if (!code || code.trim() === '') {
            target.innerHTML = '<span style="font-size: 10px; color: #94a3b8;">ไม่มีรหัส</span>';
            return;
        }

        clearTimeout(barcodeDebounceTimer);
        barcodeDebounceTimer = setTimeout(() => {
            fetch(`{{ route('assets.barcode.preview') }}?code=${encodeURIComponent(code)}`)
                .then(res => res.text())
                .then(svg => {
                    if (svg && svg.includes('<svg')) {
                        target.innerHTML = svg;
                    }
                })
                .catch(() => {});
        }, 100);
    }

    function randomizeNewItCode() {
        const itInput = document.getElementById('it_code') || document.getElementById('it_asset_code');
        const itBadge = document.getElementById('itBindingBadge');
        const itHint = document.getElementById('it_tag_hint');
        const typeCode = resolveSelectedTypeCode();
        const randToken = generateClientRandomToken(6);
        const newCode = `${typeCode}-${randToken}`;

        if (itInput) {
            itInput.value = newCode;
            itInput.style.backgroundColor = '#ecfdf5';
            setTimeout(() => { itInput.style.backgroundColor = isManualTagOverride ? '#ffffff' : '#f8fafc'; }, 300);
        }
        if (itBadge) {
            itBadge.innerHTML = `<i class="bi bi-dice-5-fill"></i> สุ่มรหัสใหม่ (${typeCode})`;
            itBadge.style.background = '#0d9488';
        }
        if (itHint) {
            itHint.innerHTML = `🔗 <strong>รหัสคุม IT สุ่มอิสระ:</strong> <span style="font-family: monospace; font-weight: 800; color: #0d9488;">${newCode}</span> &bull; <em>สแกนบาร์โค้ดได้ทันที</em>`;
        }

        refreshBarcodePreview(newCode);

        // ยืนยันรหัสที่ไม่ซ้ำจากเซิร์ฟเวอร์
        fetchNextItCodeFromServer('', typeCode, '');
    }

    let itCodeFetchTimer = null;
    function updateSmartBoundItTag() {
        if (isManualTagOverride) {
            return;
        }

        const typeCode = resolveSelectedTypeCode();
        const itInput = document.getElementById('it_code') || document.getElementById('it_asset_code');
        const itBadge = document.getElementById('itBindingBadge');
        const itHint = document.getElementById('it_tag_hint');

        // สุ่มรหัสใหม่แบบ Client-side ทันทีเพื่อความลื่นไหล
        const randToken = generateClientRandomToken(6);
        const newCode = `${typeCode}-${randToken}`;

        if (itInput && !itInput.value) {
            itInput.value = newCode;
        } else if (itInput && !isManualTagOverride) {
            const parts = itInput.value.split('-');
            if (parts.length === 2 && parts[1].length === 6) {
                itInput.value = `${typeCode}-${parts[1]}`;
            } else {
                itInput.value = newCode;
            }
        }

        if (itBadge) {
            itBadge.innerHTML = `<i class="bi bi-dice-5-fill"></i> สุ่มรหัส (${typeCode})`;
            itBadge.style.background = '#0d9488';
        }
        if (itHint && itInput) {
            itHint.innerHTML = `🔗 <strong>รหัสคุม IT สุ่มอิสระ:</strong> <span style="font-family: monospace; font-weight: 800; color: #0d9488;">${itInput.value}</span> &bull; <em>สแกนบาร์โค้ดได้ทันที</em>`;
        }

        refreshBarcodePreview(itInput ? itInput.value : newCode);

        // ซิงค์ตรวจสอบความซ้ำซ้อนจากฐานข้อมูลผ่าน AJAX
        clearTimeout(itCodeFetchTimer);
        itCodeFetchTimer = setTimeout(() => {
            fetchNextItCodeFromServer('', typeCode, '');
        }, 150);
    }

    function fetchNextItCodeFromServer(prefix, typeCode, year) {
        if (isManualTagOverride) return;
        const typeId = document.getElementById('device_type_id')?.value || '';
        const nameVal = document.getElementById('name')?.value || '';
        const assetCode = document.getElementById('asset_code')?.value || '';

        const params = new URLSearchParams({
            device_type_id: typeId,
            device_type_code: typeCode,
            name: nameVal,
            asset_code: assetCode,
            exclude_id: '{{ $asset->id }}'
        });

        fetch(`{{ route('assets.next-it-code') }}?${params.toString()}`)
            .then(res => res.json())
            .then(data => {
                if (data && data.success && data.it_code) {
                    const itInput = document.getElementById('it_code') || document.getElementById('it_asset_code');
                    const itHint = document.getElementById('it_tag_hint');
                    const target = document.getElementById('barcodeSvgTarget');

                    if (itInput && !isManualTagOverride && (!itInput.value || itInput.value.startsWith(typeCode))) {
                        itInput.value = data.it_code;
                    }
                    if (itHint) {
                        itHint.innerHTML = `🔗 <strong>รหัสคุม IT สุ่มอิสระ:</strong> <span style="font-family: monospace; font-weight: 800; color: #0d9488;">${data.it_code}</span> &bull; <em>สแกนด้วย Barcode 1D และ QR Code ได้ทันที</em>`;
                    }
                    if (data.barcode_svg && target) {
                        target.innerHTML = data.barcode_svg;
                    }
                }
            })
            .catch(e => {});
    }

    function handleManualTagInput() {
        const input = document.getElementById('it_code') || document.getElementById('it_asset_code');
        if (input) {
            refreshBarcodePreview(input.value);
        }
    }

    function handleAssetCodeInput(val) {
        // เลขพัสดุไม่มีผลต่อรหัส IT Code อีกต่อไปตามดีไซน์ใหม่
    }

    function toggleManualTag() {
        const input = document.getElementById('it_code') || document.getElementById('it_asset_code');
        const icon = document.getElementById('manualTagIcon');
        const label = document.getElementById('manualTagLabel');
        const badge = document.getElementById('itBindingBadge');

        if (!isManualTagOverride) {
            isManualTagOverride = true;
            currentPrefixMode = 'custom';
            if (icon) icon.className = 'bi bi-arrow-repeat';
            if (label) label.textContent = 'ซิงค์อัตโนมัติ';
            if (badge) {
                badge.innerHTML = '<i class="bi bi-pencil-fill"></i> กำหนดเอง';
                badge.style.background = '#8b5cf6';
            }
            if (input) {
                input.removeAttribute('readonly');
                input.style.backgroundColor = '#ffffff';
                input.style.cursor = 'text';
                input.focus();
                input.select();
            }
            document.querySelectorAll('#prefixButtonGroup .btn-prefix-pill').forEach(btn => {
                const radio = btn.querySelector('input');
                if (radio && radio.value === 'custom') {
                    btn.classList.add('active');
                    radio.checked = true;
                } else {
                    btn.classList.remove('active');
                }
            });
        } else {
            isManualTagOverride = false;
            currentPrefixMode = 'auto';
            if (icon) icon.className = 'bi bi-lock-fill';
            if (label) label.textContent = 'แก้ไขเอง';
            if (input) {
                input.setAttribute('readonly', 'readonly');
                input.style.backgroundColor = '#f8fafc';
                input.style.cursor = 'default';
            }
            document.querySelectorAll('#prefixButtonGroup .btn-prefix-pill').forEach(btn => {
                const radio = btn.querySelector('input');
                if (radio && radio.value === 'auto') {
                    btn.classList.add('active');
                    radio.checked = true;
                } else {
                    btn.classList.remove('active');
                }
            });
            updateSmartBoundItTag();
        }
    }

    function handleManualTagInput() {
        isManualTagOverride = true;
        currentPrefixMode = 'custom';
        const icon = document.getElementById('manualTagIcon');
        const label = document.getElementById('manualTagLabel');
        const badge = document.getElementById('itBindingBadge');
        if (icon) icon.className = 'bi bi-arrow-repeat';
        if (label) label.textContent = 'ซิงค์อัตโนมัติ';
        if (badge) {
            badge.innerHTML = '<i class="bi bi-pencil"></i> ปรับแต่งเอง';
            badge.style.background = '#8b5cf6';
        }
    }

    function setPrefixMode(mode) {
        currentPrefixMode = mode;
        if (mode !== 'custom') {
            isManualTagOverride = false;
            const icon = document.getElementById('manualTagIcon');
            const label = document.getElementById('manualTagLabel');
            if (icon) icon.className = 'bi bi-pencil';
            if (label) label.textContent = 'แก้ไขเอง';
        }

        document.querySelectorAll('#prefixButtonGroup .btn-prefix-pill').forEach(btn => {
            const radio = btn.querySelector('input');
            if (radio && radio.value === mode) {
                btn.classList.add('active');
                radio.checked = true;
            } else {
                btn.classList.remove('active');
            }
        });

        const noAssetCheckbox = document.getElementById('no_asset_code');
        const ownershipSelect = document.getElementById('ownership_type');

        if (mode === 'rent') {
            if (ownershipSelect) {
                ownershipSelect.value = 'rented';
                if (typeof toggleRentalBox === 'function') toggleRentalBox('rented');
            }
            if (noAssetCheckbox && !noAssetCheckbox.checked) {
                noAssetCheckbox.checked = true;
                toggleNoAssetCode(noAssetCheckbox);
            }
        } else if (mode === 'don') {
            if (ownershipSelect) {
                ownershipSelect.value = 'donated';
                if (typeof toggleRentalBox === 'function') toggleRentalBox('donated');
            }
            if (noAssetCheckbox && !noAssetCheckbox.checked) {
                noAssetCheckbox.checked = true;
                toggleNoAssetCode(noAssetCheckbox);
            }
        } else if (mode === 'auto') {
            if (ownershipSelect && (ownershipSelect.value === 'rented' || ownershipSelect.value === 'donated')) {
                ownershipSelect.value = 'owned';
                if (typeof toggleRentalBox === 'function') toggleRentalBox('owned');
            }
            if (noAssetCheckbox && noAssetCheckbox.checked) {
                noAssetCheckbox.checked = false;
                toggleNoAssetCode(noAssetCheckbox);
            }
        }

        updateSmartBoundItTag();
    }

    function handleDepartmentChange(selectElem) {
        // แผนกเปลี่ยน ไม่ต้องคำนวณรหัส IT Tag ใหม่ เพื่อให้ปริ้นสติ๊กเกอร์ครั้งเดียว ย้ายตำแหน่งได้โดยไม่ต้องปริ้นใหม่
    }

    function toggleNoAssetCode(checkbox) {
        const assetCodeInput = document.getElementById('asset_code');
        const hint = document.getElementById('asset_code_hint');
        if (checkbox.checked) {
            assetCodeInput.value = '';
            assetCodeInput.placeholder = '(เครื่องเช่า / รับบริจาค โดยไม่มีเลขพัสดุ)';
            assetCodeInput.disabled = true;
            assetCodeInput.style.backgroundColor = '#f1f5f9';
            if (hint) hint.innerHTML = '<span style="color: #ea580c; font-weight: 600;">✓ ไม่มีเลขพัสดุ: จัดการในระบบคลังและส่งซ่อมด้วยรหัสคุม IT</span>';
        } else {
            assetCodeInput.disabled = false;
            assetCodeInput.placeholder = 'เช่น 7440-001-0005/66 หรือ 7440-002-0001/67';
            assetCodeInput.style.backgroundColor = '#ffffff';
            if (hint) hint.innerHTML = 'พิมพ์เลขพัสดุเพื่อผูกรหัส IT Tag อัตโนมัติ (เช่น 7440-001-0005/66 &rarr; ลำดับ 0005, ปี 66)';
        }
        updateSmartBoundItTag();
    }

    function autoGenerateItAssetTag() {
        updateSmartBoundItTag();
    }

    function toggleRentalBox(type) {
        const box = document.getElementById('rentalContractBox');
        if (box) {
            box.style.display = (type === 'rented') ? 'block' : 'none';
        }
    }

    function handleAcquisitionMethodChange(select) {
        const selectedOption = select.options[select.selectedIndex];
        const code = selectedOption ? selectedOption.getAttribute('data-code') : '';
        const text = selectedOption ? selectedOption.text : '';
        
        if (code === 'RENTAL' || text.includes('เช่า')) {
            const ownershipSelect = document.getElementById('ownership_type');
            if (ownershipSelect) {
                ownershipSelect.value = 'rented';
                toggleRentalBox('rented');
            }
            setPrefixMode('rent');
        } else if (code === 'DONATION' || text.includes('บริจาค')) {
            const ownershipSelect = document.getElementById('ownership_type');
            if (ownershipSelect) {
                ownershipSelect.value = 'donated';
                toggleRentalBox('donated');
            }
            setPrefixMode('don');
        }
    }

    // Set initial badge, hint and barcode preview on page load
    document.addEventListener('DOMContentLoaded', function() {
        const itBadge = document.getElementById('itBindingBadge');
        const itHint = document.getElementById('it_tag_hint');
        const itInput = document.getElementById('it_code') || document.getElementById('it_asset_code');

        if (itInput && itInput.value) {
            refreshBarcodePreview(itInput.value);
            if (itBadge) {
                itBadge.innerHTML = `<i class="bi bi-upc-scan"></i> รหัสคุม IT พร้อมใช้งาน`;
                itBadge.style.background = '#0d9488';
            }
            if (itHint) {
                itHint.innerHTML = `🔗 <strong>รหัสคุม IT สุ่มอิสระ:</strong> <span style="font-family: monospace; font-weight: 800; color: #0d9488;">${itInput.value}</span> &bull; <em>สแกนด้วย Barcode 1D และ QR Code ได้ทันที</em>`;
            }
        } else if (itInput && !itInput.value) {
            updateSmartBoundItTag();
        }
    });
</script>
@endpush
