<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="THC IT">
    <meta name="theme-color" content="#0d9488">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'ระบบบริหารจัดการสารสนเทศ') - {{ setting('department_name', 'กลุ่มงานสุขภาพดิจิทัล') }} {{ setting('hospital_name_th', 'โรงพยาบาลทุ่งหัวช้าง') }}</title>

    <!-- Google Fonts: Prompt -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Chart.js & SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --primary: #0d9488;
            --primary-dark: #0f766e;
            --primary-light: #ccfbf1;
            --primary-glow: rgba(13, 148, 136, 0.25);
            --secondary: #0284c7;
            --accent: #f59e0b;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #06b6d4;
            --dark: #0f172a;
            --dark-surface: #1e293b;
            --sidebar-bg: #0f172a;
            --sidebar-hover: #1e293b;
            --sidebar-active: #0d9488;
            --bg-body: #f8fafc;
            --card-bg: #ffffff;
            --border: #e2e8f0;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-full: 9999px;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.07), 0 2px 4px -2px rgba(0, 0, 0, 0.04);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -4px rgba(0, 0, 0, 0.04);
            --shadow-glow: 0 0 20px rgba(13, 148, 136, 0.15);
            --ease-fluid: cubic-bezier(0.16, 1, 0.3, 1);
            --sat: env(safe-area-inset-top, 0px);
            --sab: env(safe-area-inset-bottom, 0px);
            --sal: env(safe-area-inset-left, 0px);
            --sar: env(safe-area-inset-right, 0px);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
            text-rendering: optimizeLegibility;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* Modern Slim Scrollbar (ระบบเลื่อนหน้าจอและแถบเลื่อน) */
        ::-webkit-scrollbar {
            width: 7px;
            height: 7px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 9999px;
        }

        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 9999px;
            border: 1px solid #f1f5f9;
            transition: background 0.2s ease;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }

        .sidebar-nav::-webkit-scrollbar {
            width: 5px;
        }

        .sidebar-nav::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar-nav::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 9999px;
        }

        .sidebar-nav::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        body {
            font-family: 'Prompt', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Global Top Loading Progress Bar (Linear SPA Feeling) */
        .global-progress-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: linear-gradient(90deg, #0d9488 0%, #0284c7 60%, #38bdf8 100%);
            box-shadow: 0 0 10px rgba(13, 148, 136, 0.7), 0 0 5px rgba(2, 132, 199, 0.5);
            z-index: 999999;
            pointer-events: none;
            opacity: 0;
            transition: width 0.3s var(--ease-fluid), opacity 0.3s ease;
        }

        .global-progress-bar.active {
            opacity: 1;
        }

        .global-progress-bar.finished {
            width: 100% !important;
            opacity: 0;
            transition: width 0.15s ease, opacity 0.35s ease 0.1s;
        }

        /* Mobile Sidebar Backdrop (Glassmorphism Blur) */
        .sidebar-backdrop {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.55);
            backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px);
            z-index: 95;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s var(--ease-fluid);
        }

        .sidebar-backdrop.show {
            display: block;
            opacity: 1;
            pointer-events: auto;
        }

        /* Layout Structure */
        .app-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background-color: var(--sidebar-bg);
            color: #f8fafc;
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            transition: transform 0.3s var(--ease-fluid), width 0.3s var(--ease-fluid);
            box-shadow: 4px 0 24px rgba(0, 0, 0, 0.12);
            will-change: transform;
        }

        .sidebar-brand {
            padding: 24px 20px;
            display: flex;
            align-items: center;
            gap: 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            background: linear-gradient(180deg, rgba(255,255,255,0.04) 0%, transparent 100%);
        }

        .brand-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: linear-gradient(135deg, #0d9488 0%, #0284c7 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: white;
            box-shadow: 0 4px 12px rgba(13, 148, 136, 0.35);
        }

        .brand-title {
            font-weight: 700;
            font-size: 15px;
            line-height: 1.25;
            letter-spacing: -0.2px;
        }

        .brand-subtitle {
            font-size: 12px;
            color: #94a3b8;
            font-weight: 400;
        }

        .sidebar-nav {
            padding: 16px 12px;
            flex: 1;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .nav-section-title {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: #64748b;
            padding: 14px 12px 6px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            border-radius: var(--radius-sm);
            color: #cbd5e1;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: transform 0.2s var(--ease-fluid), background-color 0.2s ease, color 0.2s ease;
            position: relative;
        }

        .nav-item:hover {
            background-color: var(--sidebar-hover);
            color: #ffffff;
            transform: translateX(4px);
        }

        .nav-item:hover i {
            transform: scale(1.1);
        }

        .nav-item.active {
            background-color: var(--sidebar-active);
            color: #ffffff;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(13, 148, 136, 0.3);
        }

        .nav-item i {
            font-size: 18px;
            width: 22px;
            text-align: center;
            transition: transform 0.2s var(--ease-fluid);
        }

        .nav-badge {
            margin-left: auto;
            background: #f59e0b;
            color: #ffffff;
            font-size: 11px;
            font-weight: 700;
            padding: 2px 7px;
            border-radius: 999px;
            line-height: 1;
        }

        .sidebar-footer {
            padding: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            background: rgba(0, 0, 0, 0.15);
        }

        .user-widget {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-full);
            background: linear-gradient(135deg, #3b82f6, #0d9488);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 16px;
            color: white;
            overflow: hidden;
            flex-shrink: 0;
            border: 2px solid rgba(255, 255, 255, 0.15);
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info {
            flex: 1;
            min-width: 0;
        }

        .user-name {
            font-size: 13.5px;
            font-weight: 600;
            color: #f1f5f9;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-role-badge {
            display: inline-block;
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 9999px;
            background: rgba(13, 148, 136, 0.25);
            color: #5eead4;
            margin-top: 2px;
        }

        /* Main Content */
        .main-wrapper {
            margin-left: 280px;
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            width: calc(100% - 280px);
            transition: margin-left 0.3s var(--ease-fluid), width 0.3s var(--ease-fluid);
        }

        /* Top Navbar */
        .topbar {
            height: 68px;
            background-color: #ffffff;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            position: sticky;
            top: 0;
            z-index: 90;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.03);
            backdrop-filter: blur(8px);
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            font-size: 22px;
            color: var(--text-main);
            cursor: pointer;
            padding: 6px;
            border-radius: 8px;
            transition: background 0.15s ease, transform 0.15s ease;
        }

        .mobile-menu-btn:hover {
            background: #f1f5f9;
        }

        .mobile-menu-btn:active {
            transform: scale(0.92);
        }

        .page-title-box {
            display: flex;
            flex-direction: column;
        }

        .page-title {
            font-size: 19px;
            font-weight: 700;
            color: var(--text-main);
            letter-spacing: -0.3px;
        }

        .page-breadcrumb {
            font-size: 12px;
            color: var(--text-muted);
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
        }

        .topbar-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            color: var(--text-main);
            font-size: 13.5px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: transform 0.2s var(--ease-fluid), box-shadow 0.2s var(--ease-fluid), border-color 0.2s ease, background-color 0.2s ease, color 0.2s ease;
            user-select: none;
        }

        .topbar-btn:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: var(--primary-light);
            transform: translateY(-1px);
        }

        .topbar-btn:active {
            transform: scale(0.96) translateY(0) !important;
        }

        .topbar-btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            border: none;
            color: white !important;
            box-shadow: 0 2px 8px var(--primary-glow);
        }

        .topbar-btn-primary:hover {
            opacity: 0.95;
            transform: translateY(-1px);
            box-shadow: 0 4px 14px var(--primary-glow);
        }

        .topbar-btn-secondary {
            background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
            border: none;
            color: white !important;
            box-shadow: 0 2px 8px rgba(2, 132, 199, 0.25);
        }

        .topbar-btn-secondary:hover {
            opacity: 0.95;
            transform: translateY(-1px);
            box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35);
        }

        /* Version Modal Styles */
        .version-modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(5px);
            -webkit-backdrop-filter: blur(5px);
            z-index: 99999;
            align-items: center;
            justify-content: center;
            padding: 20px;
            opacity: 0;
            transition: opacity 0.25s var(--ease-fluid);
        }

        .version-modal-overlay.active {
            display: flex;
            opacity: 1;
        }

        .version-modal-card {
            background: #ffffff;
            border-radius: 16px;
            width: 100%;
            max-width: 660px;
            max-height: 88vh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            border: 1px solid var(--border);
            transform: translateY(12px) scale(0.97);
            transition: transform 0.25s var(--ease-fluid);
            overflow: hidden;
        }

        .version-modal-overlay.active .version-modal-card {
            transform: translateY(0) scale(1);
        }

        /* Content Area & Seamless Fade-and-Rise Entrance */
        @keyframes pageContentFadeIn {
            from {
                opacity: 0;
                transform: translateY(8px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .content-body {
            padding: 28px;
            flex: 1;
            animation: pageContentFadeIn 0.25s var(--ease-fluid) forwards;
        }

        /* Flash Messages */
        .alert-box {
            padding: 14px 18px;
            border-radius: var(--radius-sm);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            animation: slideDown 0.25s var(--ease-fluid);
            transition: opacity 0.25s ease, max-height 0.25s ease, margin 0.25s ease, padding 0.25s ease;
            overflow: hidden;
        }

        .alert-box.dismissed {
            opacity: 0;
            max-height: 0;
            padding-top: 0;
            padding-bottom: 0;
            margin-bottom: 0;
            pointer-events: none;
        }

        .alert-dismiss-btn {
            margin-left: auto;
            background: transparent;
            border: none;
            color: inherit;
            opacity: 0.55;
            font-size: 20px;
            line-height: 1;
            cursor: pointer;
            padding: 0 4px;
            border-radius: 4px;
            transition: opacity 0.15s ease, transform 0.15s ease;
        }

        .alert-dismiss-btn:hover {
            opacity: 1;
            transform: scale(1.1);
        }

        .alert-dismiss-btn:active {
            transform: scale(0.9);
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .alert-success {
            background-color: #ecfdf5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }

        .alert-error, .alert-danger {
            background-color: #fef2f2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }

        .alert-warning {
            background-color: #fffbeb;
            border: 1px solid #fde68a;
            color: #92400e;
        }

        .alert-info {
            background-color: #eff6ff;
            border: 1px solid #bfdbfe;
            color: #1e40af;
        }

        /* Cards */
        .card {
            background: var(--card-bg);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            margin-bottom: 24px;
            transition: transform 0.25s var(--ease-fluid), box-shadow 0.25s var(--ease-fluid), border-color 0.2s ease;
        }

        .card:hover {
            box-shadow: var(--shadow-md);
            border-color: rgba(13, 148, 136, 0.22);
        }

        .card-header {
            padding: 18px 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #ffffff;
        }

        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .card-body {
            padding: 24px;
        }

        /* Buttons & Micro-interactions */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 9px 18px;
            border-radius: var(--radius-sm);
            font-size: 14px;
            font-weight: 500;
            font-family: inherit;
            cursor: pointer;
            text-decoration: none;
            transition: transform 0.2s var(--ease-fluid), box-shadow 0.2s var(--ease-fluid), background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease;
            border: 1px solid transparent;
            user-select: none;
            -webkit-user-select: none;
            position: relative;
            overflow: hidden;
        }

        .btn:active:not(:disabled) {
            transform: scale(0.96) !important;
            transition: transform 0.05s ease !important;
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none !important;
        }

        /* Auto-Loading State for Form Submissions */
        .btn-is-loading {
            position: relative;
            pointer-events: none !important;
            opacity: 0.82 !important;
        }

        .btn-spinner {
            display: inline-block;
            width: 14px;
            height: 14px;
            border: 2px solid currentColor;
            border-right-color: transparent;
            border-radius: 50%;
            animation: btnSpin 0.6s linear infinite;
            vertical-align: middle;
        }

        @keyframes btnSpin {
            to { transform: rotate(360deg); }
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: #ffffff;
            box-shadow: 0 2px 8px var(--primary-glow);
        }

        .btn-primary:hover:not(:disabled) {
            transform: translateY(-1.5px);
            box-shadow: 0 4px 14px var(--primary-glow);
        }

        .btn-secondary {
            background: #f1f5f9;
            color: var(--text-main);
            border-color: var(--border);
        }

        .btn-secondary:hover:not(:disabled) {
            background: #e2e8f0;
            transform: translateY(-1px);
        }

        .btn-success {
            background: #10b981;
            color: white;
            box-shadow: 0 2px 8px rgba(16, 185, 129, 0.25);
        }

        .btn-success:hover:not(:disabled) {
            background: #059669;
            transform: translateY(-1.5px);
            box-shadow: 0 4px 14px rgba(16, 185, 129, 0.35);
        }

        .btn-danger {
            background: #ef4444;
            color: white;
            box-shadow: 0 2px 8px rgba(239, 68, 68, 0.25);
        }

        .btn-danger:hover:not(:disabled) {
            background: #dc2626;
            transform: translateY(-1.5px);
            box-shadow: 0 4px 14px rgba(239, 68, 68, 0.35);
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
            box-shadow: 0 2px 8px rgba(245, 158, 11, 0.25);
        }

        .btn-warning:hover:not(:disabled) {
            background: #d97706;
            transform: translateY(-1.5px);
            box-shadow: 0 4px 14px rgba(245, 158, 11, 0.35);
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12.5px;
            border-radius: 6px;
        }

        .btn-lg {
            padding: 12px 24px;
            font-size: 16px;
            border-radius: var(--radius-md);
        }

        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 500;
            line-height: 1;
            transition: background 0.15s ease, transform 0.15s ease;
        }

        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-primary { background: #ccfbf1; color: #0f766e; }
        .badge-success { background: #d1fae5; color: #065f46; }
        .badge-danger { background: #fee2e2; color: #991b1b; }
        .badge-info { background: #e0f2fe; color: #0369a1; }
        .badge-purple { background: #f3e8ff; color: #6b21a8; }
        .badge-orange { background: #ffedd5; color: #c2410c; }
        .badge-secondary { background: #f1f5f9; color: #475569; }

        .badge-outline-secondary { border: 1px solid #cbd5e1; color: #475569; }
        .badge-outline-info { border: 1px solid #7dd3fc; color: #0284c7; }
        .badge-outline-warning { border: 1px solid #fcd34d; color: #b45309; }
        .badge-outline-danger { border: 1px solid #fca5a5; color: #b91c1c; }

        /* Tables */
        .table-responsive {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 14px;
        }

        .table th {
            background-color: #f8fafc;
            color: #475569;
            font-weight: 600;
            padding: 12px 16px;
            border-bottom: 2px solid var(--border);
            white-space: nowrap;
        }

        .table td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
            transition: background-color 0.15s ease;
        }

        .table tbody tr {
            transition: background-color 0.15s ease;
        }

        .table tbody tr:hover {
            background-color: #f1fdfb;
        }

        /* Pagination */
        .pagination {
            display: flex;
            align-items: center;
            gap: 4px;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .page-item .page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 34px;
            height: 34px;
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            background: #ffffff;
            color: var(--text-main);
            font-size: 13px;
            font-weight: 500;
            text-decoration: none;
            transition: transform 0.15s var(--ease-fluid), background-color 0.15s ease, border-color 0.15s ease, color 0.15s ease;
        }

        .page-item .page-link:hover:not(.disabled) {
            background: #f1f5f9;
            border-color: #cbd5e1;
            color: var(--primary);
            transform: translateY(-1px);
        }

        .page-item.active .page-link {
            background: var(--primary) !important;
            border-color: var(--primary) !important;
            color: #ffffff !important;
            font-weight: 600;
            box-shadow: 0 2px 6px var(--primary-glow);
        }

        .page-item.disabled .page-link {
            background: #f8fafc;
            color: #94a3b8;
            border-color: #e2e8f0;
            cursor: not-allowed;
            opacity: 0.6;
        }

        /* Forms */
        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            font-size: 13.5px;
            font-weight: 500;
            color: var(--text-main);
            margin-bottom: 6px;
        }

        .form-label.required::after {
            content: ' *';
            color: var(--danger);
        }

        .form-control, .form-select, select.form-control {
            width: 100%;
            height: 42px;
            min-height: 42px;
            padding: 8px 14px;
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
            background-color: #ffffff;
            font-family: inherit;
            font-size: 13.5px;
            line-height: 1.5;
            color: var(--text-main);
            box-sizing: border-box;
            vertical-align: middle;
            transition: border-color 0.2s var(--ease-fluid), box-shadow 0.2s var(--ease-fluid), transform 0.2s var(--ease-fluid);
        }

        .form-select, select.form-control {
            padding-right: 36px;
            cursor: pointer;
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23475569' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 14px 12px;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
        }

        .form-control-sm, .form-select-sm, select.form-control-sm {
            height: 38px !important;
            min-height: 38px !important;
            padding: 6px 12px !important;
            font-size: 13px !important;
            line-height: 1.5 !important;
            box-sizing: border-box !important;
        }

        .form-select-sm, select.form-control-sm {
            padding-right: 32px !important;
        }

        .form-select option, select option {
            font-size: 13.5px;
            padding: 6px 10px;
            color: #1e293b;
            background: #ffffff;
            line-height: 1.6;
        }

        .form-control:focus, .form-select:focus, select.form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3.5px var(--primary-glow);
            transform: translateY(-1px);
        }

        .form-text {
            font-size: 12px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 16px;
        }

        /* Footer */
        .app-footer {
            padding: 20px 28px;
            border-top: 1px solid var(--border);
            background: #ffffff;
            font-size: 12.5px;
            color: var(--text-muted);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* Floating Back to Top Button */
        .back-to-top-btn {
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border: none;
            box-shadow: 0 4px 14px rgba(13, 148, 136, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
            z-index: 80;
            opacity: 0;
            visibility: hidden;
            transform: translateY(12px) scale(0.9);
            transition: opacity 0.25s var(--ease-fluid), transform 0.25s var(--ease-fluid), visibility 0.25s, box-shadow 0.2s;
        }

        .back-to-top-btn.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0) scale(1);
        }

        .back-to-top-btn:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.5);
        }

        .back-to-top-btn:active {
            transform: translateY(0) scale(0.95);
        }

        /* Pulse Animation */
        @keyframes pulseGlow {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.03); }
        }
        .animate-pulse {
            animation: pulseGlow 1.8s infinite;
        }

        /* Responsive Mobile */
        .mobile-bottom-nav {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 64px;
            background: rgba(255, 255, 255, 0.96);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-top: 1px solid rgba(226, 232, 240, 0.9);
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.06);
            z-index: 990;
            padding: 4px 6px;
            padding-bottom: max(4px, env(safe-area-inset-bottom, 0px));
            justify-content: space-around;
            align-items: center;
            gap: 4px;
        }
        .mobile-bottom-nav-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 4px 2px;
            color: #64748b;
            text-decoration: none;
            font-size: 10px;
            font-weight: 500;
            position: relative;
            border-radius: 8px;
            transition: all 0.15s ease;
            -webkit-tap-highlight-color: transparent;
            min-height: 48px;
        }
        .mobile-bottom-nav-item i {
            font-size: 19px;
            line-height: 1;
            margin-bottom: 2px;
        }
        .mobile-bottom-nav-item.active {
            color: var(--primary);
            font-weight: 700;
        }
        .mobile-bottom-nav-item.active i {
            transform: scale(1.08);
        }
        .mobile-bottom-nav-item .mobile-nav-badge {
            position: absolute;
            top: 2px;
            right: calc(50% - 16px);
            background: #ef4444;
            color: #ffffff;
            font-size: 9px;
            font-weight: 700;
            min-width: 16px;
            height: 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 4px;
            box-shadow: 0 2px 4px rgba(239, 68, 68, 0.4);
        }
        /* Mobile Bottom Action Buttons (Clean modern flat pill design - no protruding circular button) */
        .mobile-action-pill {
            width: 100%;
            height: 46px;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 2px;
            color: #ffffff !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
            padding: 4px 6px;
            text-decoration: none;
            cursor: pointer;
        }
        .mobile-action-pill:active {
            transform: scale(0.94);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
        }
        .mobile-action-pill i {
            font-size: 16px;
            line-height: 1;
            margin: 0;
            color: #ffffff !important;
        }
        .mobile-action-pill span {
            font-size: 11px;
            font-weight: 600;
            line-height: 1.1;
            color: #ffffff !important;
            white-space: nowrap;
        }
        .pill-repair {
            background: linear-gradient(135deg, #0d9488 0%, #0f766e 100%);
            box-shadow: 0 3px 10px rgba(13, 148, 136, 0.38);
        }
        .pill-data {
            background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
            box-shadow: 0 3px 10px rgba(2, 132, 199, 0.38);
        }
        .mobile-action-pill.active-pill {
            outline: 2px solid #ffffff;
            outline-offset: -2px;
        }
        .mobile-nav-action-wrapper {
            flex: 1.15;
            padding: 2px;
        }

        /* Touch-Friendly Global Defaults */
        html {
            -webkit-text-size-adjust: 100%;
            touch-action: manipulation;
        }

        button, a.btn, input, select, textarea, .nav-item, .mobile-bottom-nav-item {
            -webkit-tap-highlight-color: rgba(13, 148, 136, 0.12);
        }

        /* Sidebar Close Button (Shown on Mobile / Tablet) */
        .sidebar-close-btn {
            display: none;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            color: #ffffff;
            width: 38px;
            height: 38px;
            border-radius: 10px;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            cursor: pointer;
            margin-left: auto;
            flex-shrink: 0;
            transition: background 0.2s, transform 0.15s;
        }
        .sidebar-close-btn:active {
            transform: scale(0.92);
            background: rgba(255, 255, 255, 0.2);
        }

        /* Responsive Table with Smooth Touch Scrolling */
        .table-responsive {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            border-radius: var(--radius-sm);
        }
        .table-responsive::-webkit-scrollbar {
            height: 6px;
        }
        .table-responsive::-webkit-scrollbar-track {
            background: #f1f5f9;
        }
        .table-responsive::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 999px;
        }

        /* Desktop only topbar action items */
        .topbar-action-desktop-only {
            display: inline-flex;
        }

        /* ==========================================================================
           CROSS-PLATFORM TOUCH & RESPONSIVE COMPONENT ENGINE
           Optimized for: iOS (Safari, WebKit), iPadOS, Android (Chrome, Samsung Internet),
           Windows Touch (Edge, Surface), and all tablet / mobile screen sizes.
           ========================================================================== */

        /* Smooth momentum touch scrolling for webkit & prevent pull-to-refresh glitch */
        html {
            -webkit-text-size-adjust: 100%;
            text-size-adjust: 100%;
            touch-action: manipulation;
            overscroll-behavior-y: none;
        }

        body {
            overflow-x: hidden;
            width: 100%;
            min-height: 100dvh;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* Custom Modal Backdrop & Dialog System (Universal cross-module responsive) */
        .custom-modal-backdrop {
            display: none;
            position: fixed;
            inset: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.72);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            z-index: 1080;
            align-items: center;
            justify-content: center;
            padding: 16px;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            box-sizing: border-box;
        }

        .custom-modal-dialog {
            background: #ffffff;
            border-radius: 18px;
            width: 100%;
            max-width: 860px;
            max-height: 90vh;
            max-height: 90dvh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35);
            overflow: hidden;
            animation: modalScaleIn 0.22s cubic-bezier(0.16, 1, 0.3, 1);
            margin: auto;
            border: 1px solid rgba(226, 232, 240, 0.8);
        }

        @keyframes modalScaleIn {
            from { transform: scale(0.96); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        /* Table Responsive Horizontal Scroll Improvements */
        .table-responsive {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            position: relative;
            scrollbar-width: thin;
            scrollbar-color: #cbd5e1 #f1f5f9;
        }

        /* Prevent image / media overflow */
        img, svg, video, canvas {
            max-width: 100%;
            height: auto;
        }

        /* ==========================================================================
           1. TABLETS LANDSCAPE / IPAD PRO & LAPTOPS (< 1200px)
           ========================================================================== */
        @media (max-width: 1200px) {
            .content-body {
                padding: 20px 20px calc(80px + env(safe-area-inset-bottom, 0px)) 20px;
            }

            /* Collapse 4-column KPI/Stat cards to 2 columns on tablet landscape */
            div[style*="grid-template-columns: repeat(4, 1fr)"],
            div[style*="grid-template-columns: repeat(4,1fr)"],
            div[style*="grid-template-columns: repeat(auto-fit, minmax(240px, 1fr))"],
            div[style*="grid-template-columns: repeat(auto-fit, minmax(260px, 1fr))"] {
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 16px !important;
            }

            /* Prevent wide badge overflow */
            .topbar-right {
                gap: 8px;
            }
        }

        /* ==========================================================================
           2. TABLET PORTRAIT & MEDIUM SCREENS (< 992px)
           iPad Air, iPad mini, Android tablets, large foldables
           ========================================================================== */
        @media (max-width: 992px) {
            .sidebar {
                width: min(310px, 86vw);
                transform: translateX(-100%);
                box-shadow: 16px 0 36px rgba(0, 0, 0, 0.32);
                z-index: 1060;
                transition: transform 0.28s cubic-bezier(0.16, 1, 0.3, 1);
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .sidebar-brand {
                padding: 18px 16px;
            }
            .sidebar-close-btn {
                display: flex;
            }
            .main-wrapper {
                margin-left: 0;
                width: 100%;
                min-width: 0;
            }
            .mobile-menu-btn {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 44px;
                height: 44px;
                border-radius: 12px;
                font-size: 24px;
                color: var(--text-main);
                background: rgba(13, 148, 136, 0.08);
                border: 1px solid rgba(13, 148, 136, 0.15);
                cursor: pointer;
            }
            .topbar {
                height: 62px;
                padding: 0 16px;
                padding-left: max(16px, env(safe-area-inset-left, 0px));
                padding-right: max(16px, env(safe-area-inset-right, 0px));
            }
            .topbar-left {
                gap: 12px;
                flex: 1;
                min-width: 0;
            }
            .page-title-box {
                min-width: 0;
                flex: 1;
            }
            .page-title {
                font-size: 16.5px;
                font-weight: 700;
                line-height: 1.25;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .page-breadcrumb {
                font-size: 11.5px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .content-body {
                padding: 18px 16px calc(86px + env(safe-area-inset-bottom, 0px)) 16px !important;
            }
            .app-footer {
                padding: 16px 16px calc(86px + env(safe-area-inset-bottom, 0px)) 16px;
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
            .mobile-bottom-nav {
                display: flex;
                height: calc(64px + env(safe-area-inset-bottom, 0px));
                padding-bottom: max(6px, env(safe-area-inset-bottom, 0px));
            }
            .back-to-top-btn {
                bottom: calc(78px + env(safe-area-inset-bottom, 0px)) !important;
                right: 16px;
                width: 42px;
                height: 42px;
                font-size: 18px;
            }

            /* Collapse multi-column split layouts to 1 column on tablet portrait */
            div[style*="grid-template-columns: 3fr 2fr"],
            div[style*="grid-template-columns: 2fr 1fr"],
            div[style*="grid-template-columns: 1fr 2fr"],
            div[style*="grid-template-columns: 1fr 1fr 1fr"],
            div[style*="grid-template-columns: repeat(3, 1fr)"],
            div[style*="grid-template-columns: repeat(3,1fr)"] {
                grid-template-columns: 1fr !important;
                gap: 16px !important;
            }

            /* Charts grid stack on tablet */
            .charts-grid {
                grid-template-columns: 1fr !important;
                gap: 18px !important;
            }

            /* Custom modals size nicely on tablet */
            .custom-modal-dialog {
                width: 95% !important;
                max-width: 720px !important;
            }
        }

        /* Tablet Floating Dock Navigation (768px - 992px) */
        @media (min-width: 768px) and (max-width: 992px) {
            .mobile-bottom-nav {
                max-width: 560px;
                left: 50%;
                transform: translateX(-50%);
                border-radius: 20px;
                bottom: 12px;
                border: 1px solid rgba(226, 232, 240, 0.95);
                box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
            }
        }

        /* ==========================================================================
           3. MOBILE PHONES STANDARD (< 768px)
           iPhone (Safari), Android (Chrome, Samsung Internet), HarmonyOS
           ========================================================================== */
        @media (max-width: 768px) {
            /* PREVENT IOS SAFARI AUTO-ZOOM ON FORM INPUT FOCUS (Mandatory 16px) */
            input[type="text"],
            input[type="password"],
            input[type="email"],
            input[type="number"],
            input[type="search"],
            input[type="tel"],
            input[type="url"],
            input[type="date"],
            input[type="datetime-local"],
            input[type="month"],
            input[type="time"],
            select,
            textarea,
            .form-control,
            .form-select,
            select.form-control {
                font-size: 16px !important;
                height: 44px !important;
                min-height: 44px !important;
            }

            textarea,
            textarea.form-control {
                height: auto !important;
                min-height: 84px !important;
            }

            .topbar {
                height: 58px;
                padding: 0 12px;
                padding-left: max(12px, env(safe-area-inset-left, 0px));
                padding-right: max(12px, env(safe-area-inset-right, 0px));
            }
            .topbar-right {
                gap: 6px;
            }
            .topbar-btn {
                padding: 8px 10px;
                font-size: 13px;
                height: 40px;
                border-radius: 10px;
                min-width: 40px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }
            .topbar-btn span {
                display: none;
            }

            /* Hide redundant topbar action buttons on mobile (accessible in bottom nav) */
            .topbar-action-desktop-only {
                display: none !important;
            }

            .page-title {
                font-size: 15px;
                max-width: none !important;
            }
            .page-breadcrumb {
                display: none;
            }

            .content-body {
                padding: 12px 10px calc(88px + env(safe-area-inset-bottom, 0px)) 10px !important;
            }

            /* Cards & Padding Modernization for Mobile */
            .card {
                border-radius: 14px !important;
                margin-bottom: 14px !important;
            }
            .card-header {
                padding: 12px 14px !important;
                flex-wrap: wrap !important;
                gap: 8px !important;
            }
            .card-title {
                font-size: 15px !important;
            }
            .card-body {
                padding: 14px 12px !important;
            }

            /* Normalize desktop-sized padding containers on mobile */
            .content-container {
                padding-left: 0 !important;
                padding-right: 0 !important;
            }
            div[style*="padding: 28px 32px"],
            div[style*="padding: 32px"],
            div[style*="padding: 24px 28px"],
            div[style*="padding: 24px"],
            div[style*="padding: 22px"] {
                padding: 14px 12px !important;
            }
            div[style*="padding: 18px 24px"] {
                padding: 12px 10px !important;
            }

            /* Collapse 2-column, 3-column, and 4-column grids on mobile */
            div[style*="grid-template-columns: 1fr 1fr"],
            div[style*="grid-template-columns: 1fr 1fr 1fr"],
            div[style*="grid-template-columns: repeat(2, 1fr)"],
            div[style*="grid-template-columns: repeat(2,1fr)"],
            div[style*="grid-template-columns: repeat(3, 1fr)"],
            div[style*="grid-template-columns: repeat(3,1fr)"],
            div[style*="grid-template-columns: repeat(4, 1fr)"],
            div[style*="grid-template-columns: repeat(4,1fr)"] {
                grid-template-columns: 1fr !important;
                gap: 12px !important;
            }

            /* Collapse wide minmax CSS grids to prevent horizontal overflow blowout */
            div[style*="repeat(auto-fit, minmax(220px"],
            div[style*="repeat(auto-fit, minmax(240px"],
            div[style*="repeat(auto-fit, minmax(260px"],
            div[style*="repeat(auto-fit, minmax(280px"],
            div[style*="repeat(auto-fit, minmax(300px"],
            div[style*="repeat(auto-fit, minmax(320px"],
            div[style*="repeat(auto-fit, minmax(340px"],
            div[style*="repeat(auto-fit, minmax(360px"],
            div[style*="repeat(auto-fill, minmax(220px"],
            div[style*="repeat(auto-fill, minmax(240px"],
            div[style*="repeat(auto-fill, minmax(280px"],
            div[style*="repeat(auto-fill, minmax(290px"],
            div[style*="repeat(auto-fill, minmax(300px"] {
                grid-template-columns: 1fr !important;
                gap: 12px !important;
            }

            /* Table styling for mobile touch readability */
            .table th, .table td {
                padding: 9px 8px !important;
                font-size: 12px !important;
            }

            /* Universal Custom Modal Responsiveness */
            .custom-modal-backdrop {
                padding: 8px !important;
                align-items: flex-start !important;
            }
            .custom-modal-dialog {
                width: 100% !important;
                max-width: 100% !important;
                max-height: calc(100dvh - 16px) !important;
                max-height: calc(100vh - 16px) !important;
                border-radius: 16px !important;
                margin: 8px auto !important;
            }
            .custom-modal-dialog > div:first-child {
                padding: 12px 14px !important;
            }
            .custom-modal-dialog > div:nth-child(2) {
                padding: 12px 14px !important;
                max-height: calc(100dvh - 128px) !important;
                overflow-y: auto !important;
            }
            .custom-modal-dialog > div:last-child {
                padding: 12px 14px !important;
            }

            /* Version Modal Card Full Width */
            .version-modal-card {
                width: 100% !important;
                max-width: 100% !important;
                max-height: calc(100dvh - 20px) !important;
                border-radius: 16px !important;
                margin: 8px auto !important;
            }

            /* SweetAlert Mobile Responsiveness */
            .swal2-popup {
                width: 92% !important;
                max-width: 390px !important;
                padding: 18px 14px !important;
                border-radius: 18px !important;
            }
            .swal2-actions {
                flex-direction: column-reverse !important;
                gap: 8px !important;
                width: 100% !important;
            }
            .swal2-actions button {
                width: 100% !important;
                margin: 0 !important;
                min-height: 44px !important;
                font-size: 14px !important;
            }

            /* Comfortable tap target size */
            .btn {
                min-height: 42px;
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }
            .btn-sm {
                min-height: 38px;
                padding: 6px 12px;
            }

            /* Action button groups inside table cells */
            .table td .btn-group,
            .table td div[style*="display: flex"] {
                flex-wrap: nowrap;
                gap: 4px;
            }
        }

        /* ==========================================================================
           4. SMALL MOBILE PHONES (< 480px)
           iPhone SE, iPhone mini, small Android devices (320px - 414px)
           ========================================================================== */
        @media (max-width: 480px) {
            .content-body {
                padding: 10px 8px calc(90px + env(safe-area-inset-bottom, 0px)) 8px !important;
            }
            .card-header {
                padding: 10px 12px !important;
            }
            .card-body {
                padding: 12px 10px !important;
            }

            /* Stack all form grids into a clean single column */
            .form-row, .row,
            div[style*="repeat(auto-fit, minmax"] {
                grid-template-columns: 1fr !important;
                gap: 10px !important;
            }

            /* Action Buttons inside forms and filters */
            .card-footer,
            div[style*="display: flex; justify-content: flex-end"],
            div[style*="display: flex; justify-content: space-between"] {
                flex-wrap: wrap !important;
                gap: 8px !important;
            }

            .btn {
                min-height: 42px;
                padding: 8px 12px;
                font-size: 13.5px;
            }
            .btn-sm {
                min-height: 36px;
                padding: 6px 10px;
                font-size: 12px;
            }

            /* Mobile Action pills inside bottom nav */
            .mobile-action-pill span {
                font-size: 10px !important;
            }
            .mobile-action-pill i {
                font-size: 14px !important;
            }
            .mobile-bottom-nav-item span {
                font-size: 9px !important;
            }
            .mobile-bottom-nav-item i {
                font-size: 17px !important;
            }
            .mobile-bottom-nav-item .mobile-nav-badge {
                right: calc(50% - 14px);
                font-size: 8.5px;
            }

            /* Topbar Compact */
            .topbar {
                height: 54px;
                padding: 0 10px;
            }
            .page-title {
                font-size: 14px;
            }
        }

        /* ==========================================================================
           5. MOBILE LANDSCAPE ORIENTATION (Short Height Screens)
           ========================================================================== */
        @media (max-height: 540px) and (orientation: landscape) {
            .topbar {
                height: 50px;
            }
            .custom-modal-dialog {
                max-height: calc(100vh - 16px) !important;
            }
            .custom-modal-dialog > div:nth-child(2) {
                max-height: calc(100vh - 100px) !important;
            }
            .mobile-bottom-nav {
                height: calc(52px + env(safe-area-inset-bottom, 0px));
            }
            .mobile-bottom-nav-item {
                min-height: 40px;
            }
            .mobile-action-pill {
                height: 38px;
            }
        }

        /* Print Style */
        @media print {
            .sidebar, .topbar, .app-footer, .no-print, .btn, .back-to-top-btn, .global-progress-bar, .mobile-bottom-nav {
                display: none !important;
            }
            .main-wrapper {
                margin-left: 0 !important;
                width: 100% !important;
            }
            .content-body {
                padding: 0 !important;
            }
            .card {
                border: none !important;
                box-shadow: none !important;
            }
        }
    </style>
    @stack('styles')
</head>
<body>
    <!-- Global Top Loading Progress Bar (Linear SPA Feeling) -->
    <div class="global-progress-bar" id="globalProgressBar"></div>

    <!-- Mobile Sidebar Backdrop (Glassmorphism Blur) -->
    <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="toggleSidebar()"></div>

    <!-- Floating Back to Top Button -->
    <button type="button" id="backToTopBtn" class="back-to-top-btn" onclick="scrollToTop()" title="กลับสู่ด้านบน" aria-label="กลับสู่ด้านบน">
        <i class="bi bi-chevron-up"></i>
    </button>

    <div class="app-container">
        <!-- Sidebar Navigation -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-brand">
                <div class="brand-icon">
                    <i class="bi bi-hospital"></i>
                </div>
                <div>
                    <div class="brand-title">{{ setting('department_name', 'กลุ่มงานสุขภาพดิจิทัล') }}</div>
                    <div class="brand-subtitle">{{ setting('hospital_name_th', 'โรงพยาบาลทุ่งหัวช้าง') }}</div>
                </div>
                <button type="button" class="sidebar-close-btn" onclick="toggleSidebar(false)" aria-label="ปิดเมนู">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>

            <nav class="sidebar-nav">
                <div class="nav-section-title">เมนูหลัก (Main Menu)</div>
                <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') || request()->is('/') ? 'active' : '' }}">
                    <i class="bi bi-speedometer2"></i>
                    <span>แดชบอร์ดภาพรวม</span>
                </a>
                <a href="{{ route('repairs.index') }}" class="nav-item {{ request()->routeIs('repairs.*') ? 'active' : '' }}">
                    <i class="bi bi-tools"></i>
                    <span>ระบบแจ้งซ่อมบำรุง</span>
                    @php
                        $navPendingRepairs = \App\Models\Repair::where('status', 'pending')->count();
                    @endphp
                    @if($navPendingRepairs > 0)
                        <span class="nav-badge" style="background: #ef4444;" title="{{ $navPendingRepairs }} งานซ่อมรอดำเนินการ">{{ $navPendingRepairs }}</span>
                    @endif
                </a>
                <a href="{{ route('data-requests.index') }}" class="nav-item {{ request()->routeIs('data-requests.index') || request()->routeIs('data-requests.show') || request()->routeIs('data-requests.edit') ? 'active' : '' }}">
                    <i class="bi bi-file-earmark-bar-graph"></i>
                    <span>ขอข้อมูลสารสนเทศ & สถิติ</span>
                    @php
                        $navPendingDr = \App\Models\DataRequest::where('status', 'pending')->count();
                    @endphp
                    @if($navPendingDr > 0)
                        <span class="nav-badge" title="{{ $navPendingDr }} คำขอข้อมูลรอพิจารณา">{{ $navPendingDr }}</span>
                    @endif
                </a>
                <a href="{{ Route::has('asset-borrows.index') ? route('asset-borrows.index') : url('/asset-borrows') }}" class="nav-item {{ request()->routeIs('asset-borrows.*') || request()->is('asset-borrows*') ? 'active' : '' }}">
                    <i class="bi bi-arrow-left-right"></i>
                    <span>ขอยืม-คืนอุปกรณ์ IT</span>
                    @php
                        $navPendingBorrows = \App\Models\AssetBorrow::where('status', 'pending')->count();
                    @endphp
                    @if($navPendingBorrows > 0)
                        <span class="nav-badge" style="background: #0284c7;" title="{{ $navPendingBorrows }} คำขอยืมรออนุมัติ">{{ $navPendingBorrows }}</span>
                    @endif
                </a>

                <div class="nav-section-title">คลังและพัสดุ (Inventory)</div>
                <a href="{{ route('assets.index') }}" class="nav-item {{ request()->routeIs('assets.*') && !request()->routeIs('asset-transfers.*') ? 'active' : '' }}">
                    <i class="bi bi-pc-display"></i>
                    <span>คลังคอมพิวเตอร์ & ครุภัณฑ์</span>
                </a>
                <a href="{{ Route::has('asset-transfers.index') ? route('asset-transfers.index') : url('/asset-transfers') }}" class="nav-item {{ request()->routeIs('asset-transfers.*') || request()->is('asset-transfers*') ? 'active' : '' }}">
                    <i class="bi bi-arrows-move"></i>
                    <span>ย้ายจุดติดตั้งครุภัณฑ์</span>
                    @php
                        $navPendingTransfers = \App\Models\AssetTransfer::where('status', 'pending')->count();
                    @endphp
                    @if($navPendingTransfers > 0)
                        <span class="nav-badge" style="background: #7c3aed;" title="{{ $navPendingTransfers }} รายการรอย้าย">{{ $navPendingTransfers }}</span>
                    @endif
                </a>
                @if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isTechnician()))
                <a href="{{ Route::has('hardware-audits.index') ? route('hardware-audits.index') : url('/hardware-audits') }}" class="nav-item {{ request()->routeIs('hardware-audits.*') || request()->is('hardware-audits*') ? 'active' : '' }}">
                    <i class="bi bi-cpu-fill"></i>
                    <span>ติดตามสเปค & ตรวจนับรายปี</span>
                    @php
                        $navPendingHwAudits = \App\Models\HardwareAudit::where('status', 'pending')->count();
                    @endphp
                    @if($navPendingHwAudits > 0)
                        <span class="nav-badge" style="background: #f59e0b;" title="{{ $navPendingHwAudits }} รายการรออนุมัติสเปค">{{ $navPendingHwAudits }}</span>
                    @endif
                </a>
                @endif
                @if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isTechnician()))
                <a href="{{ route('spare-parts.index') }}" class="nav-item {{ request()->routeIs('spare-parts.*') ? 'active' : '' }}">
                    <i class="bi bi-box-seam"></i>
                    <span>คลังอะไหล่ & พัสดุ IT</span>
                </a>
                @endif

                <div class="nav-section-title">รายงานและสถิติ (Reports)</div>
                @if(auth()->check() && (auth()->user()->isAdmin() || auth()->user()->isTechnician()))
                <a href="{{ route('reports.monthly') }}" class="nav-item {{ request()->routeIs('reports.monthly') ? 'active' : '' }}">
                    <i class="bi bi-calendar-month"></i>
                    <span>รายงานสรุปประจำเดือน</span>
                </a>
                <a href="{{ route('reports.quarterly') }}" class="nav-item {{ request()->routeIs('reports.quarterly') ? 'active' : '' }}">
                    <i class="bi bi-pie-chart"></i>
                    <span>รายงานสรุปประจำไตรมาส</span>
                </a>
                @endif
                <a href="{{ route('reports.assets') }}" class="nav-item {{ request()->routeIs('reports.assets') ? 'active' : '' }}">
                    <i class="bi bi-clipboard-data"></i>
                    <span>รายงานสถานะครุภัณฑ์</span>
                </a>

                @if(auth()->check() && auth()->user()->isAdmin())
                <div class="nav-section-title">แอดมินระบบ (Admin)</div>
                <a href="{{ route('settings.index') }}" class="nav-item {{ request()->routeIs('settings.index') ? 'active' : '' }}">
                    <i class="bi bi-sliders"></i>
                    <span>การตั้งค่าระบบ</span>
                </a>
                <a href="{{ route('system-reset.index') }}" class="nav-item {{ request()->routeIs('system-reset.*') || request()->routeIs('settings.data-management') ? 'active' : '' }}" style="color: #fca5a5;">
                    <i class="bi bi-radioactive" style="color: #ef4444;"></i>
                    <span>จัดการข้อมูล & ล้างระบบ</span>
                </a>
                <a href="{{ route('backups.index') }}" class="nav-item {{ request()->routeIs('backups.*') ? 'active' : '' }}">
                    <i class="bi bi-database-gear"></i>
                    <span>สำรอง & กู้คืนฐานข้อมูล</span>
                </a>
                <a href="{{ route('users.index') }}" class="nav-item {{ request()->routeIs('users.*') ? 'active' : '' }}">
                    <i class="bi bi-people"></i>
                    <span>ผู้ใช้งาน, สิทธิ์ & MFA</span>
                </a>
                <a href="{{ route('departments.index') }}" class="nav-item {{ request()->routeIs('departments.*') ? 'active' : '' }}">
                    <i class="bi bi-diagram-3"></i>
                    <span>แผนกในโรงพยาบาล</span>
                </a>
                <a href="{{ route('device-types.index') }}" class="nav-item {{ request()->routeIs('device-types.*') ? 'active' : '' }}">
                    <i class="bi bi-hdd-network"></i>
                    <span>ประเภทอุปกรณ์</span>
                </a>
                <a href="{{ route('budget-sources.index') }}" class="nav-item {{ request()->routeIs('budget-sources.*') ? 'active' : '' }}">
                    <i class="bi bi-cash-coin"></i>
                    <span>แหล่งเงินงบประมาณ</span>
                </a>
                <a href="{{ route('acquisition-methods.index') }}" class="nav-item {{ request()->routeIs('acquisition-methods.*') ? 'active' : '' }}">
                    <i class="bi bi-box-seam"></i>
                    <span>วิธีการได้มาของครุภัณฑ์</span>
                </a>
                <a href="{{ route('audit-logs.index') }}" class="nav-item {{ request()->routeIs('audit-logs.*') ? 'active' : '' }}">
                    <i class="bi bi-shield-check"></i>
                    <span>บันทึกกิจกรรมระบบ (Audit Log)</span>
                </a>
                <a href="{{ route('system-updates.index') }}" class="nav-item {{ request()->routeIs('system-updates.*') ? 'active' : '' }}">
                    <i class="bi bi-cloud-arrow-down"></i>
                    <span>อัปเดตระบบ (System Update)</span>
                </a>
                @endif

                <div class="nav-section-title">เอกสารและคู่มือ</div>
                <a href="{{ url('/manuals') }}" class="nav-item {{ request()->is('manuals*') || request()->is('docs*') ? 'active' : '' }}">
                    <i class="bi bi-book"></i>
                    <span>คู่มือการใช้งาน (PDF)</span>
                </a>
            </nav>

            <div class="sidebar-footer">
                @auth
                <div class="user-widget">
                    <div class="user-avatar">
                        @if(auth()->user()->avatar && file_exists(public_path(auth()->user()->avatar)))
                            <img src="{{ asset(auth()->user()->avatar) }}" alt="{{ auth()->user()->name }}">
                        @else
                            {{ mb_substr(auth()->user()->name, 0, 1, 'UTF-8') }}
                        @endif
                    </div>
                    <div class="user-info">
                        <div class="user-name">{{ auth()->user()->name }}</div>
                        <div class="user-role-badge">{{ auth()->user()->role_name }}</div>
                    </div>
                </div>
                @endauth

                <div style="margin-top: 12px; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: space-between;">
                    <button type="button" onclick="openVersionModal()" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); color: #94a3b8; font-size: 11px; padding: 3px 8px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 5px; transition: all 0.2s;" onmouseover="this.style.color='#ffffff'; this.style.borderColor='var(--primary)';" onmouseout="this.style.color='#94a3b8'; this.style.borderColor='rgba(255,255,255,0.12)';" title="คลิกดูประวัติการอัปเดตระบบ">
                        <i class="bi bi-tag-fill" style="color: var(--primary);"></i>
                        <span>v{{ app_version() }}</span>
                        <i class="bi bi-info-circle ms-1" style="font-size: 10px; opacity: 0.7;"></i>
                    </button>
                    <span style="font-size: 10px; color: #64748b;">THC IT Platform</span>
                </div>
            </div>
        </aside>

        <!-- Main Wrapper -->
        <div class="main-wrapper">
            <!-- Top Navbar -->
            <header class="topbar no-print">
                <div class="topbar-left">
                    <button class="mobile-menu-btn" onclick="toggleSidebar()">
                        <i class="bi bi-list"></i>
                    </button>
                    <div class="page-title-box">
                        <h1 class="page-title">@yield('page_title', 'ระบบบริหารจัดการสารสนเทศ')</h1>
                        <span class="page-breadcrumb">@yield('page_subtitle', setting('department_name', 'กลุ่มงานสุขภาพดิจิทัล') . ' ' . setting('hospital_name_th', 'โรงพยาบาลทุ่งหัวช้าง'))</span>
                    </div>
                </div>
                <div class="topbar-right">
                    @hasSection('topbar-actions')
                        @yield('topbar-actions')
                    @else
                        <a href="{{ route('repairs.create') }}" class="topbar-btn topbar-btn-primary topbar-action-desktop-only" title="แจ้งซ่อมอุปกรณ์หรือปัญหาไอที">
                            <i class="bi bi-plus-lg"></i>
                            <span>แจ้งซ่อมด่วน</span>
                        </a>
                        <a href="{{ Route::has('asset-borrows.create') ? route('asset-borrows.create') : url('/asset-borrows/create') }}" class="topbar-btn topbar-action-desktop-only" style="background: rgba(14, 165, 233, 0.1); color: #0284c7; border: 1px solid rgba(14, 165, 233, 0.28);" title="ยื่นคำขอยืมอุปกรณ์คอมพิวเตอร์และพัสดุ IT">
                            <i class="bi bi-arrow-left-right"></i>
                            <span>ขอยืมอุปกรณ์</span>
                        </a>
                        <a href="{{ route('data-requests.create') }}" class="topbar-btn topbar-btn-secondary topbar-action-desktop-only" title="ยื่นคำขอข้อมูลสารสนเทศและสถิติ">
                            <i class="bi bi-plus-lg"></i>
                            <span>ขอข้อมูล</span>
                        </a>
                    @endif

                    @auth
                    <a href="{{ route('profile') }}" class="topbar-btn" title="แก้ไขข้อมูลส่วนตัว">
                        <i class="bi bi-person-circle"></i>
                        <span>โปรไฟล์</span>
                    </a>

                    <form action="{{ route('logout') }}" method="POST" style="display: inline;" id="logout-form">
                        @csrf
                        <button type="button" class="topbar-btn" onclick="confirmLogout()" title="ออกจากระบบ">
                            <i class="bi bi-box-arrow-right"></i>
                            <span>ออก</span>
                        </button>
                    </form>
                    @endauth
                </div>
            </header>

            <!-- Main Body -->
            <main class="content-body">
                <!-- Flash Alerts -->
                @if(session('success'))
                <div class="alert-box alert-success" id="flashSuccessAlert">
                    <i class="bi bi-check-circle-fill" style="font-size: 18px;"></i>
                    <div style="flex: 1;">{{ session('success') }}</div>
                    <button type="button" class="alert-dismiss-btn" onclick="dismissAlert(this)" title="ปิดการแจ้งเตือน" aria-label="Close">&times;</button>
                </div>
                @endif

                @if(session('error'))
                <div class="alert-box alert-error" id="flashErrorAlert">
                    <i class="bi bi-exclamation-triangle-fill" style="font-size: 18px;"></i>
                    <div style="flex: 1;">{{ session('error') }}</div>
                    <button type="button" class="alert-dismiss-btn" onclick="dismissAlert(this)" title="ปิดการแจ้งเตือน" aria-label="Close">&times;</button>
                </div>
                @endif

                @if(session('warning'))
                <div class="alert-box alert-warning" id="flashWarningAlert">
                    <i class="bi bi-exclamation-circle-fill" style="font-size: 18px;"></i>
                    <div style="flex: 1;">{{ session('warning') }}</div>
                    <button type="button" class="alert-dismiss-btn" onclick="dismissAlert(this)" title="ปิดการแจ้งเตือน" aria-label="Close">&times;</button>
                </div>
                @endif

                @if(session('info'))
                <div class="alert-box alert-info" id="flashInfoAlert">
                    <i class="bi bi-info-circle-fill" style="font-size: 18px;"></i>
                    <div style="flex: 1;">{{ session('info') }}</div>
                    <button type="button" class="alert-dismiss-btn" onclick="dismissAlert(this)" title="ปิดการแจ้งเตือน" aria-label="Close">&times;</button>
                </div>
                @endif

                @yield('content')
            </main>

            <!-- Footer -->
            <footer class="app-footer no-print">
                <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                    <strong>{{ setting('department_name', 'กลุ่มงานสุขภาพดิจิทัล') }}</strong> {{ setting('hospital_name_th', 'โรงพยาบาลทุ่งหัวช้าง') }} &bull; {{ setting('hospital_name_en', 'Thung Hua Chang Hospital') }} Digital Health IT
                    <button type="button" onclick="openVersionModal()" style="background: #e2e8f0; border: none; font-size: 11px; padding: 2px 8px; border-radius: 12px; color: #475569; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; transition: all 0.2s;" onmouseover="this.style.background='#0d9488'; this.style.color='#ffffff';" onmouseout="this.style.background='#e2e8f0'; this.style.color='#475569';" title="คลิกเพื่อดูบันทึกการอัปเดตรุ่นระบบ">
                        <i class="bi bi-tag-fill"></i> v{{ app_version() }}
                    </button>
                </div>
                <div>
                    เชื่อมต่อฐานข้อมูล MariaDB: <code>{{ config('database.connections.mysql.host') }}</code> ({{ config('database.connections.mysql.database') }})
                </div>
            </footer>
        </div>
    </div>

    <!-- Mobile Bottom Application Navigation Bar (ออกแบบใหม่ ไร้ปุ่มกลม นูน พร้อมปุ่มแจ้งซ่อม & ขอข้อมูล) -->
    <nav class="mobile-bottom-nav no-print" aria-label="แถบนำทางสำหรับมือถือ">
        <a href="{{ route('dashboard') }}" class="mobile-bottom-nav-item {{ request()->routeIs('dashboard') || request()->is('/') ? 'active' : '' }}" title="แดชบอร์ดภาพรวม">
            <i class="bi bi-speedometer2"></i>
            <span>แดชบอร์ด</span>
        </a>
        <a href="{{ route('repairs.index') }}" class="mobile-bottom-nav-item {{ (request()->routeIs('repairs.index') || request()->routeIs('repairs.show')) && !request()->routeIs('repairs.create') ? 'active' : '' }}" title="ติดตามสถานะงานซ่อม">
            <i class="bi bi-clock-history"></i>
            <span>งานซ่อม</span>
            @if(!empty($navPendingRepairs) && $navPendingRepairs > 0)
                <span class="mobile-nav-badge">{{ $navPendingRepairs }}</span>
            @endif
        </a>
        <a href="{{ route('repairs.create') }}" class="mobile-bottom-nav-item mobile-nav-action-wrapper" title="สร้างรายการแจ้งซ่อม / แจ้งปัญหาไอที">
            <div class="mobile-action-pill pill-repair {{ request()->routeIs('repairs.create') ? 'active-pill' : '' }}">
                <i class="bi bi-tools"></i>
                <span>แจ้งซ่อม</span>
            </div>
        </a>
        <a href="{{ route('data-requests.create') }}" class="mobile-bottom-nav-item mobile-nav-action-wrapper" title="สร้างคำขอข้อมูลสารสนเทศ / รายงานและสถิติ">
            <div class="mobile-action-pill pill-data {{ request()->routeIs('data-requests.create') ? 'active-pill' : '' }}">
                <i class="bi bi-file-earmark-plus-fill"></i>
                <span>ขอข้อมูล</span>
            </div>
        </a>
        <a href="javascript:void(0)" onclick="toggleSidebar()" class="mobile-bottom-nav-item" title="เปิดเมนูระบบทั้งหมด">
            <i class="bi bi-grid-fill"></i>
            <span>เมนู</span>
        </a>
    </nav>

    <!-- System Version & Changelog Modal -->
    @php
        $globalVersionInfo = app_version_info();
    @endphp
    <div id="versionModal" class="version-modal-overlay" onclick="handleVersionModalBackdrop(event)">
        <div class="version-modal-card">
            <!-- Modal Header -->
            <div style="padding: 20px 24px; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: white; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1);">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(13, 148, 136, 0.3); border: 1px solid rgba(13, 148, 136, 0.5); display: flex; align-items: center; justify-content: center; font-size: 20px; color: #5eead4;">
                        <i class="bi bi-tag-fill"></i>
                    </div>
                    <div>
                        <div style="font-size: 16px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
                            <span>{{ $globalVersionInfo['release_name'] }}</span>
                            <span style="background: #10b981; color: white; font-size: 11px; padding: 2px 8px; border-radius: 12px; font-weight: 600;">v{{ $globalVersionInfo['version'] }}</span>
                        </div>
                        <div style="font-size: 12px; color: #94a3b8; margin-top: 2px;">
                            Build: {{ $globalVersionInfo['build'] }} &bull; เผยแพร่เมื่อ: {{ $globalVersionInfo['release_date'] }}
                        </div>
                    </div>
                </div>
                <button type="button" onclick="closeVersionModal()" style="background: rgba(255,255,255,0.1); border: none; color: white; width: 32px; height: 32px; border-radius: 8px; font-size: 18px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.2)'" onmouseout="this.style.background='rgba(255,255,255,0.1)'">
                    <i class="bi bi-x"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div style="padding: 24px; overflow-y: auto; max-height: calc(88vh - 140px);">
                <!-- System Specs Grid -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin-bottom: 24px;">
                    <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 10px; padding: 10px 14px; text-align: center;">
                        <div style="font-size: 11px; color: #64748b;">เวอร์ชันระบบ</div>
                        <div style="font-size: 15px; font-weight: 700; color: #0f172a; margin-top: 2px;">v{{ $globalVersionInfo['version'] }}</div>
                    </div>
                    <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 10px; padding: 10px 14px; text-align: center;">
                        <div style="font-size: 11px; color: #64748b;">PHP Engine</div>
                        <div style="font-size: 15px; font-weight: 700; color: #0284c7; margin-top: 2px;">PHP {{ $globalVersionInfo['php_version'] }}</div>
                    </div>
                    <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 10px; padding: 10px 14px; text-align: center;">
                        <div style="font-size: 11px; color: #64748b;">Laravel Framework</div>
                        <div style="font-size: 15px; font-weight: 700; color: #ef4444; margin-top: 2px;">v{{ $globalVersionInfo['laravel_version'] }}</div>
                    </div>
                    <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 10px; padding: 10px 14px; text-align: center;">
                        <div style="font-size: 11px; color: #64748b;">สภาพแวดล้อม</div>
                        <div style="font-size: 15px; font-weight: 700; color: #10b981; margin-top: 2px;">{{ ucfirst($globalVersionInfo['environment']) }}</div>
                    </div>
                </div>

                <!-- Changelog Timeline -->
                <div style="font-size: 14px; font-weight: 700; color: #0f172a; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
                    <i class="bi bi-clock-history text-primary"></i>
                    <span>ประวัติและบันทึกการอัปเดตระบบ (Release Notes & Changelog)</span>
                </div>

                <div style="display: flex; flex-direction: column; gap: 16px;">
                    @foreach($globalVersionInfo['changelog'] as $ver => $log)
                    <div style="background: #ffffff; border: 1px solid {{ $loop->first ? '#0d9488' : 'var(--border)' }}; border-radius: 12px; padding: 16px; box-shadow: {{ $loop->first ? '0 4px 12px rgba(13, 148, 136, 0.08)' : '0 1px 3px rgba(0,0,0,0.02)' }};">
                        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-bottom: 8px;">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span style="font-size: 15px; font-weight: 700; color: #0f172a;">v{{ $ver }}</span>
                                <span style="background: {{ $log['badge_color'] ?? '#64748b' }}; color: white; font-size: 10.5px; padding: 2px 8px; border-radius: 10px; font-weight: 600;">
                                    {{ $log['badge'] ?? 'Release' }}
                                </span>
                            </div>
                            <span style="font-size: 12px; color: #64748b;">
                                <i class="bi bi-calendar3"></i> {{ $log['date'] }}
                            </span>
                        </div>
                        <div style="font-size: 13.5px; font-weight: 600; color: #1e293b; margin-bottom: 8px;">
                            {{ $log['title'] }}
                        </div>
                        <ul style="margin: 0; padding-left: 20px; font-size: 12.5px; color: #475569; line-height: 1.6;">
                            @foreach($log['highlights'] as $item)
                            <li>{{ $item }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endforeach
                </div>
            </div>

            <!-- Modal Footer -->
            <div style="padding: 14px 24px; background: #f8fafc; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
                @if(auth()->check() && auth()->user()->isSuperAdmin())
                <div style="display: flex; align-items: center; gap: 12px;">
                    <a href="{{ route('system-updates.index') }}" style="font-size: 12px; font-weight: 600; text-decoration: none; padding: 5px 12px; background: #0d9488; color: #fff; border-radius: 6px; display: inline-flex; align-items: center; gap: 6px;">
                        <i class="bi bi-cloud-arrow-down"></i> ตรวจสอบการอัปเดต
                    </a>
                    <a href="{{ route('settings.index') }}#version" class="text-primary" style="font-size: 12px; text-decoration: none; font-weight: 600; display: inline-flex; align-items: center; gap: 4px;">
                        <i class="bi bi-sliders"></i> จัดการเวอร์ชัน &rarr;
                    </a>
                </div>
                @else
                <div style="font-size: 12px; color: #64748b;">โรงพยาบาลทุ่งหัวช้าง &bull; Digital Health Division</div>
                @endif
                <button type="button" onclick="closeVersionModal()" class="topbar-btn" style="padding: 6px 16px; font-size: 12.5px;">
                    ปิดหน้าต่าง
                </button>
            </div>
        </div>
    </div>

    <script>
        // Sidebar Toggle with Mobile Backdrop & Scroll Lock
        function toggleSidebar(forceState) {
            const sidebar = document.getElementById('sidebar');
            const backdrop = document.getElementById('sidebarBackdrop');
            if (!sidebar) return;
            const isShow = typeof forceState === 'boolean' ? forceState : !sidebar.classList.contains('show');
            if (isShow) {
                sidebar.classList.add('show');
                if (backdrop) backdrop.classList.add('show');
                if (window.innerWidth <= 992) {
                    document.body.style.overflow = 'hidden';
                }
            } else {
                sidebar.classList.remove('show');
                if (backdrop) backdrop.classList.remove('show');
                document.body.style.overflow = '';
            }
        }

        // Mobile & Tablet Touch Swipe Gestures (Swipe Left to Close, Swipe Right from Left Edge to Open)
        (function() {
            let touchStartX = 0;
            let touchStartY = 0;
            let touchEndX = 0;
            let touchEndY = 0;

            document.addEventListener('touchstart', function(e) {
                if (e.touches && e.touches.length === 1) {
                    touchStartX = e.touches[0].clientX;
                    touchStartY = e.touches[0].clientY;
                }
            }, { passive: true });

            document.addEventListener('touchend', function(e) {
                if (e.changedTouches && e.changedTouches.length === 1) {
                    touchEndX = e.changedTouches[0].clientX;
                    touchEndY = e.changedTouches[0].clientY;
                    handleSwipe();
                }
            }, { passive: true });

            function handleSwipe() {
                const diffX = touchEndX - touchStartX;
                const diffY = touchEndY - touchStartY;
                if (Math.abs(diffX) > Math.abs(diffY) * 1.5 && Math.abs(diffX) > 60) {
                    const sidebar = document.getElementById('sidebar');
                    const isOpen = sidebar && sidebar.classList.contains('show');
                    if (diffX < -50 && isOpen) {
                        toggleSidebar(false);
                    } else if (diffX > 60 && !isOpen && touchStartX < 35 && window.innerWidth <= 992) {
                        toggleSidebar(true);
                    }
                }
            }
        })();

        // Version Modal Controls
        function openVersionModal() {
            document.getElementById('versionModal').classList.add('active');
        }

        function closeVersionModal() {
            document.getElementById('versionModal').classList.remove('active');
        }

        function handleVersionModalBackdrop(e) {
            if (e.target.id === 'versionModal') {
                closeVersionModal();
            }
        }

        // Dismiss Flash Alerts Smoothly
        function dismissAlert(btn) {
            const box = btn.closest('.alert-box');
            if (box) {
                box.classList.add('dismissed');
                setTimeout(() => { box.remove(); }, 260);
            }
        }

        // Floating Back to Top Button
        function scrollToTop() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        window.addEventListener('scroll', function() {
            const btn = document.getElementById('backToTopBtn');
            if (btn) {
                if (window.scrollY > 240) {
                    btn.classList.add('show');
                } else {
                    btn.classList.remove('show');
                }
            }
        }, { passive: true });

        // Global Keydown (Escape key handlers)
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeVersionModal();
                toggleSidebar(false);
            }
        });

        function confirmLogout() {
            Swal.fire({
                title: 'ยืนยันการออกจากระบบ?',
                text: "คุณต้องการออกจากระบบการใช้งานใช่หรือไม่",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#0d9488',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'ออกจากระบบ',
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('logout-form').submit();
                }
            });
        }

        function changePerPage(val) {
            const url = new URL(window.location.href);
            url.searchParams.set('per_page', val);
            url.searchParams.set('page', 1);
            if (window.ProgressBar) window.ProgressBar.start();
            window.location.href = url.toString();
        }

        // Global Top Loading Progress Bar Controller (Linear SPA Feeling)
        const ProgressBar = {
            bar: null,
            timer: null,
            init: function() {
                this.bar = document.getElementById('globalProgressBar');
                this.bindEvents();
            },
            start: function() {
                if (!this.bar) return;
                clearTimeout(this.timer);
                this.bar.classList.remove('finished');
                this.bar.classList.add('active');
                this.bar.style.width = '28%';
                
                this.timer = setTimeout(() => {
                    if (this.bar && this.bar.classList.contains('active')) {
                        this.bar.style.width = '72%';
                        this.timer = setTimeout(() => {
                            if (this.bar && this.bar.classList.contains('active')) {
                                this.bar.style.width = '88%';
                            }
                        }, 280);
                    }
                }, 90);
            },
            finish: function() {
                if (!this.bar) return;
                clearTimeout(this.timer);
                this.bar.style.width = '100%';
                this.bar.classList.add('finished');
                setTimeout(() => {
                    if (this.bar) {
                        this.bar.classList.remove('active', 'finished');
                        this.bar.style.width = '0%';
                    }
                }, 350);
            },
            bindEvents: function() {
                // On internal navigation link clicks
                document.addEventListener('click', function(e) {
                    const link = e.target.closest('a');
                    if (!link) return;
                    const href = link.getAttribute('href');
                    if (!href || href.startsWith('#') || href.startsWith('javascript:') || link.getAttribute('target') === '_blank' || link.hasAttribute('download') || link.getAttribute('role') === 'button') {
                        return;
                    }
                    if (link.getAttribute('onclick') && (link.getAttribute('onclick').includes('Modal') || link.getAttribute('onclick').includes('toggleSidebar'))) {
                        return;
                    }
                    ProgressBar.start();
                });

                // On form submission
                document.addEventListener('submit', function(e) {
                    const form = e.target;
                    if (form.hasAttribute('data-no-progress')) return;
                    
                    if (typeof form.checkValidity === 'function' && !form.checkValidity()) {
                        return;
                    }

                    ProgressBar.start();

                    // Add smooth loading spinner to submit button to prevent double-clicks
                    const submitBtn = form.querySelector('button[type="submit"]:not([data-no-loading]), input[type="submit"]:not([data-no-loading])');
                    if (submitBtn && !submitBtn.classList.contains('btn-is-loading')) {
                        submitBtn.classList.add('btn-is-loading');
                        const spinner = document.createElement('span');
                        spinner.className = 'btn-spinner';
                        spinner.style.marginRight = '6px';
                        submitBtn.prepend(spinner);
                    }
                });
            }
        };

        window.ProgressBar = ProgressBar;

        // Auto initialize on DOM readiness
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => ProgressBar.init());
        } else {
            ProgressBar.init();
        }
        window.addEventListener('pageshow', (e) => { if (e.persisted) ProgressBar.finish(); });
        window.addEventListener('load', () => ProgressBar.finish());
    </script>
    @stack('scripts')
</body>
</html>
