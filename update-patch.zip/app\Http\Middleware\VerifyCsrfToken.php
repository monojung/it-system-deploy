<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array<int, string>
     */
    protected $except = [
        'system-updates/apply',
        'system-updates/upload-patch',
        'api/hardware-audit/*',
        'hardware-audit/submit',
        'hardware-audit/agent-command*',
        'api/hardware-audit/agent-command*',
    ];
}
