@extends('layouts.app')

@section('title', 'รายละเอียดครุภัณฑ์ ' . $asset->asset_code)
@section('page_title', 'ข้อมูลครุภัณฑ์: ' . $asset->asset_code)
@section('page_subtitle', $asset->name . ' - ' . ($asset->department?->name ?? 'ไม่ระบุแผนก'))

@section('content')
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
    <div style="display: flex; align-items: center; gap: 10px;">
        <a href="{{ route('assets.index') }}" class="btn btn-secondary btn-sm">
            <i class="bi bi-arrow-left"></i> ทะเบียนครุภัณฑ์
        </a>
        <span class="badge {{ $asset->status_badge }}" style="font-size: 13px; padding: 6px 14px;">
            {{ $asset->status_label }}
        </span>
    </div>

    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <a href="{{ route('repairs.create', ['asset_id' => $asset->id]) }}" class="btn btn-primary">
            <i class="bi bi-wrench"></i>
            <span>แจ้งซ่อมเครื่องนี้</span>
        </a>
        @if($asset->status === 'borrowed' && $asset->currentBorrow)
        <a href="{{ Route::has('asset-borrows.show') ? route('asset-borrows.show', $asset->currentBorrow->id) : url('/asset-borrows/' . $asset->currentBorrow->id) }}" class="btn btn-warning" style="color: #78350f; font-weight: 600;">
            <i class="bi bi-arrow-left-right"></i>
            <span>ดูรายการยืมปัจจุบัน</span>
        </a>
        @else
        <a href="{{ Route::has('asset-borrows.create') ? route('asset-borrows.create', ['asset_id' => $asset->id]) : url('/asset-borrows/create?asset_id=' . $asset->id) }}" class="btn btn-primary" style="background: linear-gradient(135deg, #4f46e5 0%, #4338ca 100%); border-color: #4338ca;">
            <i class="bi bi-box-arrow-right"></i>
            <span>ขอยืมอุปกรณ์นี้</span>
        </a>
        @endif
        <a href="{{ route('asset-transfers.create', ['asset_id' => $asset->id]) }}" class="btn btn-secondary" style="background: #f5f3ff; color: #7c3aed; border-color: #ddd6fe;" title="บันทึกหรือยื่นคำขอย้ายจุดติดตั้งครุภัณฑ์นี้">
            <i class="bi bi-arrows-move"></i>
            <span>ย้ายจุดติดตั้ง</span>
        </a>
        <a href="{{ route('assets.label', $asset) }}" target="_blank" class="btn btn-secondary">
            <i class="bi bi-qr-code"></i>
            <span>พิมพ์สติกเกอร์ QR</span>
        </a>
        @if(auth()->user()->isAdmin() || auth()->user()->isTechnician())
        <a href="{{ route('assets.edit', $asset) }}" class="btn btn-secondary">
            <i class="bi bi-pencil"></i>
            <span>แก้ไข</span>
        </a>
        <button type="button" class="btn btn-danger" onclick="openDeleteModal('{{ $asset->id }}', '{{ addslashes($asset->asset_code) }}', '{{ addslashes($asset->name) }}', '{{ addslashes($asset->brand . ' ' . $asset->model) }}', '{{ addslashes($asset->department?->name ?? 'ไม่ระบุแผนก') }}', '{{ addslashes($asset->deviceType?->name ?? '-') }}', '{{ addslashes($asset->status_label) }}', '{{ $asset->status_badge }}', {{ (int)$asset->repairs_count }})">
            <i class="bi bi-trash3"></i>
            <span>ลบครุภัณฑ์</span>
        </button>
        @endif
    </div>
</div>

@if($asset->status === 'borrowed' && $asset->currentBorrow)
<div style="background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); border: 1.5px solid #f59e0b; border-radius: 14px; padding: 16px 20px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.12);">
    <div style="display: flex; align-items: center; gap: 14px;">
        <div style="width: 44px; height: 44px; border-radius: 12px; background: #f59e0b; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0; box-shadow: 0 2px 8px rgba(245, 158, 11, 0.3);">
            <i class="bi bi-arrow-left-right"></i>
        </div>
        <div>
            <div style="font-weight: 800; font-size: 15px; color: #92400e; display: flex; align-items: center; gap: 8px;">
                <span>อุปกรณ์นี้กำลังถูกยืมใช้งาน</span>
                <span class="badge" style="background: #fbbf24; color: #78350f; font-size: 11px;">รหัสคำขอ: {{ $asset->currentBorrow->borrow_no }}</span>
                @if($asset->currentBorrow->is_overdue)
                    <span class="badge bg-danger">เกินกำหนดส่งคืน</span>
                @endif
            </div>
            <div style="font-size: 13px; color: #78350f; margin-top: 3px;">
                ผู้ยืม: <strong>{{ $asset->currentBorrow->borrower_name }}</strong> 
                ({{ $asset->currentBorrow->department?->name ?? $asset->currentBorrow->borrower_department ?? 'ไม่ระบุแผนก' }}) 
                • เบอร์โทร: {{ $asset->currentBorrow->contact_phone }}
                • กำหนดส่งคืน: <strong>{{ $asset->currentBorrow->expected_return_date ? $asset->currentBorrow->expected_return_date->format('d/m/Y') : 'ไม่ระบุ' }}</strong>
            </div>
        </div>
    </div>
    <a href="{{ Route::has('asset-borrows.show') ? route('asset-borrows.show', $asset->currentBorrow->id) : url('/asset-borrows/' . $asset->currentBorrow->id) }}" class="btn btn-sm btn-warning" style="color: #78350f; font-weight: 700; border-color: #d97706; padding: 7px 16px;">
        <i class="bi bi-eye"></i> ดูใบยืม-คืน #{{ $asset->currentBorrow->borrow_no }}
    </a>
</div>
@endif

@if($asset->is_rented)
<div style="background: linear-gradient(135deg, #fffaf5 0%, #fff7ed 100%); border: 1.5px solid #fdba74; border-radius: 14px; padding: 18px 22px; margin-bottom: 24px; box-shadow: 0 4px 14px rgba(234, 88, 12, 0.08);">
    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 14px; border-bottom: 1px dashed #fed7aa; padding-bottom: 12px;">
        <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 44px; height: 44px; border-radius: 12px; background: #ffedd5; color: #ea580c; display: flex; align-items: center; justify-content: center; font-size: 22px; border: 1px solid #fdba74; flex-shrink: 0;">
                <i class="bi bi-printer-fill"></i>
            </div>
            <div>
                <div style="font-weight: 800; font-size: 15px; color: #9a3412; display: flex; align-items: center; gap: 8px;">
                    <span>สัญญาเช่าครุภัณฑ์ / เครื่องพิมพ์เช่า (Lease / Rental Contract)</span>
                    <span class="badge {{ $asset->rental_status_badge }}">{{ $asset->rental_status_label }}</span>
                </div>
                <div style="font-size: 12.5px; color: #c2410c; margin-top: 2px;">
                    เลขที่สัญญา: <strong>{{ $asset->rental_contract_no ?: 'ไม่ระบุเลขที่สัญญา' }}</strong>
                    • ผู้ให้เช่า: <strong>{{ $asset->rental_vendor ?: 'ไม่ระบุคู่สัญญา' }}</strong>
                </div>
            </div>
        </div>
        @if($asset->rental_monthly_fee)
        <div style="text-align: right;">
            <div style="font-size: 11px; color: #9a3412;">ค่าเช่ารายเดือน</div>
            <div style="font-size: 18px; font-weight: 800; color: #ea580c;">{{ number_format($asset->rental_monthly_fee, 2) }} <span style="font-size: 12px; font-weight: 500;">บ./ด.</span></div>
        </div>
        @endif
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; font-size: 13px;">
        <div>
            <span style="color: #9a3412; font-size: 11.5px; display: block;">ระยะเวลาสัญญาเช่า:</span>
            <strong>{{ $asset->rental_start_date ? $asset->rental_start_date->format('d/m/Y') : '-' }}</strong> ถึง 
            <strong>{{ $asset->rental_end_date ? $asset->rental_end_date->format('d/m/Y') : '-' }}</strong>
        </div>
        <div>
            <span style="color: #9a3412; font-size: 11.5px; display: block;">เบอร์ติดต่อบริษัท/ช่าง:</span>
            @if($asset->rental_contact_phone)
                <a href="tel:{{ $asset->rental_contact_phone }}" style="color: #ea580c; font-weight: 700; text-decoration: none;">
                    <i class="bi bi-telephone-fill me-1"></i> {{ $asset->rental_contact_phone }}
                </a>
            @else
                <span style="color: #94a3b8;">-</span>
            @endif
        </div>
        @if($asset->rental_conditions)
        <div style="grid-column: 1 / -1; margin-top: 6px; background: rgba(255,255,255,0.6); padding: 8px 12px; border-radius: 8px; border: 1px solid #ffedd5;">
            <span style="color: #9a3412; font-size: 11.5px; font-weight: 700; display: block; margin-bottom: 2px;">เงื่อนไขสัญญาเช่าและบริการ:</span>
            <span style="color: #7c2d12;">{{ $asset->rental_conditions }}</span>
        </div>
        @endif
    </div>
</div>
@endif

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 24px;">
    <!-- Asset Info Card -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <i class="bi bi-info-circle text-primary"></i>
                <span>ข้อมูลจำเพาะครุภัณฑ์ (Specifications)</span>
            </div>
            <span style="font-family: monospace; font-weight: 700; color: #0284c7; font-size: 15px;">
                {{ $asset->asset_code }}
            </span>
        </div>
        <div class="card-body">
            <h2 style="font-size: 20px; font-weight: 700; margin-bottom: 6px; color: var(--text-main);">
                {{ $asset->name }}
            </h2>
            <div style="font-size: 14px; color: var(--text-muted); margin-bottom: 20px;">
                {{ $asset->brand }} {{ $asset->model }} &bull; ประเภท: {{ $asset->deviceType?->name }}
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 20px;">
                <div style="background: #f8fafc; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--border);">
                    <div style="font-size: 12px; color: var(--text-muted);">Serial Number (S/N)</div>
                    <div style="font-weight: 600; font-family: monospace; font-size: 14px; margin-top: 2px;">
                        {{ $asset->serial_number ?? '-' }}
                    </div>
                </div>

                <div style="background: #fdf4ff; padding: 12px 16px; border-radius: 8px; border: 1px solid #f0abfc;">
                    <div style="font-size: 12px; color: #a21caf; font-weight: 600; display: flex; align-items: center; justify-content: space-between;">
                        <span><i class="bi bi-fingerprint me-1"></i> HardwareID (UUID)</span>
                        @if($asset->hardware_id)
                            <button type="button" class="btn btn-link p-0 text-decoration-none" onclick="navigator.clipboard.writeText('{{ $asset->hardware_id }}'); if (window.Swal) Swal.fire({toast:true, position:'top-end', icon:'success', title:'คัดลอก HardwareID แล้ว', showConfirmButton:false, timer:1500});" title="คัดลอก HardwareID">
                                <i class="bi bi-clipboard" style="font-size: 12px; color: #a21caf;"></i>
                            </button>
                        @endif
                    </div>
                    <div style="font-weight: 600; font-family: monospace; font-size: 13px; margin-top: 2px; color: #701a75; word-break: break-all;">
                        {{ $asset->hardware_id ?? '-' }}
                    </div>
                </div>

                <div style="background: #f8fafc; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--border);">
                    <div style="font-size: 12px; color: var(--text-muted);">IP Address</div>
                    <div style="font-weight: 600; font-family: monospace; font-size: 14px; margin-top: 2px;">
                        {{ $asset->ip_address ?? '-' }}
                    </div>
                </div>

                <div style="background: #f8fafc; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--border);">
                    <div style="font-size: 12px; color: var(--text-muted);">MAC Address</div>
                    <div style="font-weight: 600; font-family: monospace; font-size: 13.5px; margin-top: 2px;">
                        {{ $asset->mac_address ?? '-' }}
                    </div>
                </div>

                <div style="background: #f8fafc; padding: 12px 16px; border-radius: 8px; border: 1px solid var(--border);">
                    <div style="font-size: 12px; color: var(--text-muted);">ปีงบประมาณจัดซื้อ</div>
                    <div style="font-weight: 600; font-size: 14px; margin-top: 2px;">
                        {{ $asset->budget_year ?? '-' }}
                    </div>
                </div>

                <div style="background: {{ $asset->last_audited_fiscal_year ? '#f0fdf4' : '#fffbeb' }}; padding: 12px 16px; border-radius: 8px; border: 1px solid {{ $asset->last_audited_fiscal_year ? '#bbf7d0' : '#fde68a' }};">
                    <div style="font-size: 12px; color: {{ $asset->last_audited_fiscal_year ? '#166534' : '#92400e' }}; font-weight: 600; display: flex; align-items: center; justify-content: space-between;">
                        <span>ตรวจนับสเปครายปี</span>
                        @if($asset->last_audited_fiscal_year)
                            <span class="badge badge-success" style="font-size: 10px; padding: 2px 6px;">ตรวจแล้ว</span>
                        @else
                            <span class="badge badge-warning" style="font-size: 10px; padding: 2px 6px;">ยังไม่ตรวจ</span>
                        @endif
                    </div>
                    <div style="font-weight: 700; font-size: 13.5px; margin-top: 2px; color: {{ $asset->last_audited_fiscal_year ? '#15803d' : '#b45309' }};">
                        @if($asset->last_audited_fiscal_year)
                            ปีงบฯ {{ $asset->last_audited_fiscal_year }}
                            <small style="font-size: 11px; font-weight: 400; display: block; color: #4b5563;">({{ $asset->last_audited_at?->format('d/m/Y') }})</small>
                        @else
                            รอตรวจนับปี {{ $currentFiscalYear ?? (now()->month >= 10 ? now()->year + 544 : now()->year + 543) }}
                        @endif
                    </div>
                </div>
            </div>

            @if(isset($pendingAuditForAsset) && $pendingAuditForAsset)
            <!-- Pending Hardware Audit Banner -->
            <div style="background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%); border: 1.5px solid #f59e0b; border-radius: 12px; padding: 14px 18px; margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.12);">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 40px; height: 40px; border-radius: 10px; background: #fde68a; color: #b45309; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0;">
                        <i class="bi bi-bell-fill"></i>
                    </div>
                    <div>
                        <div style="font-weight: 700; font-size: 14.5px; color: #92400e; display: flex; align-items: center; gap: 8px;">
                            <span>มีผลการสแกนสเปคใหม่รอแอดมินอนุมัติ</span>
                            <span class="badge" style="background: #f59e0b; color: #fff; font-size: 11px;">ปีงบ {{ $pendingAuditForAsset->fiscal_year }}</span>
                        </div>
                        <div style="font-size: 12.5px; color: #78350f; margin-top: 2px;">
                            ส่งจากเครื่องโฮสต์: <strong>{{ $pendingAuditForAsset->hostname }}</strong> เมื่อ {{ $pendingAuditForAsset->created_at->format('d/m/Y H:i') }} น.
                            @if($pendingAuditForAsset->hasDiff())
                                &bull; <span style="color: #b45309; font-weight: 700;">ตรวจพบการเปลี่ยนแปลงของสเปค (Diff Detected)</span>
                            @endif
                        </div>
                    </div>
                </div>
                <a href="{{ route('hardware-audits.index', ['fiscal_year' => $pendingAuditForAsset->fiscal_year, 'search' => $asset->serial_number ?: $asset->asset_code]) }}" class="btn btn-warning btn-sm" style="font-weight: 600; padding: 7px 16px; border-radius: 8px; display: inline-flex; align-items: center; gap: 6px;">
                    <i class="bi bi-check2-circle"></i>
                    <span>ตรวจสอบและกดอนุมัติสเปค</span>
                </a>
            </div>
            @endif

            <!-- Hardware Specs Detailed Grid -->
            <div style="margin-bottom: 24px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
                    <div style="font-weight: 700; font-size: 14.5px; color: var(--text-main); display: flex; align-items: center; gap: 8px;">
                        <i class="bi bi-cpu-fill text-primary" style="font-size: 18px;"></i>
                        <span>รายละเอียดคุณลักษณะและสเปคเครื่อง (Hardware Specs)</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                        @if($asset->is_computer)
                            <span class="badge badge-info" style="font-size: 11.5px; padding: 4px 10px;">
                                <i class="bi bi-pc-display me-1"></i> คอมพิวเตอร์ประมวลผล
                            </span>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="copyAssetAgentCmd('{{ $asset->asset_code }}')" title="คัดลอกคำสั่งสแกนเครื่องนี้ไปรันบน PowerShell" style="font-size: 12px; padding: 3px 10px; display: inline-flex; align-items: center; gap: 4px;">
                                <i class="bi bi-terminal"></i> สแกน/อัปเดตสเปค (UTF-8)
                            </button>
                        @endif
                    </div>
                </div>

                @if($asset->cpu_model || $asset->ram_capacity || $asset->os_name || $asset->storage_capacity)
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin-bottom: 14px;">
                        {{-- 1. CPU Processor --}}
                        <div style="background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 12px; padding: 14px; position: relative;">
                            <div style="font-size: 11.5px; font-weight: 700; color: #0284c7; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 5px; margin-bottom: 6px;">
                                <i class="bi bi-cpu"></i> หน่วยประมวลผล (CPU)
                            </div>
                            <div style="font-weight: 700; font-size: 15px; color: #0c4a6e; line-height: 1.3;">
                                {{ $asset->cpu_model ?: 'ไม่ระบุ' }}
                            </div>
                            @if($asset->cpu_speed)
                                <div style="font-size: 12px; color: #0369a1; margin-top: 4px;">
                                    <i class="bi bi-speedometer2 me-1"></i> {{ $asset->cpu_speed }}
                                </div>
                            @endif
                            @if($asset->cpu_model)
                                <div style="margin-top: 10px; border-top: 1px dashed #bae6fd; padding-top: 6px;">
                                    <a href="{{ route('assets.index', ['cpu' => explode(' ', $asset->cpu_model)[2] ?? $asset->cpu_model]) }}" style="font-size: 11px; color: #0284c7; text-decoration: none; font-weight: 600;">
                                        <i class="bi bi-search me-1"></i> ค้นหาเครื่อง CPU นี้
                                    </a>
                                </div>
                            @endif
                        </div>

                        {{-- 2. RAM Memory --}}
                        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 14px; position: relative;">
                            <div style="font-size: 11.5px; font-weight: 700; color: #16a34a; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 5px; margin-bottom: 6px;">
                                <i class="bi bi-memory"></i> หน่วยความจำ (RAM)
                            </div>
                            <div style="font-weight: 700; font-size: 15px; color: #14532d; line-height: 1.3;">
                                {{ $asset->ram_capacity ? $asset->ram_capacity . ' GB' : '-' }}
                                @if($asset->ram_type)
                                    <span class="badge" style="background: #dcfce7; color: #15803d; border: 1px solid #86efac; font-size: 11px; margin-left: 4px;">
                                        {{ $asset->ram_type }}
                                    </span>
                                @endif
                            </div>
                            <div style="font-size: 12px; color: #15803d; margin-top: 4px;">
                                @if($asset->ram_bus) <span>{{ $asset->ram_bus }}</span> @endif
                                @if($asset->ram_slots) <span>• {{ $asset->ram_slots }}</span> @endif
                            </div>
                            @if($asset->ram_type)
                                <div style="margin-top: 10px; border-top: 1px dashed #bbf7d0; padding-top: 6px;">
                                    <a href="{{ route('assets.index', ['ram_type' => $asset->ram_type]) }}" style="font-size: 11px; color: #16a34a; text-decoration: none; font-weight: 600;">
                                        <i class="bi bi-search me-1"></i> ค้นหาเครื่องที่ใช้ {{ $asset->ram_type }}
                                    </a>
                                </div>
                            @endif
                        </div>

                        {{-- 3. Storage Drive --}}
                        <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 12px; padding: 14px; position: relative;">
                            <div style="font-size: 11.5px; font-weight: 700; color: #9333ea; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 5px; margin-bottom: 6px;">
                                <i class="bi bi-device-hdd"></i> ไดรฟ์เก็บข้อมูล (Storage)
                            </div>
                            <div style="font-weight: 700; font-size: 15px; color: #581c87; line-height: 1.3;">
                                {{ $asset->storage_capacity ?: '-' }}
                            </div>
                            <div style="font-size: 12px; color: #7e22ce; margin-top: 4px;">
                                {{ $asset->storage_type ?: 'ฮาร์ดดิสก์/ไดรฟ์' }}
                                @if($asset->storage_second)
                                    <div style="font-size: 11px; margin-top: 2px; color: #6b21a8;">+ {{ $asset->storage_second }}</div>
                                @endif
                            </div>
                            @if($asset->storage_type)
                                <div style="margin-top: 10px; border-top: 1px dashed #e9d5ff; padding-top: 6px;">
                                    <a href="{{ route('assets.index', ['storage_type' => $asset->storage_type]) }}" style="font-size: 11px; color: #9333ea; text-decoration: none; font-weight: 600;">
                                        <i class="bi bi-search me-1"></i> ค้นหาเครื่องชนิดไดรฟ์นี้
                                    </a>
                                </div>
                            @endif
                        </div>

                        {{-- 4. Operating System (OS) & License --}}
                        <div style="background: #f0fdfa; border: 1px solid #99f6e4; border-radius: 12px; padding: 14px; position: relative;">
                            <div style="font-size: 11.5px; font-weight: 700; color: #0d9488; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 5px; margin-bottom: 6px;">
                                <i class="bi bi-windows"></i> ระบบปฏิบัติการ (OS)
                            </div>
                            <div style="font-weight: 700; font-size: 15px; color: #134e4a; line-height: 1.3;">
                                {{ $asset->os_name ?: 'ไม่ระบุ OS' }}
                            </div>
                            @if($asset->os_license)
                                <div style="font-size: 12px; color: #0f766e; margin-top: 4px;">
                                    <i class="bi bi-patch-check me-1"></i> {{ $asset->os_license }}
                                </div>
                            @endif
                            @if($asset->os_name)
                                <div style="margin-top: 10px; border-top: 1px dashed #99f6e4; padding-top: 6px;">
                                    <a href="{{ route('assets.index', ['os' => $asset->os_name]) }}" style="font-size: 11px; color: #0d9488; text-decoration: none; font-weight: 600;">
                                        <i class="bi bi-search me-1"></i> ค้นหาเครื่องที่ใช้ {{ $asset->os_name }}
                                    </a>
                                </div>
                            @endif
                        </div>
                    </div>

                    {{-- Graphics & Monitor Secondary Details --}}
                    @if($asset->gpu_model || $asset->monitor_size)
                        <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 8px; padding: 10px 14px; margin-bottom: 12px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; font-size: 13px;">
                            @if($asset->gpu_model)
                                <div>
                                    <strong style="color: #475569;"><i class="bi bi-gpu-card text-primary me-1"></i> การ์ดแสดงผล:</strong>
                                    <span>{{ $asset->gpu_model }}</span>
                                </div>
                            @endif
                            @if($asset->monitor_size)
                                <div>
                                    <strong style="color: #475569;"><i class="bi bi-display text-info me-1"></i> ขนาดจอภาพ:</strong>
                                    <span>{{ $asset->monitor_size }}</span>
                                </div>
                            @endif
                        </div>
                    @endif
                @endif

                {{-- Full Specs / Remarks Text --}}
                @if($asset->specs)
                    <div style="background: #ffffff; border: 1px solid var(--border); border-radius: 8px; padding: 12px 14px; font-size: 13.5px; line-height: 1.5; color: #334155;">
                        <div style="font-size: 12px; font-weight: 600; color: #64748b; margin-bottom: 4px;">รายละเอียดสเปคเพิ่มเติม:</div>
                        <div style="white-space: pre-line;">{{ $asset->specs }}</div>
                    </div>
                @elseif(!$asset->cpu_model && !$asset->ram_capacity)
                    <div style="background: #ffffff; border: 1px solid var(--border); border-radius: 8px; padding: 14px; font-size: 14px; color: var(--text-muted);">
                        ไม่มีข้อมูลสเปคฮาร์ดแวร์เพิ่มเติม
                    </div>
                @endif
            </div>

            @if($asset->notes)
            <div>
                <div style="font-weight: 600; font-size: 13.5px; color: var(--text-main); margin-bottom: 4px;">หมายเหตุ:</div>
                <div style="font-size: 13px; color: var(--text-muted);">{{ $asset->notes }}</div>
            </div>
            @endif
        </div>
    </div>

    <!-- Right Side: Location, Custodian, Financial -->
    <div>
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="bi bi-geo-alt text-danger"></i>
                    <span>สถานที่ตั้ง & ผู้ครอบครอง</span>
                </div>
            </div>
            <div class="card-body">
                <div style="margin-bottom: 16px;">
                    <div style="font-size: 12px; color: var(--text-muted);">แผนก / หน่วยงาน:</div>
                    <div style="font-weight: 600; font-size: 14.5px;">{{ $asset->department?->name ?? 'ไม่ระบุ' }}</div>
                    <div style="font-size: 12px; color: #64748b;">{{ $asset->department?->building }}</div>
                </div>

                <div style="margin-bottom: 16px;">
                    <div style="font-size: 12px; color: var(--text-muted);">จุดที่ตั้ง / ห้องทำงาน:</div>
                    <div style="font-weight: 600; font-size: 14px;">{{ $asset->location_detail ?? '-' }}</div>
                </div>

                <div style="margin-bottom: 16px;">
                    <div style="font-size: 12px; color: var(--text-muted);">ผู้ครอบครอง / ผู้ดูแลเครื่อง:</div>
                    <div style="font-weight: 600; font-size: 14px; color: #0f766e;">{{ $asset->custodian_name ?? '-' }}</div>
                </div>

                <hr style="border: none; border-top: 1px solid var(--border); margin: 16px 0;">

                <div style="margin-bottom: 12px;">
                    <div style="font-size: 12px; color: var(--text-muted);">กรรมสิทธิ์ / การครอบครอง:</div>
                    <div style="margin-top: 3px;">
                        <span class="badge {{ $asset->ownership_badge }}" style="font-size: 12px; padding: 4px 10px;">
                            {{ $asset->ownership_label }}
                        </span>
                    </div>
                </div>

                <div style="margin-bottom: 12px;">
                    <div style="font-size: 12px; color: var(--text-muted);">วิธีการได้มาของครุภัณฑ์:</div>
                    <div style="font-weight: 600; font-size: 13.5px; color: #059669; margin-top: 2px;">
                        <i class="bi bi-box-arrow-in-down-right me-1"></i>
                        {{ $asset->acquisitionMethod?->name ?? 'ไม่ระบุ' }}
                    </div>
                </div>

                <div style="margin-bottom: 12px;">
                    <div style="font-size: 12px; color: var(--text-muted);">แหล่งเงินงบประมาณ / เงินที่ซื้อ:</div>
                    <div style="font-weight: 600; font-size: 13.5px; color: #4338ca; margin-top: 2px;">
                        <i class="bi bi-wallet2 me-1"></i>
                        {{ $asset->budgetSource?->name ?? 'ไม่ระบุ' }}
                    </div>
                </div>

                <div style="margin-bottom: 12px;">
                    <div style="font-size: 12px; color: var(--text-muted);">วันที่จัดซื้อ / ตรวจรับ:</div>
                    <div style="font-weight: 500; font-size: 13.5px;">
                        {{ $asset->purchase_date ? $asset->purchase_date->format('d/m/Y') : '-' }}
                    </div>
                </div>

                <div style="margin-bottom: 12px;">
                    <div style="font-size: 12px; color: var(--text-muted);">ราคาจัดซื้อ:</div>
                    <div style="font-weight: 700; font-size: 15px; color: #0284c7;">
                        {{ $asset->price ? number_format($asset->price, 2) . ' บาท' : '-' }}
                    </div>
                </div>

                <div>
                    <div style="font-size: 12px; color: var(--text-muted);">การรับประกัน (Warranty):</div>
                    @if($asset->warranty_expire_date)
                        @php $isExpired = $asset->warranty_expire_date->isPast(); @endphp
                        <div style="font-weight: 600; font-size: 13.5px; color: {{ $isExpired ? '#dc2626' : '#16a34a' }};">
                            หมดประกัน: {{ $asset->warranty_expire_date->format('d/m/Y') }}
                            <span class="badge {{ $isExpired ? 'badge-danger' : 'badge-success' }}" style="margin-left: 6px;">
                                {{ $isExpired ? 'หมดประกันแล้ว' : 'อยู่ในประกัน' }}
                            </span>
                        </div>
                    @else
                        <div style="font-size: 13px; color: #94a3b8;">ไม่ระบุวันหมดประกัน</div>
                    @endif
                </div>
            </div>
        </div>

        @if($asset->image)
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="bi bi-image"></i>
                    <span>รูปภาพครุภัณฑ์</span>
                </div>
            </div>
            <div class="card-body" style="text-align: center;">
                <img src="{{ asset($asset->image) }}" alt="รูปครุภัณฑ์" style="max-width: 100%; max-height: 240px; border-radius: 8px;">
            </div>
        </div>
        @endif
    </div>
</div>

<!-- Asset Repair History Table -->
<div class="card">
    <div class="card-header">
        <div class="card-title">
            <i class="bi bi-clock-history text-primary"></i>
            <span>ประวัติการแจ้งซ่อมบำรุงของเครื่องนี้ ({{ $asset->repairs->count() }} ครั้ง)</span>
        </div>
        <a href="{{ route('repairs.create', ['asset_id' => $asset->id]) }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle"></i> แจ้งซ่อมเครื่องนี้
        </a>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>เลขที่ใบแจ้งซ่อม</th>
                        <th>อาการเสีย / หัวข้อ</th>
                        <th>ระดับความเร่งด่วน</th>
                        <th>สถานะ</th>
                        <th>ช่างผู้ดำเนินการ</th>
                        <th>ค่าใช้จ่าย (บาท)</th>
                        <th>วันที่แจ้ง</th>
                        <th style="text-align: center;">ดู</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($asset->repairs as $repair)
                    <tr>
                        <td>
                            <a href="{{ route('repairs.show', $repair) }}" style="font-weight: 700; color: var(--primary); text-decoration: none;">
                                {{ $repair->ticket_number }}
                            </a>
                        </td>
                        <td>
                            <div style="font-weight: 600;">{{ $repair->title }}</div>
                            @if($repair->solution)
                            <div style="font-size: 12px; color: #065f46;">วิธีแก้: {{ $repair->solution }}</div>
                            @endif
                        </td>
                        <td>
                            <span class="badge {{ $repair->urgency_badge }}">
                                {{ $repair->urgency_label }}
                            </span>
                        </td>
                        <td>
                            <span class="badge {{ $repair->status_badge }}">
                                {{ $repair->status_label }}
                            </span>
                        </td>
                        <td style="font-size: 13px;">{{ $repair->technician?->name ?? 'รอรับเรื่อง' }}</td>
                        <td style="font-weight: 600;">{{ number_format($repair->total_cost, 2) }}</td>
                        <td style="font-size: 12.5px; color: var(--text-muted);">
                            {{ $repair->created_at->format('d/m/Y') }}
                        </td>
                        <td style="text-align: center;">
                            <a href="{{ route('repairs.show', $repair) }}" class="btn btn-secondary btn-sm">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            ไม่มีประวัติการส่งซ่อมสำหรับครุภัณฑ์นี้ (อุปกรณ์ทำงานปกติ)
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Asset Hardware Audit History Table -->
<div class="card" style="margin-top: 24px;">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div class="card-title">
            <i class="bi bi-cpu-fill text-info"></i>
            <span>ประวัติการตรวจนับและสแกนสเปคจากเครื่องลูกข่าย ({{ $asset->hardwareAudits->count() }} ครั้ง)</span>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            @if($asset->is_computer)
                <button type="button" class="btn btn-primary btn-sm" onclick="copyAssetAgentCmd('{{ $asset->asset_code }}')" style="display: inline-flex; align-items: center; gap: 5px;">
                    <i class="bi bi-terminal-fill"></i> คัดลอกคำสั่งสแกนเครื่องนี้ (UTF-8)
                </button>
            @endif
            <a href="{{ route('hardware-audits.index', ['search' => $asset->serial_number ?: $asset->asset_code]) }}" class="btn btn-secondary btn-sm">
                <i class="bi bi-speedometer2"></i> แดชบอร์ดตรวจนับสเปค
            </a>
        </div>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive">
            <table class="table" style="margin: 0;">
                <thead>
                    <tr>
                        <th>วันที่ส่งข้อมูล</th>
                        <th>ปีงบประมาณ</th>
                        <th>ชื่อโฮสต์ / S/N จาก BIOS</th>
                        <th>สเปคที่ส่งมา (CPU / RAM / Disk / OS)</th>
                        <th>การเปลี่ยนแปลง (Diff)</th>
                        <th>สถานะ</th>
                        <th>ผู้ตรวจอนุมัติ / หมายเหตุ</th>
                        <th style="text-align: center;">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($asset->hardwareAudits as $audit)
                    <tr>
                        <td style="font-size: 12.5px; color: var(--text-muted); white-space: nowrap;">
                            {{ $audit->created_at->format('d/m/Y H:i') }} น.
                        </td>
                        <td>
                            <span class="badge" style="background: #e0f2fe; color: #0369a1; font-weight: 600;">
                                ปีงบ {{ $audit->fiscal_year }}
                            </span>
                        </td>
                        <td>
                            <div style="font-weight: 600; font-family: monospace;">{{ $audit->hostname }}</div>
                            <div style="font-size: 11.5px; color: var(--text-muted); font-family: monospace;">S/N: {{ $audit->serial_number ?: '-' }}</div>
                        </td>
                        <td style="font-size: 12px; max-width: 260px;">
                            <div style="font-weight: 600; color: #0f172a;">{{ $audit->cpu_model ?: '-' }}</div>
                            <div style="color: #475569;">
                                RAM: {{ $audit->ram_capacity ? $audit->ram_capacity . ' GB ' . $audit->ram_type : '-' }} |
                                Disk: {{ $audit->storage_capacity ? $audit->storage_capacity . ' ' . $audit->storage_type : '-' }}
                            </div>
                            <div style="color: #0d9488; font-size: 11.5px;">{{ $audit->os_name ?: '-' }}</div>
                        </td>
                        <td>
                            @if($audit->hasDiff())
                                <span class="badge badge-warning" style="font-size: 11px;">
                                    <i class="bi bi-arrow-left-right me-1"></i> มีการเปลี่ยนสเปค
                                </span>
                            @else
                                <span class="badge badge-secondary" style="font-size: 11px; background: #f1f5f9; color: #64748b;">
                                    ตรงกับฐานข้อมูล
                                </span>
                            @endif
                        </td>
                        <td>
                            <span class="badge {{ $audit->status_badge }}" style="font-size: 11.5px;">
                                {{ $audit->status_label }}
                            </span>
                        </td>
                        <td style="font-size: 12px;">
                            @if($audit->reviewed_by)
                                <div style="color: #0f766e; font-weight: 500;">
                                    <i class="bi bi-check-circle me-1"></i> {{ $audit->reviewer?->name ?? 'แอดมิน' }}
                                </div>
                                <div style="font-size: 11px; color: var(--text-muted);">
                                    {{ $audit->reviewed_at?->format('d/m/Y H:i') }}
                                </div>
                            @elseif($audit->status === 'pending')
                                <span style="color: #b45309; font-weight: 600;">รอแอดมินตรวจสอบ</span>
                            @else
                                <span class="text-muted">-</span>
                            @endif
                            @if($audit->review_notes)
                                <div style="font-size: 11px; color: #64748b; margin-top: 2px;">{{ $audit->review_notes }}</div>
                            @endif
                        </td>
                        <td style="text-align: center; white-space: nowrap;">
                            <a href="{{ route('hardware-audits.index', ['fiscal_year' => $audit->fiscal_year, 'search' => $audit->serial_number ?: $audit->hostname]) }}" class="btn btn-secondary btn-sm" title="เปิดดูในแดชบอร์ด">
                                <i class="bi bi-box-arrow-up-right"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 24px;">
                            ยังไม่มีประวัติการส่งข้อมูลสแกนสเปคจากเครื่องคอมพิวเตอร์นี้
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Asset Borrow History Table -->
<div class="card" style="margin-top: 24px;">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div class="card-title">
            <i class="bi bi-box-arrow-right text-indigo" style="color: #4f46e5;"></i>
            <span>ประวัติการขอยืม-คืนอุปกรณ์นี้ ({{ $asset->borrows->count() }} ครั้ง)</span>
        </div>
        <a href="{{ Route::has('asset-borrows.create') ? route('asset-borrows.create', ['asset_id' => $asset->id]) : url('/asset-borrows/create?asset_id=' . $asset->id) }}" class="btn btn-primary btn-sm" style="background: #4f46e5; border-color: #4f46e5;">
            <i class="bi bi-plus-circle"></i> ทำเรื่องขอยืมอุปกรณ์นี้
        </a>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive">
            <table class="table" style="margin: 0;">
                <thead>
                    <tr>
                        <th>เลขที่ใบยืม</th>
                        <th>ผู้ขอยืม / แผนก</th>
                        <th>วัตถุประสงค์</th>
                        <th>ช่วงเวลาที่ยืม</th>
                        <th>สถานะ</th>
                        <th>วันที่คืนจริง</th>
                        <th style="text-align: center;">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($asset->borrows as $borrow)
                    <tr>
                        <td>
                            <a href="{{ Route::has('asset-borrows.show') ? route('asset-borrows.show', $borrow) : url('/asset-borrows/' . $borrow->id) }}" style="font-weight: 700; color: #4f46e5; text-decoration: none; font-family: monospace;">
                                {{ $borrow->borrow_no }}
                            </a>
                        </td>
                        <td>
                            <div style="font-weight: 600;">{{ $borrow->borrower_name }}</div>
                            <div style="font-size: 12px; color: var(--text-muted);">{{ $borrow->borrower_department }} &bull; {{ $borrow->borrower_phone }}</div>
                        </td>
                        <td style="font-size: 13px; max-width: 250px;">
                            <div style="color: #334155;">{{ Str::limit($borrow->purpose, 60) }}</div>
                            @if($borrow->location_of_use)
                                <div style="font-size: 11.5px; color: #64748b;"><i class="bi bi-geo-alt me-1"></i> {{ $borrow->location_of_use }}</div>
                            @endif
                        </td>
                        <td style="font-size: 12.5px;">
                            <div>{{ $borrow->borrow_date->format('d/m/Y') }} &rarr; {{ $borrow->expected_return_date->format('d/m/Y') }}</div>
                            <div style="font-size: 11px; color: var(--text-muted);">({{ $borrow->borrow_date->diffInDays($borrow->expected_return_date) }} วัน)</div>
                        </td>
                        <td>
                            <span class="badge {{ $borrow->status_badge }}">
                                {{ $borrow->status_label }}
                            </span>
                        </td>
                        <td style="font-size: 12.5px;">
                            @if($borrow->actual_return_date)
                                <span style="color: #16a34a; font-weight: 600;">
                                    <i class="bi bi-check-circle me-1"></i> {{ $borrow->actual_return_date->format('d/m/Y') }}
                                </span>
                            @else
                                <span class="text-muted">-</span>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <a href="{{ Route::has('asset-borrows.show') ? route('asset-borrows.show', $borrow) : url('/asset-borrows/' . $borrow->id) }}" class="btn btn-secondary btn-sm" title="ดูรายละเอียด">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 24px;">
                            ยังไม่มีประวัติการขอยืมครุภัณฑ์ชิ้นนี้
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Asset Relocation & Transfer History Table -->
<div class="card" style="margin-top: 24px;">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div class="card-title">
            <i class="bi bi-arrows-move text-primary" style="color: #7c3aed !important;"></i>
            <span>ประวัติการย้ายจุดติดตั้งและโอนย้ายอุปกรณ์นี้ ({{ $asset->transfers->count() }} ครั้ง)</span>
        </div>
        <a href="{{ route('asset-transfers.create', ['asset_id' => $asset->id]) }}" class="btn btn-primary btn-sm" style="background: #7c3aed; border-color: #7c3aed;">
            <i class="bi bi-plus-circle"></i> บันทึกการย้ายเครื่องนี้
        </a>
    </div>
    <div class="card-body" style="padding: 0;">
        <div class="table-responsive">
            <table class="table" style="margin: 0; vertical-align: middle;">
                <thead>
                    <tr>
                        <th>เลขที่เอกสาร</th>
                        <th>ประเภท</th>
                        <th>การย้ายจุดติดตั้ง (จุดเดิม &rarr; จุดใหม่)</th>
                        <th>ผู้รับผิดชอบใหม่</th>
                        <th>วันที่ย้าย</th>
                        <th>สถานะ</th>
                        <th style="text-align: center;">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($asset->transfers as $transfer)
                    <tr>
                        <td>
                            <a href="{{ route('asset-transfers.show', $transfer) }}" style="font-weight: 700; color: #7c3aed; text-decoration: none; font-family: monospace;">
                                {{ $transfer->transfer_no }}
                            </a>
                        </td>
                        <td>
                            {!! $transfer->transfer_type_badge !!}
                        </td>
                        <td style="font-size: 12.5px;">
                            <div style="display: flex; align-items: center; gap: 6px;">
                                <span style="color: #64748b;">{{ $transfer->fromDepartment?->name ?? $transfer->from_department_name ?? 'ไม่ระบุ' }} ({{ $transfer->from_location_detail ?: '-' }})</span>
                                <i class="bi bi-arrow-right text-muted"></i>
                                <strong style="color: #166534;">{{ $transfer->toDepartment?->name ?? $transfer->to_department_name ?? 'ไม่ระบุ' }} ({{ $transfer->to_location_detail ?: '-' }})</strong>
                            </div>
                        </td>
                        <td style="font-size: 12.5px;">
                            <i class="bi bi-person me-1 text-muted"></i>{{ $transfer->to_custodian_name ?: '-' }}
                        </td>
                        <td style="font-size: 12px; color: #475569; white-space: nowrap;">
                            {{ $transfer->transfer_date ? $transfer->transfer_date->format('d/m/Y') : '-' }}
                        </td>
                        <td style="white-space: nowrap;">
                            {!! $transfer->status_badge !!}
                        </td>
                        <td style="text-align: center; white-space: nowrap;">
                            <a href="{{ route('asset-transfers.show', $transfer) }}" class="btn btn-secondary btn-sm" title="ดูรายละเอียด">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="{{ route('asset-transfers.print', $transfer) }}" target="_blank" class="btn btn-secondary btn-sm" title="พิมพ์ใบย้าย">
                                <i class="bi bi-printer"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 24px;">
                            ยังไม่มีประวัติการย้ายจุดติดตั้งสำหรับครุภัณฑ์นี้ (ติดตั้งอยู่ที่เดิมตั้งแต่ลงทะเบียน)
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Asset Deletion Confirmation Modal -->
<div id="deleteAssetModal" class="custom-modal-backdrop" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(4px); z-index: 1050; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: #ffffff; border-radius: 18px; width: 100%; max-width: 520px; box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2); overflow: hidden; animation: modalScaleIn 0.22s ease-out;">
        {{-- Modal Header --}}
        <div style="background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); padding: 20px 24px; color: #ffffff; display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 14px;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(255, 255, 255, 0.2); display: flex; align-items: center; justify-content: center; font-size: 22px; color: #ffffff; border: 1px solid rgba(255, 255, 255, 0.3);">
                    <i class="bi bi-trash3-fill"></i>
                </div>
                <div>
                    <div style="font-size: 16.5px; font-weight: 700; letter-spacing: -0.2px;">ยืนยันการลบรายการครุภัณฑ์</div>
                    <div style="font-size: 12px; color: rgba(255, 255, 255, 0.85);">Asset Deletion Confirmation & Safety Check</div>
                </div>
            </div>
            <button type="button" onclick="closeDeleteModal()" style="background: transparent; border: none; color: rgba(255, 255, 255, 0.8); font-size: 22px; cursor: pointer;" title="ปิดหน้าต่าง">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        {{-- Modal Body --}}
        <div style="padding: 24px;">
            {{-- Asset Summary Card --}}
            <div style="background: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 20px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
                    <span id="del_asset_code" style="font-family: monospace; font-weight: 700; font-size: 14px; color: #0284c7; background: #e0f2fe; padding: 4px 10px; border-radius: 6px; border: 1px solid #bae6fd;">-</span>
                    <span id="del_asset_status" class="badge badge-secondary">-</span>
                </div>
                <div style="font-weight: 700; font-size: 14.5px; color: #0f172a; margin-bottom: 8px;" id="del_asset_name">-</div>
                <div style="display: flex; font-size: 13px; color: #475569; margin-bottom: 6px; gap: 8px;">
                    <strong style="color: #1e293b; min-width: 90px;">ยี่ห้อ / รุ่น:</strong>
                    <span id="del_asset_brand_model">-</span>
                </div>
                <div style="display: flex; font-size: 13px; color: #475569; margin-bottom: 6px; gap: 8px;">
                    <strong style="color: #1e293b; min-width: 90px;">แผนก / ที่ตั้ง:</strong>
                    <span id="del_asset_dept">-</span>
                </div>
                <div style="display: flex; font-size: 13px; color: #475569; margin-bottom: 0; gap: 8px;">
                    <strong style="color: #1e293b; min-width: 90px;">ประเภท:</strong>
                    <span id="del_asset_type">-</span>
                </div>
            </div>

            {{-- Case 1: Cannot Delete Due to Repair Records --}}
            <div id="del_blocked_section" style="display: none;">
                <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 14px 16px; margin-bottom: 20px;">
                    <div style="display: flex; align-items: flex-start; gap: 10px;">
                        <i class="bi bi-shield-exclamation text-warning" style="font-size: 20px; flex-shrink: 0; margin-top: 1px;"></i>
                        <div>
                            <strong style="color: #92400e; font-size: 14px;">ไม่สามารถลบครุภัณฑ์นี้ได้</strong>
                            <div style="margin-top: 4px; color: #78350f; font-size: 13.5px; line-height: 1.5;">
                                ครุภัณฑ์นี้มีประวัติการแจ้งซ่อมในระบบจำนวน <strong id="del_repair_count_num" style="color: #b45309; font-size: 15px;">0</strong> รายการ เพื่อรักษาประวัติการซ่อมบำรุงตามระเบียบงานสารสนเทศโรงพยาบาล
                            </div>
                            <div style="margin-top: 8px; font-size: 12.5px; color: #92400e; background: rgba(245, 158, 11, 0.12); padding: 8px 12px; border-radius: 8px;">
                                💡 <strong>คำแนะนำ:</strong> หากอุปกรณ์ใช้งานไม่ได้ ท่านสามารถเข้าไป <strong>"แก้ไขข้อมูล"</strong> แล้วเปลี่ยนสถานะเป็น <strong>"ชำรุดรอซ่อม"</strong> หรือ <strong>"รอจำหน่าย/แทงจำหน่าย"</strong> แทนการลบ
                            </div>
                        </div>
                    </div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">
                        ปิดหน้าต่าง
                    </button>
                </div>
            </div>

            {{-- Case 2: Can Delete Safely (0 Repairs) --}}
            <div id="del_allowed_section" style="display: none;">
                <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 10px; padding: 14px 16px; margin-bottom: 20px; color: #991b1b; font-size: 13.5px; line-height: 1.5;">
                    <div style="display: flex; align-items: flex-start; gap: 10px;">
                        <i class="bi bi-exclamation-triangle-fill" style="font-size: 20px; flex-shrink: 0; margin-top: 1px;"></i>
                        <div>
                            <strong style="font-size: 14px;">คำเตือน: ยืนยันการลบถาวร</strong>
                            <div style="margin-top: 4px;">
                                ข้อมูลครุภัณฑ์และประวัติทั้งหมดจะถูกลบออกจากระบบ และไม่สามารถย้อนคืนได้
                            </div>
                            <div style="font-size: 12px; margin-top: 6px; color: #991b1b;">
                                🛡️ ระบบจะทำการบันทึกข้อมูลการลบนี้ลงใน <strong>Audit Log</strong> เพื่อการตรวจสอบย้อนหลัง
                            </div>
                        </div>
                    </div>
                </div>

                <form id="deleteAssetForm" method="POST" action="">
                    @csrf
                    @method('DELETE')
                    <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                        <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">
                            ยกเลิก
                        </button>
                        <button type="submit" class="btn btn-danger" style="box-shadow: 0 4px 12px rgba(220, 38, 38, 0.25);">
                            <i class="bi bi-trash3-fill"></i>
                            <span>ยืนยันลบครุภัณฑ์นี้</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function openDeleteModal(id, code, name, brandModel, dept, type, statusLabel, statusBadge, repairsCount) {
        document.getElementById('del_asset_code').textContent = code;
        document.getElementById('del_asset_name').textContent = name;
        document.getElementById('del_asset_brand_model').textContent = brandModel && brandModel.trim() ? brandModel : '-';
        document.getElementById('del_asset_dept').textContent = dept;
        document.getElementById('del_asset_type').textContent = type;

        const statusElem = document.getElementById('del_asset_status');
        statusElem.textContent = statusLabel;
        statusElem.className = 'badge ' + statusBadge;

        if (repairsCount > 0) {
            document.getElementById('del_repair_count_num').textContent = repairsCount;
            document.getElementById('del_blocked_section').style.display = 'block';
            document.getElementById('del_allowed_section').style.display = 'none';
        } else {
            document.getElementById('deleteAssetForm').action = '{{ url('/assets') }}/' + id;
            document.getElementById('del_blocked_section').style.display = 'none';
            document.getElementById('del_allowed_section').style.display = 'block';
        }

        const modal = document.getElementById('deleteAssetModal');
        modal.style.display = 'flex';
    }

    function closeDeleteModal() {
        const modal = document.getElementById('deleteAssetModal');
        modal.style.display = 'none';
    }

    window.addEventListener('click', function(e) {
        const modal = document.getElementById('deleteAssetModal');
        if (e.target === modal) {
            closeDeleteModal();
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeDeleteModal();
        }
    });

    function copyAssetAgentCmd(assetCode) {
        const cmd = `powershell -ExecutionPolicy Bypass -NoProfile -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; & ([scriptblock]::Create((irm 'https://thchospital.moph.go.th/it-system/agent/thc_audit_agent.ps1'))) -AssetCode '${assetCode}'"`;
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(cmd).then(() => {
                alert('คัดลอกคำสั่งสแกนครุภัณฑ์ ' + assetCode + ' เรียบร้อยแล้ว!\nสามารถนำไปคลิกขวา Paste วางใน PowerShell (Run as Administrator) บนเครื่องเป้าหมายได้ทันที');
            }).catch(() => {
                prompt('กรุณาคัดลอกคำสั่งด้านล่างไปรันใน PowerShell:', cmd);
            });
        } else {
            prompt('กรุณาคัดลอกคำสั่งด้านล่างไปรันใน PowerShell:', cmd);
        }
    }
</script>
@endpush
