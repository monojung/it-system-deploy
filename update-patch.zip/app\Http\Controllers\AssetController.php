<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Asset;
use App\Models\DeviceType;
use App\Models\Department;
use App\Models\BudgetSource;
use App\Models\AcquisitionMethod;
use App\Services\IctStandardCatalog;
use App\Services\ItAssetCodeGeneratorService;
use Carbon\Carbon;

class AssetController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();
        $query = Asset::with(['deviceType', 'department', 'budgetSource', 'acquisitionMethod'])->withCount('repairs');

        // Regular users can only see assets of their own department
        if ($user && $user->isUser()) {
            if ($user->department_id) {
                $query->where('department_id', $user->department_id);
            } else {
                $query->whereRaw('1 = 0');
            }
        } elseif ($request->filled('department_id')) {
            $query->where('department_id', $request->department_id);
        }

        if ($request->filled('device_type_id')) {
            $query->where('device_type_id', $request->device_type_id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('budget_year')) {
            $query->where('budget_year', $request->budget_year);
        }

        // Budget Source (แหล่งเงินที่ใช้ซื้อ)
        if ($request->filled('budget_source_id')) {
            $query->where('budget_source_id', $request->budget_source_id);
        }

        // Acquisition Method (วิธีการได้มาของครุภัณฑ์)
        if ($request->filled('acquisition_method_id')) {
            $query->where('acquisition_method_id', $request->acquisition_method_id);
        }

        // Ownership Type (กรรมสิทธิ์ / เครื่องเช่า / ซื้อขาด / บริจาค / ยืม)
        if ($request->filled('ownership_type')) {
            $query->where('ownership_type', $request->ownership_type);
        }

        // Rental Status Filtering (สำหรับคุมเครื่องเช่า เช่น เครื่องพิมพ์เช่า)
        if ($request->filled('rental_status')) {
            $rStatus = $request->rental_status;
            if ($rStatus === 'expiring_soon') {
                $query->where('ownership_type', 'rented')
                      ->whereNotNull('rental_end_date')
                      ->whereBetween('rental_end_date', [now()->startOfDay(), now()->addDays(30)->endOfDay()]);
            } elseif ($rStatus === 'expired') {
                $query->where('ownership_type', 'rented')
                      ->whereNotNull('rental_end_date')
                      ->where('rental_end_date', '<', now()->startOfDay());
            } elseif ($rStatus === 'active') {
                $query->where('ownership_type', 'rented')
                      ->where(function($q) {
                          $q->whereNull('rental_end_date')
                            ->orWhere('rental_end_date', '>=', now()->startOfDay());
                      });
            } elseif ($rStatus === 'all_rented') {
                $query->where('ownership_type', 'rented');
            }
        }

        // Hardware Specs Filtering
        if ($request->filled('cpu')) {
            $cpu = $request->cpu;
            $query->where('cpu_model', 'like', "%{$cpu}%");
        }

        if ($request->filled('ram_type')) {
            $query->where('ram_type', $request->ram_type);
        }

        if ($request->filled('ram_capacity')) {
            $query->where('ram_capacity', (int)$request->ram_capacity);
        }

        if ($request->filled('os')) {
            $os = $request->os;
            $query->where('os_name', 'like', "%{$os}%");
        }

        if ($request->filled('storage_type')) {
            $query->where('storage_type', 'like', "%{$request->storage_type}%");
        }

        if ($request->filled('storage_capacity')) {
            $query->where('storage_capacity', 'like', "%{$request->storage_capacity}%");
        }

        // Annual Fiscal Year Hardware Audit Filtering
        if ($request->filled('audited_fiscal_year')) {
            $fy = (int)$request->audited_fiscal_year;
            if ($request->input('audit_status') === 'not_audited') {
                $query->where(function ($q) use ($fy) {
                    $q->whereNull('last_audited_fiscal_year')
                      ->orWhere('last_audited_fiscal_year', '<', $fy);
                });
            } else {
                $query->where('last_audited_fiscal_year', $fy);
            }
        } elseif ($request->filled('audit_status')) {
            $calcFY = (now()->month >= 10) ? now()->year + 544 : now()->year + 543;
            if ($request->audit_status === 'audited') {
                $query->where('last_audited_fiscal_year', $calcFY);
            } elseif ($request->audit_status === 'not_audited') {
                $query->where(function ($q) use ($calcFY) {
                    $q->whereNull('last_audited_fiscal_year')
                      ->orWhere('last_audited_fiscal_year', '<', $calcFY);
                });
            }
        }

        if ($request->filled('search')) {
            $search = trim($request->search);
            $cleanSearch = str_replace('-', '', $search);
            $query->where(function ($q) use ($search, $cleanSearch) {
                $q->where('it_code', 'like', "%{$search}%")
                  ->orWhere('it_code', 'like', "%{$cleanSearch}%")
                  ->orWhere('asset_code', 'like', "%{$search}%")
                  ->orWhere('serial_number', 'like', "%{$search}%")
                  ->orWhere('name', 'like', "%{$search}%")
                  ->orWhere('brand', 'like', "%{$search}%")
                  ->orWhere('model', 'like', "%{$search}%")
                  ->orWhere('custodian_name', 'like', "%{$search}%")
                  ->orWhere('location_detail', 'like', "%{$search}%")
                  ->orWhere('ip_address', 'like', "%{$search}%")
                  ->orWhere('mac_address', 'like', "%{$search}%")
                  ->orWhere('specs', 'like', "%{$search}%")
                  ->orWhere('cpu_model', 'like', "%{$search}%")
                  ->orWhere('ram_type', 'like', "%{$search}%")
                  ->orWhere('os_name', 'like', "%{$search}%")
                  ->orWhere('storage_type', 'like', "%{$search}%")
                  ->orWhere('rental_contract_no', 'like', "%{$search}%")
                  ->orWhere('rental_vendor', 'like', "%{$search}%")
                  ->orWhere('notes', 'like', "%{$search}%");

                // รองรับค้นหาด้วยชื่อหรือรหัสย่อของแผนก
                $q->orWhereHas('department', function ($dq) use ($search) {
                    $dq->where('name', 'like', "%{$search}%")
                       ->orWhere('code', 'like', "%{$search}%");
                });

                // รองรับค้นหาด้วยประเภทอุปกรณ์
                $q->orWhereHas('deviceType', function ($dtq) use ($search) {
                    $dtq->where('name', 'like', "%{$search}%")
                       ->orWhere('code', 'like', "%{$search}%");
                });

                // รองรับการค้นหาด้วยรหัสคุมไอที เช่น ER-PC-66-0005, RENT-PRN-67-001, DON-NB-67-001
                if (preg_match('/(?:[A-Z0-9_]+)-([A-Z]+)-?(\d{2,4})?-?([A-Z0-9]+)/i', $search, $m)) {
                    $typeCode = $m[1] ?? null;
                    $seqStr = $m[3] ?? null;
                    if ($seqStr) {
                        $cleanSeq = ltrim($seqStr, 'Tt0');
                        $q->orWhere('asset_code', 'like', "%{$seqStr}%");
                        if (!empty($cleanSeq)) {
                            $q->orWhere('id', (int)$cleanSeq);
                        }
                    }
                    if ($typeCode) {
                        $q->orWhereHas('deviceType', function ($dtQ) use ($typeCode) {
                            $dtQ->where('code', $typeCode);
                        });
                    }
                }
            });
        }

        $perPage = in_array((int)$request->input('per_page'), [10, 20, 50, 100]) ? (int)$request->input('per_page') : 10;
        $assets = $query->latest('id')->paginate($perPage)->withQueryString();

        $deviceTypes = DeviceType::orderBy('name')->get();
        $departments = Department::where('is_active', true)->orderBy('name')->get();
        $budgetYears = Asset::select('budget_year')->whereNotNull('budget_year')->distinct()->orderBy('budget_year', 'desc')->pluck('budget_year');

        // Summary counts (scoped to department if regular user)
        $countQuery = Asset::query();
        if ($user && $user->isUser()) {
            $countQuery->where('department_id', $user->department_id ?: 0);
        }

        $statusCounts = [
            'total' => (clone $countQuery)->count(),
            'active' => (clone $countQuery)->where('status', 'active')->count(),
            'spare' => (clone $countQuery)->where('status', 'spare')->count(),
            'repairing' => (clone $countQuery)->where('status', 'repairing')->count(),
            'broken' => (clone $countQuery)->where('status', 'broken')->count(),
            'disposed' => (clone $countQuery)->where('status', 'disposed')->count(),
        ];

        // Hardware Specs Statistics & Fleet Breakdown
        $baseHardwareQuery = clone $countQuery;

        $ramTypeStats = (clone $baseHardwareQuery)
            ->whereNotNull('ram_type')
            ->where('ram_type', '!=', '')
            ->select('ram_type', \Illuminate\Support\Facades\DB::raw('count(*) as count'))
            ->groupBy('ram_type')
            ->orderBy('count', 'desc')
            ->pluck('count', 'ram_type')
            ->toArray();

        $ramCapacityStats = (clone $baseHardwareQuery)
            ->whereNotNull('ram_capacity')
            ->select('ram_capacity', \Illuminate\Support\Facades\DB::raw('count(*) as count'))
            ->groupBy('ram_capacity')
            ->orderBy('ram_capacity')
            ->pluck('count', 'ram_capacity')
            ->toArray();

        $osStats = (clone $baseHardwareQuery)
            ->whereNotNull('os_name')
            ->where('os_name', '!=', '')
            ->select('os_name', \Illuminate\Support\Facades\DB::raw('count(*) as count'))
            ->groupBy('os_name')
            ->orderBy('count', 'desc')
            ->pluck('count', 'os_name')
            ->toArray();

        $cpuCounts = [
            'i5' => (clone $baseHardwareQuery)->where('cpu_model', 'like', '%i5%')->count(),
            'i3' => (clone $baseHardwareQuery)->where('cpu_model', 'like', '%i3%')->count(),
            'i7' => (clone $baseHardwareQuery)->where('cpu_model', 'like', '%i7%')->count(),
            'ryzen' => (clone $baseHardwareQuery)->where('cpu_model', 'like', '%Ryzen%')->count(),
        ];

        $storageTypeStats = (clone $baseHardwareQuery)
            ->whereNotNull('storage_type')
            ->where('storage_type', '!=', '')
            ->select('storage_type', \Illuminate\Support\Facades\DB::raw('count(*) as count'))
            ->groupBy('storage_type')
            ->orderBy('count', 'desc')
            ->pluck('count', 'storage_type')
            ->toArray();

        $hardwareStats = [
            'ram_types' => $ramTypeStats,
            'ram_capacities' => $ramCapacityStats,
            'os_list' => $osStats,
            'cpu_families' => $cpuCounts,
            'storage_types' => $storageTypeStats,
            'total_computers' => (clone $baseHardwareQuery)->where(function($q) {
                $q->whereNotNull('cpu_model')
                  ->orWhereNotNull('ram_capacity')
                  ->orWhereHas('deviceType', function($dt) {
                      $dt->whereIn('code', ['PC', 'NB', 'AIO', 'SRV']);
                  });
            })->count(),
        ];

        $currentFiscalYear = (now()->month >= 10) ? now()->year + 544 : now()->year + 543;
        $pendingAuditsCount = \App\Models\HardwareAudit::where('status', 'pending')->count();
        $auditedYears = Asset::select('last_audited_fiscal_year')
            ->whereNotNull('last_audited_fiscal_year')
            ->distinct()
            ->orderBy('last_audited_fiscal_year', 'desc')
            ->pluck('last_audited_fiscal_year');

        // Master data for filters & options
        $budgetSources = BudgetSource::where('is_active', true)->orderBy('name')->get();
        $acquisitionMethods = AcquisitionMethod::where('is_active', true)->orderBy('name')->get();

        // Rental Fleet & Leased Printer Statistics (เครื่องเช่า / เครื่องพิมพ์เช่า)
        $rentedStats = [
            'total' => (clone $countQuery)->where('ownership_type', 'rented')->count(),
            'monthly_fee_total' => (float)(clone $countQuery)->where('ownership_type', 'rented')->sum('rental_monthly_fee'),
            'expiring_soon' => (clone $countQuery)->where('ownership_type', 'rented')
                ->whereNotNull('rental_end_date')
                ->whereBetween('rental_end_date', [now()->startOfDay(), now()->addDays(30)->endOfDay()])
                ->count(),
            'expired' => (clone $countQuery)->where('ownership_type', 'rented')
                ->whereNotNull('rental_end_date')
                ->where('rental_end_date', '<', now()->startOfDay())
                ->count(),
            'printers' => (clone $countQuery)->where('ownership_type', 'rented')
                ->where(function($q) {
                    $q->where('name', 'like', '%ปริ้น%')
                      ->orWhere('name', 'like', '%print%')
                      ->orWhere('name', 'like', '%พิมพ์%')
                      ->orWhere('model', 'like', '%printer%')
                      ->orWhereHas('deviceType', function($dt) {
                          $dt->where('code', 'PRN')
                            ->orWhere('name', 'like', '%ปริ้น%')
                            ->orWhere('name', 'like', '%พิมพ์%');
                      });
                })->count(),
        ];

        return view('assets.index', compact(
            'assets', 'deviceTypes', 'departments', 'budgetYears', 'statusCounts',
            'hardwareStats', 'user', 'currentFiscalYear', 'pendingAuditsCount', 'auditedYears',
            'budgetSources', 'acquisitionMethods', 'rentedStats'
        ));
    }

    public function create(Request $request)
    {
        $deviceTypes = DeviceType::orderBy('name')->get();
        $departments = Department::where('is_active', true)->orderBy('name')->get();
        $budgetSources = BudgetSource::where('is_active', true)->orderBy('name')->get();
        $acquisitionMethods = AcquisitionMethod::where('is_active', true)->orderBy('name')->get();
        $ictStandardsGrouped = IctStandardCatalog::grouped();
        $ictStandardsAll = IctStandardCatalog::all();

        $prefillAudit = null;
        if ($request->filled('from_audit')) {
            $prefillAudit = \App\Models\HardwareAudit::find($request->from_audit);
        }

        return view('assets.create', compact('deviceTypes', 'departments', 'budgetSources', 'acquisitionMethods', 'ictStandardsGrouped', 'ictStandardsAll', 'prefillAudit'));
    }

    public function store(Request $request)
    {
        // จัดการกรณีเครื่องเช่า / รับบริจาค / รอพัสดุออกเลข (ไม่มีเลขพัสดุ)
        $isRented = ($request->input('ownership_type') === 'rented') || str_starts_with(strtoupper($request->input('it_code', $request->input('it_asset_code', ''))), 'RENT');
        $isDonated = ($request->input('ownership_type') === 'donated') || str_starts_with(strtoupper($request->input('it_code', $request->input('it_asset_code', ''))), 'DON');
        $noAssetCode = $request->boolean('no_asset_code') || empty($request->input('asset_code'));

        if ($noAssetCode) {
            $prefixTemp = $isRented ? 'RENT' : ($isDonated ? 'DON' : 'PENDING');
            $uniqueSuffix = time() . '-' . rand(100, 999);
            $rawTag = $request->input('it_code') ?: $request->input('it_asset_code');
            $cleanTag = $rawTag ? preg_replace('/[^A-Za-z0-9_-]/', '', $rawTag) : $uniqueSuffix;
            $request->merge([
                'asset_code' => "{$prefixTemp}-{$cleanTag}"
            ]);
        }

        $request->validate([
            'it_code' => 'nullable|string|max:50',
            'it_asset_code' => 'nullable|string|max:50',
            'asset_code' => 'required|string|max:100|unique:it_assets,asset_code',
            'serial_number' => 'nullable|string|max:100',
            'hardware_id' => 'nullable|string|max:100',
            'name' => 'required|string|max:255',
            'device_type_id' => 'required|exists:it_device_types,id',
            'brand' => 'nullable|string|max:100',
            'model' => 'nullable|string|max:100',
            'specs' => 'nullable|string',
            'cpu_model' => 'nullable|string|max:150',
            'cpu_speed' => 'nullable|string|max:50',
            'ram_capacity' => 'nullable|integer|min:1|max:1024',
            'ram_type' => 'nullable|string|max:30',
            'ram_bus' => 'nullable|string|max:30',
            'ram_slots' => 'nullable|string|max:50',
            'storage_type' => 'nullable|string|max:50',
            'storage_capacity' => 'nullable|string|max:50',
            'storage_second' => 'nullable|string|max:100',
            'os_name' => 'nullable|string|max:100',
            'os_license' => 'nullable|string|max:100',
            'gpu_model' => 'nullable|string|max:150',
            'monitor_size' => 'nullable|string|max:50',
            'ip_address' => 'nullable|string|max:45',
            'mac_address' => 'nullable|string|max:50',
            'department_id' => 'nullable|exists:it_departments,id',
            'location_detail' => 'nullable|string|max:255',
            'custodian_name' => 'nullable|string|max:255',
            'status' => 'required|in:active,spare,repairing,broken,disposed',
            'purchase_date' => 'nullable|date',
            'price' => 'nullable|numeric|min:0',
            'warranty_expire_date' => 'nullable|date',
            'budget_year' => 'nullable|string|max:10',
            'budget_source_id' => 'nullable|exists:it_budget_sources,id',
            'acquisition_method_id' => 'nullable|exists:it_acquisition_methods,id',
            'ownership_type' => 'nullable|in:owned,rented,donated,borrowed',
            'rental_contract_no' => 'nullable|string|max:100',
            'rental_vendor' => 'nullable|string|max:150',
            'rental_start_date' => 'nullable|date',
            'rental_end_date' => 'nullable|date',
            'rental_monthly_fee' => 'nullable|numeric|min:0',
            'rental_contact_phone' => 'nullable|string|max:50',
            'rental_conditions' => 'nullable|string',
            'image' => 'nullable|image|max:3072',
            'notes' => 'nullable|string',
        ]);

        $data = $request->except(['image', 'no_asset_code', 'prefix_mode', 'it_asset_code', 'it_code']);
        $data['ownership_type'] = $data['ownership_type'] ?? 'owned';

        // บันทึกรหัสคุมไอที (IT Asset Tag / IT Code) โครงสร้างใหม่: [รหัสย่อประเภท]-[สุ่ม 6 หลัก อักษรพิมพ์ใหญ่+ตัวเลข]
        $itTag = strtoupper(trim($request->input('it_code') ?: $request->input('it_asset_code', '')));
        if (empty($itTag)) {
            $devType = !empty($data['device_type_id']) ? DeviceType::find($data['device_type_id']) : null;
            $typeCode = ItAssetCodeGeneratorService::resolveTypeCodeString($devType, $data['name'] ?? null, $data['asset_code'] ?? null);
            $itTag = ItAssetCodeGeneratorService::generateCode($typeCode, null, $data['name'] ?? null, $data['asset_code'] ?? null);
        }
        if (!empty($itTag)) {
            $data['it_code'] = $itTag;
            $cleanNotes = preg_replace('/\[IT-TAG:\s*[^\]]+\]\s*/', '', $data['notes'] ?? '');
            $data['notes'] = trim("[IT-TAG: {$itTag}]\n" . $cleanNotes);
        }

        // Auto-format fallback specs string if left empty
        if (empty($data['specs'])) {
            $parts = [];
            if (!empty($data['cpu_model'])) $parts[] = $data['cpu_model'];
            if (!empty($data['ram_capacity'])) $parts[] = 'RAM ' . $data['ram_capacity'] . 'GB' . (!empty($data['ram_type']) ? ' ' . $data['ram_type'] : '');
            if (!empty($data['storage_capacity']) || !empty($data['storage_type'])) $parts[] = trim(($data['storage_type'] ?? '') . ' ' . ($data['storage_capacity'] ?? ''));
            if (!empty($data['os_name'])) $parts[] = $data['os_name'];
            if (!empty($parts)) $data['specs'] = implode(', ', $parts);
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = 'asset_' . time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/assets'), $filename);
            $data['image'] = 'uploads/assets/' . $filename;
        }

        $asset = Asset::create($data);

        return redirect()->route('assets.show', $asset)->with('success', "เพิ่มครุภัณฑ์รหัส {$asset->asset_code} เรียบร้อยแล้ว");
    }

    public function show(Asset $asset)
    {
        $user = Auth::user();
        if ($user && $user->isUser() && $asset->department_id !== $user->department_id) {
            abort(403, 'คุณมีสิทธิ์เข้าถึงเฉพาะข้อมูลครุภัณฑ์ประจำแผนกของคุณเท่านั้น');
        }

        $asset->load([
            'deviceType',
            'department',
            'budgetSource',
            'acquisitionMethod',
            'repairs.department',
            'repairs.technician',
            'hardwareAudits.reviewer',
            'currentBorrow.department',
            'borrows.department',
        ])->loadCount(['repairs', 'hardwareAudits', 'borrows']);

        $currentFiscalYear = (now()->month >= 10) ? now()->year + 544 : now()->year + 543;
        $pendingAuditForAsset = $asset->hardwareAudits->firstWhere('status', 'pending');

        return view('assets.show', compact('asset', 'currentFiscalYear', 'pendingAuditForAsset'));
    }

    public function edit(Asset $asset)
    {
        $deviceTypes = DeviceType::orderBy('name')->get();
        $departments = Department::where('is_active', true)->orderBy('name')->get();
        $budgetSources = BudgetSource::where('is_active', true)->orderBy('name')->get();
        $acquisitionMethods = AcquisitionMethod::where('is_active', true)->orderBy('name')->get();
        $ictStandardsGrouped = IctStandardCatalog::grouped();
        $ictStandardsAll = IctStandardCatalog::all();

        return view('assets.edit', compact('asset', 'deviceTypes', 'departments', 'budgetSources', 'acquisitionMethods', 'ictStandardsGrouped', 'ictStandardsAll'));
    }

    public function update(Request $request, Asset $asset)
    {
        // จัดการกรณีเครื่องเช่า / รับบริจาค / รอพัสดุออกเลข (ไม่มีเลขพัสดุ)
        $isRented = ($request->input('ownership_type') === 'rented') || str_starts_with(strtoupper($request->input('it_code', $request->input('it_asset_code', ''))), 'RENT');
        $isDonated = ($request->input('ownership_type') === 'donated') || str_starts_with(strtoupper($request->input('it_code', $request->input('it_asset_code', ''))), 'DON');
        $noAssetCode = $request->boolean('no_asset_code') || empty($request->input('asset_code'));

        if ($noAssetCode && !$asset->has_official_asset_code) {
            $prefixTemp = $isRented ? 'RENT' : ($isDonated ? 'DON' : 'PENDING');
            $rawTag = $request->input('it_code') ?: $request->input('it_asset_code');
            $cleanTag = $rawTag ? preg_replace('/[^A-Za-z0-9_-]/', '', $rawTag) : $asset->id;
            $request->merge([
                'asset_code' => "{$prefixTemp}-{$cleanTag}"
            ]);
        }

        $request->validate([
            'it_code' => 'nullable|string|max:50',
            'it_asset_code' => 'nullable|string|max:50',
            'asset_code' => 'required|string|max:100|unique:it_assets,asset_code,' . $asset->id,
            'serial_number' => 'nullable|string|max:100',
            'hardware_id' => 'nullable|string|max:100',
            'name' => 'required|string|max:255',
            'device_type_id' => 'required|exists:it_device_types,id',
            'brand' => 'nullable|string|max:100',
            'model' => 'nullable|string|max:100',
            'specs' => 'nullable|string',
            'cpu_model' => 'nullable|string|max:150',
            'cpu_speed' => 'nullable|string|max:50',
            'ram_capacity' => 'nullable|integer|min:1|max:1024',
            'ram_type' => 'nullable|string|max:30',
            'ram_bus' => 'nullable|string|max:30',
            'ram_slots' => 'nullable|string|max:50',
            'storage_type' => 'nullable|string|max:50',
            'storage_capacity' => 'nullable|string|max:50',
            'storage_second' => 'nullable|string|max:100',
            'os_name' => 'nullable|string|max:100',
            'os_license' => 'nullable|string|max:100',
            'gpu_model' => 'nullable|string|max:150',
            'monitor_size' => 'nullable|string|max:50',
            'ip_address' => 'nullable|string|max:45',
            'mac_address' => 'nullable|string|max:50',
            'department_id' => 'nullable|exists:it_departments,id',
            'location_detail' => 'nullable|string|max:255',
            'custodian_name' => 'nullable|string|max:255',
            'status' => 'required|in:active,spare,repairing,broken,disposed',
            'purchase_date' => 'nullable|date',
            'price' => 'nullable|numeric|min:0',
            'warranty_expire_date' => 'nullable|date',
            'budget_year' => 'nullable|string|max:10',
            'budget_source_id' => 'nullable|exists:it_budget_sources,id',
            'acquisition_method_id' => 'nullable|exists:it_acquisition_methods,id',
            'ownership_type' => 'nullable|in:owned,rented,donated,borrowed',
            'rental_contract_no' => 'nullable|string|max:100',
            'rental_vendor' => 'nullable|string|max:150',
            'rental_start_date' => 'nullable|date',
            'rental_end_date' => 'nullable|date',
            'rental_monthly_fee' => 'nullable|numeric|min:0',
            'rental_contact_phone' => 'nullable|string|max:50',
            'rental_conditions' => 'nullable|string',
            'image' => 'nullable|image|max:3072',
            'notes' => 'nullable|string',
        ]);

        $data = $request->except(['image', 'no_asset_code', 'prefix_mode', 'it_asset_code', 'it_code']);
        if (empty($data['ownership_type'])) {
            $data['ownership_type'] = $asset->ownership_type ?? 'owned';
        }

        // บันทึกรหัสคุมไอที (IT Asset Tag / IT Code) โครงสร้างใหม่: [รหัสย่อประเภท]-[สุ่ม 6 หลัก อักษรพิมพ์ใหญ่+ตัวเลข]
        $itTag = strtoupper(trim($request->input('it_code') ?: $request->input('it_asset_code', '')));
        if (empty($itTag)) {
            $devType = !empty($data['device_type_id']) ? DeviceType::find($data['device_type_id']) : null;
            $typeCode = ItAssetCodeGeneratorService::resolveTypeCodeString($devType, $data['name'] ?? null, $data['asset_code'] ?? null);
            $itTag = ItAssetCodeGeneratorService::generateCode($typeCode, $asset->id, $data['name'] ?? null, $data['asset_code'] ?? null);
        }
        if (!empty($itTag)) {
            $data['it_code'] = $itTag;
            $cleanNotes = preg_replace('/\[IT-TAG:\s*[^\]]+\]\s*/', '', $data['notes'] ?? $asset->notes ?? '');
            $data['notes'] = trim("[IT-TAG: {$itTag}]\n" . $cleanNotes);
        }


        // Auto-format fallback specs string if left empty
        if (empty($data['specs'])) {
            $parts = [];
            if (!empty($data['cpu_model'])) $parts[] = $data['cpu_model'];
            if (!empty($data['ram_capacity'])) $parts[] = 'RAM ' . $data['ram_capacity'] . 'GB' . (!empty($data['ram_type']) ? ' ' . $data['ram_type'] : '');
            if (!empty($data['storage_capacity']) || !empty($data['storage_type'])) $parts[] = trim(($data['storage_type'] ?? '') . ' ' . ($data['storage_capacity'] ?? ''));
            if (!empty($data['os_name'])) $parts[] = $data['os_name'];
            if (!empty($parts)) $data['specs'] = implode(', ', $parts);
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = 'asset_' . time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/assets'), $filename);
            $data['image'] = 'uploads/assets/' . $filename;
        }

        $asset->update($data);

        return redirect()->route('assets.show', $asset)->with('success', 'บันทึกการแก้ไขข้อมูลครุภัณฑ์เรียบร้อยแล้ว');
    }

    public function destroy(Asset $asset)
    {
        if ($asset->repairs()->count() > 0) {
            return back()->with('error', 'ไม่สามารถลบครุภัณฑ์นี้ได้ เนื่องจากมีประวัติการแจ้งซ่อมในระบบ');
        }

        $code = $asset->asset_code;
        $asset->delete();

        return redirect()->route('assets.index')->with('success', "ลบครุภัณฑ์รหัส {$code} เรียบร้อยแล้ว");
    }

    public function label(Asset $asset)
    {
        $user = Auth::user();
        if ($user && $user->isUser() && $asset->department_id !== $user->department_id) {
            abort(403, 'คุณมีสิทธิ์เข้าถึงเฉพาะข้อมูลครุภัณฑ์ประจำแผนกของคุณเท่านั้น');
        }

        $asset->load(['deviceType', 'department']);
        return view('assets.label', compact('asset'));
    }

    /**
     * Download CSV template with sample data for asset importing
     */
    public function downloadTemplate()
    {
        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="it_asset_import_template.csv"',
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];

        return response()->stream(function () {
            $handle = fopen('php://output', 'w');
            // Write UTF-8 BOM for Microsoft Excel compatibility on Thai Windows
            fprintf($handle, chr(0xEF) . chr(0xBB) . chr(0xBF));

            fputcsv($handle, [
                'รหัสครุภัณฑ์',
                'Serial Number',
                'ชื่อรายการครุภัณฑ์',
                'ประเภทอุปกรณ์',
                'ยี่ห้อ',
                'รุ่น',
                'CPU',
                'ความเร็ว CPU',
                'RAM (GB)',
                'ชนิด RAM',
                'บัส RAM',
                'สล็อต RAM',
                'ชนิด Storage',
                'ความจุ Storage',
                'ไดรฟ์สำรอง',
                'ระบบ OS',
                'ลิขสิทธิ์ OS',
                'การ์ดจอ',
                'ขนาดจอภาพ',
                'สเปคเพิ่มเติม',
                'แผนก',
                'สถานที่ตั้ง',
                'ผู้ครอบครอง',
                'สถานะ',
                'ราคา (บาท)',
                'ปีงบประมาณ',
                'วันที่ซื้อ (YYYY-MM-DD)',
                'วันหมดประกัน (YYYY-MM-DD)',
                'IP Address',
                'MAC Address',
                'แหล่งเงินงบประมาณ',
                'วิธีการได้มา',
                'กรรมสิทธิ์ (owned/rented/donated/borrowed)',
                'เลขที่สัญญาเช่า',
                'ผู้ให้เช่า/บริษัทคู่สัญญา',
                'วันเริ่มสัญญาเช่า (YYYY-MM-DD)',
                'วันสิ้นสุดสัญญาเช่า (YYYY-MM-DD)',
                'ค่าเช่าต่อเดือน (บาท)',
                'เบอร์ติดต่อผู้ให้เช่า',
                'เงื่อนไขสัญญาเช่า',
                'หมายเหตุ',
            ]);

            // Sample 1: PC with DDR5
            fputcsv($handle, [
                '7440-001-0021/67',
                'DL-OPT-7020-02',
                'คอมพิวเตอร์ประมวลผลงานเภสัชกรรม',
                'คอมพิวเตอร์ตั้งโต๊ะ (PC)',
                'Dell',
                'OptiPlex 7020 Plus',
                'Intel Core i5-14500',
                '2.6 GHz Turbo 5.0 GHz',
                '16',
                'DDR5',
                '5600 MHz',
                '1 แถว (16GB x 1)',
                'SSD NVMe M.2',
                '512 GB',
                '',
                'Windows 11 Pro',
                'OEM (ติดเครื่อง/BIOS)',
                'Intel UHD Graphics 770',
                '24 นิ้ว FHD IPS',
                '',
                'กลุ่มงานเภสัชกรรมและคุ้มครองผู้บริโภค',
                'ห้องจ่ายยา ช่องบริการ 1',
                'ภญ.พิมพ์ใจ รักยา',
                'active',
                '28900.00',
                '2567',
                '2024-04-10',
                '2027-04-10',
                '192.168.2.75',
                '00:14:22:88:99:AA',
                'เงิน UC (กองทุนหลักประกันสุขภาพถ้วนหน้า)',
                'จัดซื้อจัดจ้าง (เงินงบประมาณ/เงินบำรุง)',
                'owned',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                'เครื่องประจำห้องจ่ายยา',
            ]);

            // Sample 2: Notebook with DDR4
            fputcsv($handle, [
                '7440-006-0003/67',
                'LN-T14-01',
                'โน้ตบุ๊กงานเวชระเบียนและสถิติ',
                'คอมพิวเตอร์พกพา (Notebook)',
                'Lenovo',
                'ThinkPad T14 Gen 4',
                'AMD Ryzen 7 7730U',
                '2.0 GHz Turbo 4.5 GHz',
                '16',
                'DDR4',
                '3200 MHz',
                '1 แถว (16GB x 1)',
                'SSD NVMe M.2',
                '512 GB',
                '',
                'Windows 11 Pro',
                'OEM (ติดเครื่อง/BIOS)',
                'AMD Radeon Graphics',
                '14 นิ้ว FHD',
                '',
                'กลุ่มงานประกันสุขภาพและเวชระเบียน',
                'ห้องเวชระเบียน อาคาร OPD',
                'เจ้าหน้าที่เวชระเบียน',
                'active',
                '27500.00',
                '2567',
                '2024-03-15',
                '2027-03-15',
                '192.168.2.106',
                '48:2A:E3:44:55:77',
                'เงินบำรุง / เงินเก็บค่าบริการทางการแพทย์',
                'จัดซื้อจัดจ้าง (เงินงบประมาณ/เงินบำรุง)',
                'owned',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                'โน้ตบุ๊กประจำกลุ่มงาน',
            ]);

            // Sample 3: All-in-One PC with DDR4
            fputcsv($handle, [
                '7440-002-0006/66',
                'HP-AIO-24-01',
                'คอมพิวเตอร์ AIO จุดประชาสัมพันธ์',
                'คอมพิวเตอร์ All-in-One (AIO)',
                'HP',
                'ProOne 240 G10',
                'Intel Core i3-1315U',
                '1.2 GHz Turbo 4.5 GHz',
                '8',
                'DDR4',
                '3200 MHz',
                '1 แถว (8GB x 1)',
                'SSD NVMe M.2',
                '256 GB',
                '',
                'Windows 10 Pro',
                'Volume License (KMS/MAK)',
                'Intel UHD Graphics',
                '23.8 นิ้ว FHD',
                '',
                'กลุ่มงานบริหารทั่วไป (ธุรการ/สารบรรณ)',
                'เคาน์เตอร์ประชาสัมพันธ์ อาคารผู้ป่วยนอก',
                'เจ้าหน้าที่ประชาสัมพันธ์',
                'active',
                '19500.00',
                '2566',
                '2023-11-20',
                '2026-11-20',
                '192.168.2.93',
                '94:C6:91:22:33:55',
                'เงินงบประมาณแผ่นดิน (งบลงทุน/จัดสรร)',
                'จัดซื้อจัดจ้าง (เงินงบประมาณ/เงินบำรุง)',
                'owned',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
            ]);

            // Sample 4: Laser Printer
            fputcsv($handle, [
                '7440-002-0002/67',
                'BR-HL-L2370-01',
                'เครื่องพิมพ์เลเซอร์ แผนกเภสัชกรรม',
                'เครื่องพิมพ์เลเซอร์/อิงค์เจ็ท (Laser/Inkjet)',
                'Brother',
                'HL-L2370DN',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                'Laser Duplex Network 30 ppm',
                'กลุ่มงานเภสัชกรรมและคุ้มครองผู้บริโภค',
                'เคาน์เตอร์จ่ายยา ช่อง 2',
                'ภญ.พิมพ์ใจ รักยา',
                'active',
                '4900.00',
                '2567',
                '2024-02-15',
                '2027-02-15',
                '192.168.2.152',
                '00:80:77:AA:BB:DD',
                'เงินบำรุง / เงินเก็บค่าบริการทางการแพทย์',
                'จัดซื้อจัดจ้าง (เงินงบประมาณ/เงินบำรุง)',
                'owned',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                'พิมพ์ใบสั่งยา',
            ]);

            // Sample 5: Rented Multi-Function Printer (เครื่องพิมพ์เช่าคุมสัญญา)
            fputcsv($handle, [
                'RENT-PRN-001/67',
                'FX-APEOS-C3070-01',
                'เครื่องพิมพ์มัลติฟังก์ชันเช่า แผนกธุรการ',
                'เครื่องพิมพ์เลเซอร์/อิงค์เจ็ท (Laser/Inkjet)',
                'FUJIFILM (Fuji Xerox)',
                'ApeosPrint C3070',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                'Multifunction Copy/Print/Scan Network 35 ppm',
                'กลุ่มงานบริหารทั่วไป (ธุรการ/สารบรรณ)',
                'ห้องธุรการ อาคารอำนวยการ ชั้น 1',
                'หัวหน้างานธุรการ',
                'active',
                '0.00',
                '2567',
                '',
                '',
                '192.168.2.200',
                '00:11:22:33:44:55',
                'เงินบำรุง / เงินเก็บค่าบริการทางการแพทย์',
                'เช่าใช้ / สัญญาเช่าบริการ (Lease / Rental)',
                'rented',
                'CN-IT-2567/012',
                'บริษัท ฟูจิฟิล์ม บิสซิเนส อินโนเวชั่น (ประเทศไทย) จำกัด',
                '2024-01-01',
                '2026-12-31',
                '2500.00',
                '02-660-8000',
                'ฟรีผงหมึกพิมพ์ทุกสีและค่าช่างซ่อมบำรุง สิทธิ์พิมพ์ขาวดำ 5,000 แผ่น/เดือน สี 1,000 แผ่น/เดือน',
                'เครื่องเช่าพร้อมบริการบำรุงรักษา',
            ]);

            fclose($handle);
        }, 200, $headers);
    }

    /**
     * Import assets from CSV file (Admin only)
     */
    public function importCsv(Request $request)
    {
        $user = Auth::user();
        if (!$user || !$user->isAdmin()) {
            abort(403, 'เฉพาะผู้ดูแลระบบ (Admin) เท่านั้นที่สามารถนำเข้าข้อมูลครุภัณฑ์ได้');
        }

        $file = $request->file('csv_file') ?? $request->file('file');
        if (!$file) {
            return back()->with('error', 'กรุณาเลือกไฟล์ CSV สำหรับนำเข้าข้อมูล');
        }

        $request->validate([
            'csv_file' => 'nullable|file|max:10240',
            'file' => 'nullable|file|max:10240',
            'overwrite' => 'nullable|boolean',
        ]);

        $path = $file->getRealPath();
        $overwrite = $request->boolean('overwrite');

        $content = file_get_contents($path);
        // Strip BOM if present
        if (str_starts_with($content, "\xEF\xBB\xBF")) {
            $content = substr($content, 3);
        }

        // Auto-detect delimiter (, or ;)
        $firstLine = strtok($content, "\r\n");
        $delimiter = (substr_count($firstLine, ';') > substr_count($firstLine, ',')) ? ';' : ',';

        $lines = explode("\n", str_replace("\r\n", "\n", $content));
        if (count($lines) < 2) {
            return back()->with('error', 'ไฟล์ CSV ไม่มีข้อมูล หรือมีเฉพาะหัวตาราง');
        }

        $headerLine = array_shift($lines);
        $headers = str_getcsv($headerLine, $delimiter);
        $normalizedHeaders = [];
        foreach ($headers as $idx => $h) {
            $key = mb_strtolower(trim(trim($h, "\xEF\xBB\xBF\"' ")));
            $normalizedHeaders[$key] = $idx;
        }

        $deviceTypes = DeviceType::all();
        $departments = Department::all();
        $budgetSources = BudgetSource::all();
        $acquisitionMethods = AcquisitionMethod::all();

        $createdCount = 0;
        $updatedCount = 0;
        $skippedCount = 0;
        $errorCount = 0;

        $parseDate = function ($v) {
            if (!$v) return null;
            $clean = trim($v);
            $ts = strtotime(str_replace('/', '-', $clean));
            return $ts ? date('Y-m-d', $ts) : null;
        };

        foreach ($lines as $lineIndex => $line) {
            $trimmed = trim($line);
            if ($trimmed === '') continue;

            $row = str_getcsv($line, $delimiter);
            if (empty(array_filter($row))) continue;

            $getVal = function ($names, $default = null) use ($row, $normalizedHeaders) {
                foreach ((array)$names as $name) {
                    $key = mb_strtolower(trim($name));
                    if (isset($normalizedHeaders[$key]) && isset($row[$normalizedHeaders[$key]])) {
                        $v = trim($row[$normalizedHeaders[$key]]);
                        if ($v !== '') return $v;
                    }
                }
                return $default;
            };

            $assetCode = $getVal(['รหัสครุภัณฑ์', 'asset_code', 'code']);
            if (!$assetCode) {
                $errorCount++;
                continue;
            }

            $name = $getVal(['ชื่อรายการครุภัณฑ์', 'ชื่อรายการ', 'name'], 'อุปกรณ์ IT');
            $deviceTypeName = $getVal(['ประเภทอุปกรณ์', 'device_type', 'type']);
            $deviceType = null;
            if ($deviceTypeName) {
                $deviceType = $deviceTypes->first(function ($dt) use ($deviceTypeName) {
                    return mb_stripos($dt->name, $deviceTypeName) !== false || 
                           strcasecmp($dt->code, $deviceTypeName) === 0;
                });
            }
            if (!$deviceType) {
                $deviceType = $deviceTypes->firstWhere('code', 'PC') ?? $deviceTypes->first();
            }

            $deptName = $getVal(['แผนก', 'department', 'หน่วยงาน']);
            $dept = null;
            if ($deptName) {
                $dept = $departments->first(function ($d) use ($deptName) {
                    return mb_stripos($d->name, $deptName) !== false || 
                           strcasecmp($d->code, $deptName) === 0;
                });
            }

            $rawStatus = mb_strtolower($getVal(['สถานะ', 'status'], 'active'));
            $status = match (true) {
                str_contains($rawStatus, 'spare') || str_contains($rawStatus, 'สำรอง') => 'spare',
                str_contains($rawStatus, 'repair') || str_contains($rawStatus, 'ซ่อม') => 'repairing',
                str_contains($rawStatus, 'broken') || str_contains($rawStatus, 'ชำรุด') => 'broken',
                str_contains($rawStatus, 'dispos') || str_contains($rawStatus, 'จำหน่าย') => 'disposed',
                default => 'active',
            };

            $rawRamCap = $getVal(['ram (gb)', 'ram_capacity', 'ram', 'ความจุ ram']);
            $ramCapacity = null;
            if ($rawRamCap && preg_match('/(\d+)/', $rawRamCap, $m)) {
                $ramCapacity = (int)$m[1];
            }

            $ramType = $getVal(['ชนิด ram', 'ram_type', 'ประเภท ram']);
            if (!$ramType && $ramCapacity) {
                $ramType = 'DDR4';
            }

            $rawPrice = $getVal(['ราคา (บาท)', 'ราคา', 'price']);
            $price = is_numeric(str_replace(',', '', $rawPrice ?? '')) ? (float)str_replace(',', '', $rawPrice) : null;

            $budgetSourceName = $getVal(['แหล่งเงินงบประมาณ', 'แหล่งเงิน', 'budget_source']);
            $budgetSource = null;
            if ($budgetSourceName) {
                $budgetSource = $budgetSources->first(function ($b) use ($budgetSourceName) {
                    return mb_stripos($b->name, $budgetSourceName) !== false || 
                           strcasecmp($b->code, $budgetSourceName) === 0;
                });
            }

            $acqMethodName = $getVal(['วิธีการได้มา', 'acquisition_method']);
            $acquisitionMethod = null;
            if ($acqMethodName) {
                $acquisitionMethod = $acquisitionMethods->first(function ($a) use ($acqMethodName) {
                    return mb_stripos($a->name, $acqMethodName) !== false || 
                           strcasecmp($a->code, $acqMethodName) === 0;
                });
            }

            $rawOwnership = mb_strtolower($getVal(['กรรมสิทธิ์', 'ownership_type', 'ประเภทการครอบครอง'], 'owned'));
            $ownershipType = match (true) {
                str_contains($rawOwnership, 'rent') || str_contains($rawOwnership, 'เช่า') => 'rented',
                str_contains($rawOwnership, 'donat') || str_contains($rawOwnership, 'บริจาค') => 'donated',
                str_contains($rawOwnership, 'borrow') || str_contains($rawOwnership, 'ยืม') => 'borrowed',
                default => 'owned',
            };

            $rawRentalFee = $getVal(['ค่าเช่าต่อเดือน (บาท)', 'ค่าเช่ารายเดือน', 'rental_monthly_fee']);
            $rentalMonthlyFee = is_numeric(str_replace(',', '', $rawRentalFee ?? '')) ? (float)str_replace(',', '', $rawRentalFee) : null;

            $assetData = [
                'asset_code' => $assetCode,
                'serial_number' => $getVal(['serial number', 's/n', 'serial_number']),
                'name' => $name,
                'device_type_id' => $deviceType?->id,
                'brand' => $getVal(['ยี่ห้อ', 'brand']),
                'model' => $getVal(['รุ่น', 'model']),
                'cpu_model' => $getVal(['cpu', 'cpu_model', 'หน่วยประมวลผล']),
                'cpu_speed' => $getVal(['ความเร็ว cpu', 'cpu_speed', 'speed']),
                'ram_capacity' => $ramCapacity,
                'ram_type' => $ramType,
                'ram_bus' => $getVal(['บัส ram', 'ram_bus', 'bus']),
                'ram_slots' => $getVal(['สล็อต ram', 'ram_slots', 'slots']),
                'storage_type' => $getVal(['ชนิด storage', 'storage_type', 'ชนิดไดรฟ์']),
                'storage_capacity' => $getVal(['ความจุ storage', 'storage_capacity', 'ขนาดไดรฟ์']),
                'storage_second' => $getVal(['ไดรฟ์สำรอง', 'storage_second']),
                'os_name' => $getVal(['ระบบ os', 'os_name', 'os', 'ระบบปฏิบัติการ']),
                'os_license' => $getVal(['ลิขสิทธิ์ os', 'os_license', 'ลิขสิทธิ์']),
                'gpu_model' => $getVal(['การ์ดจอ', 'gpu_model', 'gpu']),
                'monitor_size' => $getVal(['ขนาดจอภาพ', 'monitor_size', 'จอภาพ']),
                'specs' => $getVal(['สเปคเพิ่มเติม', 'สเปกเพิ่มเติม', 'specs', 'รายละเอียดสเปค', 'รายละเอียดสเปก']),
                'department_id' => $dept?->id,
                'location_detail' => $getVal(['สถานที่ตั้ง', 'location_detail', 'จุดวาง', 'ห้อง']),
                'custodian_name' => $getVal(['ผู้ครอบครอง', 'custodian_name', 'ผู้ดูแล']),
                'status' => $status,
                'price' => $price,
                'budget_year' => $getVal(['ปีงบประมาณ', 'budget_year']),
                'budget_source_id' => $budgetSource?->id,
                'acquisition_method_id' => $acquisitionMethod?->id,
                'ownership_type' => $ownershipType,
                'rental_contract_no' => $getVal(['เลขที่สัญญาเช่า', 'rental_contract_no', 'เลขที่สัญญา']),
                'rental_vendor' => $getVal(['ผู้ให้เช่า/บริษัทคู่สัญญา', 'ผู้ให้เช่า', 'rental_vendor', 'บริษัทผู้ให้เช่า']),
                'rental_start_date' => $parseDate($getVal(['วันเริ่มสัญญาเช่า (yyyy-mm-dd)', 'วันเริ่มสัญญาเช่า', 'rental_start_date'])),
                'rental_end_date' => $parseDate($getVal(['วันสิ้นสุดสัญญาเช่า (yyyy-mm-dd)', 'วันสิ้นสุดสัญญาเช่า', 'rental_end_date'])),
                'rental_monthly_fee' => $rentalMonthlyFee,
                'rental_contact_phone' => $getVal(['เบอร์ติดต่อผู้ให้เช่า', 'rental_contact_phone', 'เบอร์ติดต่อ']),
                'rental_conditions' => $getVal(['เงื่อนไขสัญญาเช่า', 'rental_conditions', 'เงื่อนไข']),
                'purchase_date' => $parseDate($getVal(['วันที่ซื้อ (yyyy-mm-dd)', 'purchase_date', 'วันที่ซื้อ'])),
                'warranty_expire_date' => $parseDate($getVal(['วันหมดประกัน (yyyy-mm-dd)', 'warranty_expire_date', 'วันหมดประกัน'])),
                'ip_address' => $getVal(['ip address', 'ip_address', 'ip']),
                'mac_address' => $getVal(['mac address', 'mac_address', 'mac']),
                'notes' => $getVal(['หมายเหตุ', 'notes']),
            ];

            if (empty($assetData['specs'])) {
                $parts = [];
                if (!empty($assetData['cpu_model'])) $parts[] = $assetData['cpu_model'];
                if (!empty($assetData['ram_capacity'])) $parts[] = 'RAM ' . $assetData['ram_capacity'] . 'GB' . (!empty($assetData['ram_type']) ? ' ' . $assetData['ram_type'] : '');
                if (!empty($assetData['storage_capacity']) || !empty($assetData['storage_type'])) $parts[] = trim(($assetData['storage_type'] ?? '') . ' ' . ($assetData['storage_capacity'] ?? ''));
                if (!empty($assetData['os_name'])) $parts[] = $assetData['os_name'];
                if (!empty($parts)) $assetData['specs'] = implode(', ', $parts);
            }

            $existing = Asset::where('asset_code', $assetCode)->first();
            if ($existing) {
                if ($overwrite) {
                    $existing->update($assetData);
                    $updatedCount++;
                } else {
                    $skippedCount++;
                }
            } else {
                Asset::create($assetData);
                $createdCount++;
            }
        }

        $summaryParts = ["นำเข้าข้อมูลเสร็จสิ้น: สร้างใหม่ {$createdCount} รายการ"];
        if ($updatedCount > 0) $summaryParts[] = "อัปเดต {$updatedCount} รายการ";
        if ($skippedCount > 0) $summaryParts[] = "ข้ามรหัสซ้ำ {$skippedCount} รายการ";
        if ($errorCount > 0) $summaryParts[] = "ข้อมูลไม่สมบูรณ์ {$errorCount} แถว";

        return redirect()->route('assets.index')->with('success', implode(' | ', $summaryParts));
    }

    /**
     * สุ่มรหัสคุมครุภัณฑ์ไอที (IT Code) พร้อมภาพ Barcode (SVG) แบบ Real-time (AJAX API)
     * รูปแบบใหม่: [รหัสย่อประเภท]-[สุ่ม 6 หลัก อักษรพิมพ์ใหญ่+ตัวเลข]
     */
    public function nextItCode(Request $request)
    {
        $deviceTypeId = $request->input('device_type_id');
        $deviceTypeCodeParam = $request->input('device_type_code');
        $excludeId = $request->input('exclude_id');
        $assetName = $request->input('name');
        $assetCode = $request->input('asset_code');

        $deviceType = $deviceTypeId ? DeviceType::find($deviceTypeId) : null;
        $resolvedTypeCode = $deviceTypeCodeParam ?: ItAssetCodeGeneratorService::resolveTypeCodeString($deviceType, $assetName, $assetCode);

        $code = ItAssetCodeGeneratorService::generateCode(
            $resolvedTypeCode,
            $excludeId ? (int)$excludeId : null,
            $assetName,
            $assetCode
        );

        $barcodeSvg = \App\Services\BarcodeService::generateSvg($code, 55, 2, true);
        $barcodeDataUri = \App\Services\BarcodeService::generateDataUri($code, 55, 2, true);

        return response()->json([
            'success' => true,
            'it_code' => $code,
            'type' => $resolvedTypeCode,
            'barcode_svg' => $barcodeSvg,
            'barcode_data_uri' => $barcodeDataUri,
        ]);
    }

    /**
     * ให้บริการภาพ Barcode SVG สำหรับครุภัณฑ์
     */
    public function barcode(Request $request, Asset $asset)
    {
        $code = $asset->it_code ?: ($asset->asset_code ?: 'ASSET');
        $svg = \App\Services\BarcodeService::generateSvg($code, 55, 2, true);

        return response($svg, 200, [
            'Content-Type' => 'image/svg+xml',
            'Cache-Control' => 'public, max-age=86400',
        ]);
    }

    /**
     * ให้บริการภาพ Barcode Preview (SVG) จากรหัสที่ส่งมา
     */
    public function barcodePreview(Request $request)
    {
        $code = $request->query('code', 'SAMPLE');
        $code = strtoupper(trim((string)$code));
        $svg = \App\Services\BarcodeService::generateSvg($code, 55, 2, true);

        return response($svg, 200, [
            'Content-Type' => 'image/svg+xml',
            'Cache-Control' => 'no-cache, private',
        ]);
    }
}
