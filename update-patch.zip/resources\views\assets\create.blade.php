@extends('layouts.app')

@section('title', 'เพิ่มครุภัณฑ์ใหม่')
@section('page-title', 'เพิ่มครุภัณฑ์คอมพิวเตอร์และอุปกรณ์ IT')
@section('breadcrumb', 'ระบบพัสดุและคลัง / ทะเบียนครุภัณฑ์ IT / เพิ่มรายการใหม่')

@section('topbar-actions')
@if(auth()->user()->isAdmin())
<button type="button" class="topbar-btn" onclick="openImportModal()" title="นำเข้าข้อมูลครุภัณฑ์หลายรายการจากไฟล์ CSV">
    <i class="bi bi-file-earmark-arrow-up text-primary"></i>
    <span>นำเข้าไฟล์ CSV</span>
</button>
@endif
<a href="{{ route('assets.index') }}" class="topbar-btn" title="กลับไปหน้ารายการครุภัณฑ์">
    <i class="bi bi-arrow-left"></i>
    <span>กลับหน้ารายการ</span>
</a>
@endsection

@push('styles')
<style>
    .form-section-card {
        background: #ffffff;
        border-radius: 14px;
        border: 1px solid var(--border);
        box-shadow: 0 2px 8px rgba(0,0,0,0.02);
        margin-bottom: 22px;
        overflow: hidden;
        transition: all 0.2s ease;
    }

    .form-section-card:hover {
        box-shadow: 0 4px 16px rgba(0,0,0,0.04);
        border-color: #cbd5e1;
    }

    .form-section-header {
        padding: 16px 22px;
        background: linear-gradient(to right, #f8fafc, #f1f5f9);
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 10px;
    }

    .form-section-title {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 15px;
        font-weight: 700;
        color: #0f172a;
    }

    .form-section-icon {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    .form-section-body {
        padding: 22px;
    }

    /* Type Selector Chips */
    .type-pill-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 13px;
        border-radius: 999px;
        border: 1px solid #cbd5e1;
        background: #ffffff;
        font-size: 12.5px;
        font-weight: 500;
        color: #334155;
        cursor: pointer;
        transition: all 0.18s ease;
        user-select: none;
    }

    .type-pill-btn:hover {
        background: #f1f5f9;
        border-color: #94a3b8;
        transform: translateY(-1px);
    }

    .type-pill-btn.active {
        background: #0d9488;
        border-color: #0d9488;
        color: #ffffff;
        font-weight: 600;
        box-shadow: 0 2px 8px rgba(13, 148, 136, 0.25);
    }

    /* Status Radio Cards */
    .status-card-group {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(135px, 1fr));
        gap: 10px;
    }

    .status-radio-card {
        border: 2px solid #e2e8f0;
        border-radius: 10px;
        padding: 10px 12px;
        text-align: center;
        cursor: pointer;
        transition: all 0.2s ease;
        background: #ffffff;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
    }

    .status-radio-card:hover {
        border-color: #cbd5e1;
        background: #f8fafc;
    }

    .status-radio-card input {
        display: none;
    }

    .status-radio-card.active-status {
        border-color: #0d9488;
        background: #f0fdfa;
        box-shadow: 0 2px 10px rgba(13, 148, 136, 0.15);
    }

    .status-radio-card.active-status.status-spare {
        border-color: #0284c7;
        background: #f0f9ff;
    }

    .status-radio-card.active-status.status-repairing {
        border-color: #f59e0b;
        background: #fffbeb;
    }

    .status-radio-card.active-status.status-broken {
        border-color: #ef4444;
        background: #fef2f2;
    }

    .status-radio-card.active-status.status-disposed {
        border-color: #64748b;
        background: #f1f5f9;
    }

    /* Quick Preset Buttons */
    .quick-tag {
        font-size: 11px;
        padding: 2px 8px;
        border-radius: 4px;
        background: #f1f5f9;
        border: 1px solid #cbd5e1;
        color: #475569;
        cursor: pointer;
        transition: all 0.15s;
    }

    .quick-tag:hover {
        background: #e2e8f0;
        color: #0f172a;
    }

    /* Image Dropzone */
    .image-dropzone {
        border: 2px dashed #cbd5e1;
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        background: #f8fafc;
        cursor: pointer;
        transition: all 0.2s;
    }

    .image-dropzone:hover {
        border-color: #0d9488;
        background: #f0fdfa;
    }
</style>
@endpush

@section('content')
<div style="max-width: 960px; margin: 0 auto; padding-bottom: 60px;">

    {{-- Admin Quick Import Callout Banner --}}
    @if(auth()->user()->isAdmin())
    <div style="background: linear-gradient(135deg, #f0fdfa 0%, #e0f2fe 100%); border: 1px solid #99f6e4; border-radius: 14px; padding: 16px 20px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px; box-shadow: 0 4px 12px rgba(13, 148, 136, 0.08);">
        <div style="display: flex; align-items: center; gap: 14px;">
            <div style="width: 44px; height: 44px; border-radius: 12px; background: #0d9488; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0;">
                <i class="bi bi-file-earmark-spreadsheet-fill"></i>
            </div>
            <div>
                <div style="font-size: 14.5px; font-weight: 700; color: #0f766e;">
                    มีข้อมูลครุภัณฑ์จำนวนมาก? นำเข้าได้ทันทีผ่านไฟล์ CSV
                </div>
                <div style="font-size: 12.5px; color: #334155; margin-top: 2px;">
                    ดาวน์โหลดเทมเพลตตัวอย่างที่มีสเปคเครื่อง (PC DDR5, Notebook DDR4, All-in-One, Printer) แล้วอัปโหลดเพื่อบันทึกเป็นชุด
                </div>
            </div>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <a href="{{ route('assets.import.template') }}" class="btn btn-sm btn-light border" style="font-weight: 600; display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px;" download>
                <i class="bi bi-download text-primary"></i> ดาวน์โหลดเทมเพลต CSV
            </a>
            <button type="button" onclick="openImportModal()" class="btn btn-sm btn-primary" style="font-weight: 600; display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px;">
                <i class="bi bi-cloud-arrow-up-fill"></i> นำเข้าไฟล์ CSV
            </button>
        </div>
    </div>
    @endif

    {{-- Header Intro --}}
    <div style="margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
        <div>
            <h2 style="font-size: 20px; font-weight: 700; color: #0f172a; margin: 0 0 4px 0;">
                <i class="bi bi-plus-circle-fill text-primary me-1"></i> ลงทะเบียนครุภัณฑ์ใหม่ (Asset Registration)
            </h2>
            <p style="font-size: 13.5px; color: #64748b; margin: 0;">
                กรอกข้อมูลครุภัณฑ์และคุณลักษณะเฉพาะทางฮาร์ดแวร์เพื่อบันทึกลงสู่ระบบคลัง IT
            </p>
        </div>
        <a href="{{ route('assets.index') }}" class="btn btn-secondary btn-sm" style="display: inline-flex; align-items: center; gap: 6px;">
            <i class="bi bi-arrow-left"></i> กลับหน้ารายการ
        </a>
    </div>

    {{-- Main Form --}}
    <form action="{{ route('assets.store') }}" method="POST" enctype="multipart/form-data" id="createAssetForm">
        @csrf

        @if(isset($prefillAudit) && $prefillAudit)
        <div style="background: linear-gradient(135deg, #fdf4ff 0%, #fae8ff 100%); border: 1.5px solid #e879f9; border-radius: 12px; padding: 14px 18px; margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; box-shadow: 0 4px 12px rgba(192, 38, 211, 0.08);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="width: 40px; height: 40px; border-radius: 10px; background: #c026d3; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0;">
                    <i class="bi bi-sparkles"></i>
                </div>
                <div>
                    <strong style="color: #86198f; font-size: 14px;">กำลังลงทะเบียนครุภัณฑ์ใหม่จากผลสแกนฮาร์ดแวร์ประจำปีงบประมาณ {{ $prefillAudit->fiscal_year }}</strong>
                    <div style="font-size: 12px; color: #4b5563; margin-top: 2px;">
                        เครื่อง: <strong>{{ $prefillAudit->hostname }}</strong> &bull; HardwareID: <code style="color: #a21caf; font-weight: 700;">{{ $prefillAudit->hardware_id ?: '-' }}</code> &bull; S/N: <code>{{ $prefillAudit->serial_number ?: '-' }}</code>
                    </div>
                </div>
            </div>
            <span class="badge" style="background: #f0abfc; color: #701a75; font-size: 11.5px; font-weight: 700; padding: 6px 12px; border-radius: 999px;">
                นำเข้าสเปคอัตโนมัติแล้ว
            </span>
        </div>
        @endif

        {{-- SECTION 1: ข้อมูลพื้นฐานและการจำแนกประเภท (Asset Identity) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #e0f2fe; color: #0284c7;">
                        <i class="bi bi-tag-fill"></i>
                    </div>
                    <span>1. ข้อมูลพื้นฐานและประเภทครุภัณฑ์ (Asset Identification)</span>
                </div>
                <span style="font-size: 12px; color: #0284c7; font-weight: 600; background: #e0f2fe; padding: 2px 8px; border-radius: 6px;">
                    ข้อมูลจำเป็น *
                </span>
            </div>

            <div class="form-section-body">
                {{-- Quick Device Type Chips --}}
                <div style="margin-bottom: 18px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <label class="form-label" style="font-size: 12.5px; color: #64748b; margin-bottom: 0;">
                            เลือกประเภทอุปกรณ์ด่วน:
                        </label>
                        @if(auth()->check() && auth()->user()->isAdmin())
                        <a href="{{ route('device-types.index') }}" target="_blank" style="font-size: 11.5px; color: #0284c7; text-decoration: none; font-weight: 500;">
                            <i class="bi bi-gear-fill me-1"></i>จัดการประเภทอุปกรณ์
                        </a>
                        @endif
                    </div>
                    <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                        @foreach($deviceTypes as $type)
                            @php
                                $icon = $type->icon ?: 'bi-device-hdd';
                                if (empty($type->icon)) {
                                    $lower = mb_strtolower($type->name);
                                    if (str_contains($lower, 'ตั้งโต๊ะ') || str_contains($lower, 'pc')) $icon = 'bi-pc-display';
                                    elseif (str_contains($lower, 'โน้ตบุ๊ก') || str_contains($lower, 'notebook') || str_contains($lower, 'laptop')) $icon = 'bi-laptop';
                                    elseif (str_contains($lower, 'all-in-one') || str_contains($lower, 'aio')) $icon = 'bi-display';
                                    elseif (str_contains($lower, 'server') || str_contains($lower, 'เซิร์ฟเวอร์')) $icon = 'bi-server';
                                    elseif (str_contains($lower, 'พิมพ์') || str_contains($lower, 'printer')) $icon = 'bi-printer';
                                    elseif (str_contains($lower, 'สแกนเนอร์') || str_contains($lower, 'scanner')) $icon = 'bi-scanner';
                                    elseif (str_contains($lower, 'เครือข่าย') || str_contains($lower, 'switch') || str_contains($lower, 'router')) $icon = 'bi-hdd-network';
                                }

                                $isActiveType = old('device_type_id') == $type->id;
                                if (!$isActiveType && isset($prefillAudit)) {
                                    $code = strtoupper($prefillAudit->device_type_code ?? '');
                                    if ($type->code === $code) $isActiveType = true;
                                }
                            @endphp
                            <button type="button" class="type-pill-btn {{ $isActiveType ? 'active' : '' }}"
                                    data-type-id="{{ $type->id }}"
                                    data-type-name="{{ $type->name }}"
                                    onclick="selectDeviceType('{{ $type->id }}', this)">
                                <i class="bi {{ $icon }}"></i>
                                <span>{{ $type->name }}</span>
                            </button>
                        @endforeach
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group" style="flex: 1.2;">
                        <label class="form-label required" for="asset_code">หมายเลขครุภัณฑ์ (Asset Code)</label>
                        <input type="text" id="asset_code" name="asset_code" class="form-control"
                               value="{{ old('asset_code') }}" placeholder="เช่น 7440-001-0001/67" required autofocus>
                        <span class="form-text">รหัสหมายเลขครุภัณฑ์ตามทะเบียนพัสดุ รพ.ทุ่งหัวช้าง</span>
                    </div>

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="serial_number">Serial Number (S/N)</label>
                        <input type="text" id="serial_number" name="serial_number" class="form-control"
                               value="{{ old('serial_number', $prefillAudit->serial_number ?? '') }}" placeholder="เช่น S/N บนตัวเครื่อง">
                        <span class="form-text">หมายเลขประจำเครื่องจากผู้ผลิต</span>
                    </div>

                    <div class="form-group" style="flex: 1.1;">
                        <label class="form-label" for="hardware_id">
                            <i class="bi bi-fingerprint" style="color: #a21caf;"></i> HardwareID (UUID)
                        </label>
                        <input type="text" id="hardware_id" name="hardware_id" class="form-control" style="font-family: monospace;"
                               value="{{ old('hardware_id', $prefillAudit->hardware_id ?? '') }}" placeholder="SMBIOS UUID ประจำเครื่อง">
                        <span class="form-text">ระบุอัตโนมัติจาก Agent สแกนสเปค</span>
                    </div>

                    <div class="form-group" style="flex: 1.2;">
                        <label class="form-label required" for="device_type_id">ประเภทอุปกรณ์ (Device Type)</label>
                        <select name="device_type_id" id="device_type_id" class="form-select" required onchange="handleTypeDropdownChange(this)">
                            <option value="">-- กรุณาเลือกประเภท --</option>
                            @foreach($deviceTypes as $type)
                                @php
                                    $isSel = old('device_type_id') == $type->id;
                                    if (!$isSel && isset($prefillAudit)) {
                                        $code = strtoupper($prefillAudit->device_type_code ?? '');
                                        if ($type->code === $code) $isSel = true;
                                    }
                                @endphp
                                <option value="{{ $type->id }}" data-code="{{ $type->code }}" {{ $isSel ? 'selected' : '' }}>
                                    {{ $type->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                {{-- ICT Standard Catalog Selector (เกณฑ์ราคากลางกระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม) --}}
                <div style="background: linear-gradient(135deg, #f8fafc 0%, #f0fdfa 100%); border: 1.5px solid #99f6e4; border-radius: 12px; padding: 16px; margin-bottom: 20px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <div style="width: 28px; height: 28px; border-radius: 7px; background: #0d9488; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 14px;">
                                <i class="bi bi-bookmark-check-fill"></i>
                            </div>
                            <div>
                                <strong style="font-size: 13.5px; color: #0f766e;">เลือกชื่อรายการตามเกณฑ์ราคากลางและคุณลักษณะพื้นฐานฯ</strong>
                                <span style="font-size: 11.5px; color: #64748b; margin-left: 4px;">(กระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม)</span>
                            </div>
                        </div>
                        <span id="ictStandardBadge" style="display: none; background: #ccfbf1; color: #0f766e; border: 1px solid #5eead4; font-size: 11.5px; font-weight: 600; padding: 3px 10px; border-radius: 999px;">
                            <i class="bi bi-patch-check-fill text-success me-1"></i> ตรงตามเกณฑ์มาตรฐานภาครัฐ
                        </span>
                    </div>

                    {{-- Grouped Select by Category --}}
                    <div style="margin-bottom: 10px;">
                        <select id="ict_standard_select" class="form-select" onchange="handleIctStandardSelect(this.value)" style="border-color: #5eead4; background-color: #ffffff; font-size: 13.5px; font-weight: 500;">
                            <option value="">-- คลิกเพื่อเลือกชื่อตามเกณฑ์ราคากลาง ICT (มีสเปคและราคากลางแนะนำ) --</option>
                            @if(isset($ictStandardsGrouped))
                                @foreach($ictStandardsGrouped as $category => $items)
                                    <optgroup label="📁 {{ $category }}">
                                        @foreach($items as $item)
                                            <option value="{{ $item['code'] }}">
                                                {{ $item['name'] }} (ราคากลาง: {{ number_format($item['standard_price']) }} บาท)
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endforeach
                            @endif
                        </select>
                    </div>

                    {{-- Quick Popular Standard Pills --}}
                    <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center;">
                        <span style="font-size: 11px; font-weight: 600; color: #0d9488;">เกณฑ์ยอดนิยม:</span>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PC-PROC-2')">💻 PC ประมวลผล (แบบ 2 - 27,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PC-OFFICE')">💻 PC สำนักงาน (17,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('NB-PROC')">💻 โน้ตบุ๊กประมวลผล (26,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('NB-OFFICE')">💻 โน้ตบุ๊ก สนง. (21,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('AIO-PROC')">🖥️ All-in-One (23,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-LASER-NET')">🖨️ เลเซอร์ Network (8,500 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-MFP-MONO')">🖨️ มัลติฟังก์ชันเลเซอร์ (7,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-INK-TANK')">🖨️ Ink Tank แท้ (5,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('PRN-LABEL-BARCODE')">🏷️ พิมพ์สติกเกอร์ยา (12,000 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('UPS-800VA')">🔋 UPS 800VA (2,500 บ.)</button>
                        <button type="button" class="quick-tag" onclick="selectIctByCode('SCN-SMART-CARD')">💳 อ่านบัตร ปชช. (500 บ.)</button>
                    </div>

                    {{-- Description & Specs Hint Box (Appears when item selected) --}}
                    <div id="ictInfoBox" style="display: none; margin-top: 10px; padding: 10px 14px; background: #ffffff; border: 1px solid #99f6e4; border-radius: 8px; font-size: 12px; color: #334155;">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; flex-wrap: wrap;">
                            <div style="flex: 1; min-width: 240px;">
                                <strong id="ictInfoTitle" style="color: #0f766e; font-size: 12.5px;">-</strong>
                                <div id="ictInfoDesc" style="color: #64748b; margin-top: 2px; line-height: 1.4;">-</div>
                            </div>
                            <div style="text-align: right; flex-shrink: 0;">
                                <span style="font-size: 11px; color: #64748b;">ราคากลางมาตรฐาน:</span>
                                <div id="ictInfoPrice" style="font-size: 14.5px; font-weight: 700; color: #0284c7;">-</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group" style="flex: 1.5;">
                        <label class="form-label required" for="name">
                            ชื่อรายการครุภัณฑ์ (Asset Name)
                            <small class="text-muted" style="font-weight: 400;">(สามารถเลือกจากเกณฑ์ด้านบน หรือพิมพ์แก้ไขต่อท้ายได้)</small>
                        </label>
                        <input type="text" id="name" name="name" class="form-control"
                               value="{{ old('name', isset($prefillAudit) ? 'เครื่องคอมพิวเตอร์ ' . ($prefillAudit->brand ? $prefillAudit->brand . ' ' : '') . ($prefillAudit->model ?: $prefillAudit->hostname) : '') }}" placeholder="เช่น เครื่องคอมพิวเตอร์ สำหรับงานประมวลผล แบบที่ 2 (ห้องตรวจ 1)" required>
                        <span class="form-text">ชื่อทางการสำหรับทะเบียนพัสดุและรายงานตามระเบียบราชการ</span>
                    </div>

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="brand">ยี่ห้อ (Brand)</label>
                        <input type="text" id="brand" name="brand" class="form-control" list="brand_suggestions"
                               value="{{ old('brand', $prefillAudit->brand ?? '') }}" placeholder="เช่น Dell, HP, Lenovo, Brother">
                        <datalist id="brand_suggestions">
                            <option value="Dell">
                            <option value="HP">
                            <option value="Lenovo">
                            <option value="Acer">
                            <option value="Asus">
                            <option value="Brother">
                            <option value="Canon">
                            <option value="Epson">
                            <option value="Cisco">
                            <option value="Ruijie">
                            <option value="MikroTik">
                        </datalist>
                    </div>

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="model">รุ่น (Model)</label>
                        <input type="text" id="model" name="model" class="form-control"
                               value="{{ old('model', $prefillAudit->model ?? '') }}" placeholder="เช่น OptiPlex 7010, ThinkCentre">
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 2: คุณลักษณะเฉพาะทางฮาร์ดแวร์ & สเปคเครื่อง (Hardware Specifications) --}}
        <div class="form-section-card" id="hardwareSpecsSection">
            <div class="form-section-header" style="background: linear-gradient(to right, #f0fdfa, #f8fafc);">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #ccfbf1; color: #0d9488;">
                        <i class="bi bi-cpu-fill"></i>
                    </div>
                    <span>2. คุณลักษณะและสเปคฮาร์ดแวร์ (Hardware Specifications)</span>
                </div>
                <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                    <button type="button" class="btn btn-sm btn-primary" onclick="openClientHardwareModal('deep')" style="font-size: 12px; font-weight: 600; padding: 4px 12px; border-radius: 7px; display: inline-flex; align-items: center; gap: 5px; background: linear-gradient(135deg, #0d9488 0%, #0284c7 100%); border: none;">
                        <i class="bi bi-shield-check"></i> ⚡ สแกนสเปคจริง 100%
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-success" onclick="pasteHardwareSpecsFromClipboard()" style="font-size: 12px; font-weight: 600; padding: 4px 10px; border-radius: 7px; display: inline-flex; align-items: center; gap: 4px; background: #ffffff;">
                        <i class="bi bi-clipboard-check"></i> วางสเปค
                    </button>
                    <span style="font-size: 11.5px; color: #0f766e; background: #e6fffa; border: 1px solid #99f6e4; padding: 2px 8px; border-radius: 6px;">
                        สำหรับ PC, โน้ตบุ๊ก, All-in-One, Server
                    </span>
                </div>
            </div>

            <div class="form-section-body" style="padding-bottom: 12px;">
                @include('assets._specs_form')
            </div>
        </div>

        {{-- SECTION 3: สถานที่ติดตั้งและผู้ครอบครอง (Location & Custodian) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #ede9fe; color: #7c3aed;">
                        <i class="bi bi-geo-alt-fill"></i>
                    </div>
                    <span>3. สถานที่ติดตั้งและผู้ครอบครอง (Location & Custodian)</span>
                </div>
            </div>

            <div class="form-section-body">
                <div class="form-row">
                    <div class="form-group" style="flex: 1.2;">
                        <label class="form-label" for="department_id">
                            <i class="bi bi-building text-secondary"></i> แผนก / หน่วยงานที่รับผิดชอบ
                        </label>
                        <select name="department_id" id="department_id" class="form-select">
                            <option value="">-- ไม่ระบุแผนก --</option>
                            @foreach($departments as $dept)
                                <option value="{{ $dept->id }}" {{ old('department_id') == $dept->id ? 'selected' : '' }}>
                                    {{ $dept->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group" style="flex: 1.2;">
                        <label class="form-label" for="location_detail">
                            <i class="bi bi-pin-map text-danger"></i> จุดที่ตั้ง / ห้องทำงาน
                        </label>
                        <input type="text" id="location_detail" name="location_detail" class="form-control"
                               value="{{ old('location_detail') }}" placeholder="เช่น เคาน์เตอร์พยาบาล, โต๊ะทำงานชั้น 2">
                        <div style="display: flex; gap: 6px; margin-top: 6px; flex-wrap: wrap; align-items: center;">
                            <span style="font-size: 11px; color: #64748b;">ตำแหน่งด่วน:</span>
                            <span class="quick-tag" onclick="setLocation('เคาน์เตอร์พยาบาล')">เคาน์เตอร์พยาบาล</span>
                            <span class="quick-tag" onclick="setLocation('ห้องตรวจแพทย์ 1')">ห้องตรวจแพทย์ 1</span>
                            <span class="quick-tag" onclick="setLocation('ห้องจ่ายยา / เภสัชกรรม')">ห้องจ่ายยา</span>
                            <span class="quick-tag" onclick="setLocation('ห้องการเงินและบัญชี')">ห้องการเงิน</span>
                            <span class="quick-tag" onclick="setLocation('ห้องเซิร์ฟเวอร์ / งาน IT')">งาน IT</span>
                        </div>
                    </div>

                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="custodian_name">
                            <i class="bi bi-person-fill text-primary"></i> ชื่อผู้ครอบครอง / ผู้ดูแล
                        </label>
                        <input type="text" id="custodian_name" name="custodian_name" class="form-control"
                               value="{{ old('custodian_name') }}" placeholder="เช่น พว.สุดาพร ใจดี">
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 4: การเชื่อมต่อเครือข่าย (Network Settings) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #e0f2fe; color: #0369a1;">
                        <i class="bi bi-hdd-network-fill"></i>
                    </div>
                    <span>4. การเชื่อมต่อเครือข่าย (Network Settings)</span>
                </div>
                <span style="font-size: 12px; color: #64748b;">Subnet รพ.ทุ่งหัวช้าง 192.168.2.x</span>
            </div>

            <div class="form-section-body">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="ip_address">
                            <i class="bi bi-router text-primary"></i> IP Address
                        </label>
                        <input type="text" id="ip_address" name="ip_address" class="form-control"
                               value="{{ old('ip_address', $prefillAudit->ip_address ?? '') }}" placeholder="เช่น 192.168.2.55">
                        <span class="form-text">IP Address ภายในระบบ LAN โรงพยาบาล</span>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="mac_address">
                            <i class="bi bi-ethernet text-secondary"></i> MAC Address
                        </label>
                        <input type="text" id="mac_address" name="mac_address" class="form-control"
                               value="{{ old('mac_address', $prefillAudit->mac_address ?? '') }}" placeholder="เช่น 00:1A:2B:3C:4D:5E">
                        <span class="form-text">Hardware Address การ์ดแลน / Wi-Fi</span>
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 5: การจัดซื้อ, ประกัน & สถานะ (Procurement & Status) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #fef3c7; color: #d97706;">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <span>5. ข้อมูลการจัดซื้อ ประกัน และสถานะครุภัณฑ์ (Procurement & Status)</span>
                </div>
            </div>

            <div class="form-section-body">
                {{-- Status Selection --}}
                <div style="margin-bottom: 20px;">
                    <label class="form-label required" style="margin-bottom: 8px;">สถานะครุภัณฑ์ (Asset Status)</label>
                    <div class="status-card-group">
                        @php $currentStatus = old('status', 'active'); @endphp
                        <label class="status-radio-card {{ $currentStatus == 'active' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="active" {{ $currentStatus == 'active' ? 'checked' : '' }} required>
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #065f46;">ใช้งานปกติ</strong>
                            <span style="font-size: 11px; color: #64748b;">Active</span>
                        </label>

                        <label class="status-radio-card status-spare {{ $currentStatus == 'spare' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="spare" {{ $currentStatus == 'spare' ? 'checked' : '' }}>
                            <i class="bi bi-shield-check text-info" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #0284c7;">เครื่องสำรอง</strong>
                            <span style="font-size: 11px; color: #64748b;">Spare</span>
                        </label>

                        <label class="status-radio-card status-repairing {{ $currentStatus == 'repairing' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="repairing" {{ $currentStatus == 'repairing' ? 'checked' : '' }}>
                            <i class="bi bi-tools text-warning" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #d97706;">ส่งซ่อม</strong>
                            <span style="font-size: 11px; color: #64748b;">In Repair</span>
                        </label>

                        <label class="status-radio-card status-broken {{ $currentStatus == 'broken' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="broken" {{ $currentStatus == 'broken' ? 'checked' : '' }}>
                            <i class="bi bi-exclamation-octagon-fill text-danger" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #dc2626;">ชำรุดรอซ่อม</strong>
                            <span style="font-size: 11px; color: #64748b;">Broken</span>
                        </label>

                        <label class="status-radio-card status-disposed {{ $currentStatus == 'disposed' ? 'active-status' : '' }}" onclick="selectStatusCard(this)">
                            <input type="radio" name="status" value="disposed" {{ $currentStatus == 'disposed' ? 'checked' : '' }}>
                            <i class="bi bi-archive-fill text-secondary" style="font-size: 20px;"></i>
                            <strong style="font-size: 13px; color: #475569;">รอแทงจำหน่าย</strong>
                            <span style="font-size: 11px; color: #64748b;">Disposed</span>
                        </label>
                    </div>
                </div>

                {{-- วิธีการได้มา แหล่งเงิน และกรรมสิทธิ์ (Acquisition, Funding & Ownership) --}}
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px 18px; margin-bottom: 20px;">
                    <div style="font-size: 13.5px; font-weight: 700; color: #1e293b; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                        <i class="bi bi-wallet2 text-primary"></i>
                        <span>วิธีการได้มา แหล่งเงินงบประมาณ และกรรมสิทธิ์การครอบครอง</span>
                    </div>
                    
                    <div class="form-row" style="margin-bottom: 12px;">
                        {{-- วิธีการได้มาของครุภัณฑ์ --}}
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label" for="acquisition_method_id">
                                วิธีการได้มาของครุภัณฑ์
                                <a href="{{ route('acquisition-methods.index') }}" target="_blank" class="text-primary text-decoration-none ms-1" style="font-size: 11px;" title="จัดการวิธีการได้มา">+ จัดการตัวเลือก</a>
                            </label>
                            <select id="acquisition_method_id" name="acquisition_method_id" class="form-select" onchange="handleAcquisitionMethodChange(this)">
                                <option value="">-- ไม่ระบุ / ระบุภายหลัง --</option>
                                @foreach($acquisitionMethods as $method)
                                    <option value="{{ $method->id }}" 
                                            data-code="{{ $method->code }}"
                                            {{ old('acquisition_method_id') == $method->id ? 'selected' : '' }}>
                                        {{ $method->name }} {{ $method->code ? '('.$method->code.')' : '' }}
                                    </option>
                                @endforeach
                            </select>
                            <span class="form-text" style="font-size: 11.5px; color: #64748b;">เช่น จัดซื้อจัดจ้าง, ได้รับบริจาค, เช่าใช้บริการ, รับโอน</span>
                        </div>

                        {{-- แหล่งเงินที่ใช้ซื้อ --}}
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label" for="budget_source_id">
                                แหล่งเงินที่ใช้ซื้อ / แหล่งงบประมาณ
                                <a href="{{ route('budget-sources.index') }}" target="_blank" class="text-primary text-decoration-none ms-1" style="font-size: 11px;" title="จัดการแหล่งเงินงบประมาณ">+ จัดการตัวเลือก</a>
                            </label>
                            <select id="budget_source_id" name="budget_source_id" class="form-select">
                                <option value="">-- ไม่ระบุ / ระบุภายหลัง --</option>
                                @foreach($budgetSources as $source)
                                    <option value="{{ $source->id }}" 
                                            {{ old('budget_source_id') == $source->id ? 'selected' : '' }}>
                                        {{ $source->name }} {{ $source->code ? '('.$source->code.')' : '' }}
                                    </option>
                                @endforeach
                            </select>
                            <span class="form-text" style="font-size: 11.5px; color: #64748b;">เช่น เงิน UC, เงินเก็บค่าบริการ (เงินบำรุง), เงินงบประมาณแผ่นดิน</span>
                        </div>

                        {{-- ประเภทกรรมสิทธิ์ / การครอบครอง --}}
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label required" for="ownership_type">ประเภทกรรมสิทธิ์ / การครอบครอง</label>
                            @php $curOwnership = old('ownership_type', 'owned'); @endphp
                            <select id="ownership_type" name="ownership_type" class="form-select" onchange="toggleRentalBox(this.value)" required>
                                <option value="owned" {{ $curOwnership == 'owned' ? 'selected' : '' }}>🏢 เป็นของ รพ. (ซื้อขาด)</option>
                                <option value="rented" {{ $curOwnership == 'rented' ? 'selected' : '' }}>🖨️ เช่าใช้ (เครื่องเช่า / สัญญาเช่า)</option>
                                <option value="donated" {{ $curOwnership == 'donated' ? 'selected' : '' }}>🎁 ได้รับบริจาค</option>
                                <option value="borrowed" {{ $curOwnership == 'borrowed' ? 'selected' : '' }}>🔄 ยืมใช้งานภายนอก</option>
                            </select>
                            <span class="form-text" style="font-size: 11.5px; color: #64748b;">เลือก "เช่าใช้" สำหรับเครื่องพิมพ์หรืออุปกรณ์ที่เช่ารายเดือน/รายปี</span>
                        </div>
                    </div>

                    {{-- Collapsible Rental Contract Details Box (เครื่องเช่า เช่น เครื่องพิมพ์เช่า) --}}
                    <div id="rentalContractBox" style="display: {{ $curOwnership == 'rented' ? 'block' : 'none' }}; background: #fffaf5; border: 1.5px dashed #fdba74; border-radius: 10px; padding: 16px; margin-top: 14px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px dashed #fed7aa; padding-bottom: 8px;">
                            <div style="font-size: 13px; font-weight: 700; color: #c2410c; display: flex; align-items: center; gap: 6px;">
                                <i class="bi bi-printer-fill" style="font-size: 16px;"></i>
                                <span>ข้อมูลสัญญาเช่าและบริษัทผู้ให้เช่า (Lease / Rental Contract Details)</span>
                            </div>
                            <span class="badge" style="background: #ffedd5; color: #c2410c; border: 1px solid #fdba74; font-size: 11px;">
                                สำหรับควบคุมเครื่องเช่า & เครื่องพิมพ์เช่า
                            </span>
                        </div>

                        <div class="form-row" style="margin-bottom: 10px;">
                            <div class="form-group" style="flex: 1.2;">
                                <label class="form-label" for="rental_contract_no">เลขที่สัญญาเช่า</label>
                                <input type="text" id="rental_contract_no" name="rental_contract_no" class="form-control" 
                                       placeholder="เช่น CN-IT-2567/012, สัญญาเช่าที่ 45/2567" 
                                       value="{{ old('rental_contract_no') }}">
                            </div>

                            <div class="form-group" style="flex: 1.5;">
                                <label class="form-label" for="rental_vendor">บริษัทผู้ให้เช่า / คู่สัญญา</label>
                                <input type="text" id="rental_vendor" name="rental_vendor" class="form-control" 
                                       placeholder="เช่น บจก. ฟูจิฟิล์ม บิสซิเนสฯ, ริโก้ (ประเทศไทย), แคนนอน" 
                                       value="{{ old('rental_vendor') }}">
                            </div>

                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_contact_phone">เบอร์ติดต่อบริษัท/ช่างบริการ</label>
                                <input type="text" id="rental_contact_phone" name="rental_contact_phone" class="form-control" 
                                       placeholder="เช่น 02-xxx-xxxx, 081-xxx-xxxx" 
                                       value="{{ old('rental_contact_phone') }}">
                            </div>
                        </div>

                        <div class="form-row" style="margin-bottom: 10px;">
                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_start_date">วันเริ่มสัญญาเช่า</label>
                                <input type="date" id="rental_start_date" name="rental_start_date" class="form-control" 
                                       value="{{ old('rental_start_date') }}">
                            </div>

                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_end_date">วันสิ้นสุดสัญญาเช่า</label>
                                <input type="date" id="rental_end_date" name="rental_end_date" class="form-control" 
                                       value="{{ old('rental_end_date') }}">
                            </div>

                            <div class="form-group" style="flex: 1;">
                                <label class="form-label" for="rental_monthly_fee">ค่าเช่ารายเดือน/งวด (บาท)</label>
                                <div style="position: relative;">
                                    <input type="number" step="0.01" id="rental_monthly_fee" name="rental_monthly_fee" class="form-control" 
                                           placeholder="เช่น 2500.00" 
                                           value="{{ old('rental_monthly_fee') }}" style="padding-right: 42px;">
                                    <span style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 12px; color: #94a3b8;">บาท</span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="rental_conditions">เงื่อนไขสัญญาและบริการ (Conditions & Service Level)</label>
                            <textarea id="rental_conditions" name="rental_conditions" class="form-control" rows="2" 
                                      placeholder="เช่น รวมหมึกพิมพ์ทุกสีและค่าบริการซ่อมบำรุง, โควตาพิมพ์ขาวดำ 5,000 แผ่น/เดือน, สี 1,000 แผ่น/เดือน ส่วนเกินแผ่นละ 0.50 บาท">{{ old('rental_conditions') }}</textarea>
                        </div>
                    </div>
                </div>

                {{-- Financial & Dates --}}
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="purchase_date">วันที่ตรวจรับ / ซื้อ</label>
                        <input type="date" id="purchase_date" name="purchase_date" class="form-control"
                               value="{{ old('purchase_date') }}" onchange="handlePurchaseDateChange(this.value)">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="price">ราคาจัดซื้อ (บาท)</label>
                        <div style="position: relative;">
                            <input type="number" step="0.01" id="price" name="price" class="form-control"
                                   value="{{ old('price') }}" placeholder="เช่น 24500.00" style="padding-right: 42px;">
                            <span style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 13px; color: #94a3b8;">บาท</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="warranty_expire_date">วันหมดประกัน</label>
                        <input type="date" id="warranty_expire_date" name="warranty_expire_date" class="form-control"
                               value="{{ old('warranty_expire_date') }}">
                        <div style="display: flex; gap: 6px; margin-top: 6px; flex-wrap: wrap; align-items: center;">
                            <span style="font-size: 11px; color: #64748b;">คำนวณ:</span>
                            <span class="quick-tag" onclick="addWarrantyYears(1)">+1 ปี</span>
                            <span class="quick-tag" onclick="addWarrantyYears(3)">+3 ปี</span>
                            <span class="quick-tag" onclick="addWarrantyYears(5)">+5 ปี</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="budget_year">ปีงบประมาณ</label>
                        <input type="text" id="budget_year" name="budget_year" class="form-control"
                               value="{{ old('budget_year', $prefillAudit->fiscal_year ?? '2569') }}" placeholder="เช่น 2568, 2569">
                    </div>
                </div>
            </div>
        </div>

        {{-- SECTION 6: รูปถ่ายและหมายเหตุเพิ่มเติม (Photo & Notes) --}}
        <div class="form-section-card">
            <div class="form-section-header">
                <div class="form-section-title">
                    <div class="form-section-icon" style="background: #f1f5f9; color: #475569;">
                        <i class="bi bi-camera-fill"></i>
                    </div>
                    <span>6. รูปถ่ายครุภัณฑ์และหมายเหตุ (Photo & Notes)</span>
                </div>
            </div>

            <div class="form-section-body">
                <div class="form-row">
                    <div class="form-group" style="flex: 1;">
                        <label class="form-label" for="image">รูปถ่ายครุภัณฑ์ (Asset Image)</label>
                        <div class="image-dropzone" onclick="document.getElementById('image').click()">
                            <input type="file" id="image" name="image" class="form-control" accept="image/*" style="display: none;" onchange="previewAssetImage(event)">
                            <div id="imageUploadPrompt">
                                <i class="bi bi-cloud-arrow-up text-primary" style="font-size: 28px;"></i>
                                <div style="font-size: 13px; font-weight: 600; color: #1e293b; margin-top: 4px;">คลิกเพื่ออัปโหลดรูปถ่าย</div>
                                <div style="font-size: 11.5px; color: #64748b;">รองรับไฟล์ JPG, PNG สูงสุด 3MB</div>
                            </div>
                            <div id="imagePreviewBox" style="display: none; align-items: center; justify-content: center; gap: 12px; margin-top: 8px;">
                                <img id="imagePreviewImg" src="" alt="ตัวอย่างรูปถ่าย" style="max-height: 100px; border-radius: 8px; border: 1px solid #cbd5e1; box-shadow: 0 2px 6px rgba(0,0,0,0.1);">
                                <button type="button" class="btn btn-sm btn-light border text-danger" onclick="removeAssetImage(event)" title="ลบรูป">
                                    <i class="bi bi-trash"></i> ลบรูป
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group" style="flex: 1.5;">
                        <label class="form-label" for="notes">หมายเหตุเพิ่มเติม (Notes)</label>
                        <textarea id="notes" name="notes" class="form-control" rows="4" placeholder="บันทึกข้อมูลเพิ่มเติม เช่น ประวัติการโยกย้าย, รหัสพัสดุเดิม, อุปกรณ์ต่อพ่วงที่มาด้วยกัน...">{{ old('notes') }}</textarea>
                    </div>
                </div>
            </div>
        </div>

        {{-- Form Actions Bar --}}
        <div style="background: #ffffff; border: 1px solid var(--border); border-radius: 14px; padding: 18px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px; box-shadow: 0 4px 16px rgba(0,0,0,0.04);">
            <a href="{{ route('assets.index') }}" class="btn btn-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                <i class="bi bi-x-circle"></i>
                <span>ยกเลิก</span>
            </a>

            <div style="display: flex; align-items: center; gap: 10px;">
                <button type="reset" class="btn btn-light border" style="display: inline-flex; align-items: center; gap: 6px;" onclick="handleReset()">
                    <i class="bi bi-arrow-counterclockwise"></i> ล้างฟอร์ม
                </button>
                <button type="submit" class="btn btn-primary btn-lg" style="display: inline-flex; align-items: center; gap: 8px; padding: 10px 24px; font-weight: 600; box-shadow: 0 4px 14px rgba(13, 148, 136, 0.3);">
                    <i class="bi bi-floppy-fill"></i>
                    <span>บันทึกครุภัณฑ์ใหม่</span>
                </button>
            </div>
        </div>
    </form>
</div>

{{-- Reusable CSV Import Modal for Admin --}}
@include('assets._import_modal')

@endsection

@push('scripts')
<script>
    // Set Device Type from Pills
    function selectDeviceType(typeId, buttonElem) {
        const select = document.getElementById('device_type_id');
        if (select) {
            select.value = typeId;
            handleTypeDropdownChange(select);
        }

        // Update pills active class
        document.querySelectorAll('.type-pill-btn').forEach(btn => btn.classList.remove('active'));
        if (buttonElem) {
            buttonElem.classList.add('active');
        }
    }

    function handleTypeDropdownChange(selectElem) {
        const typeId = selectElem.value;
        const selectedText = selectElem.options[selectElem.selectedIndex]?.text?.toLowerCase() || '';

        // Sync pills active state
        document.querySelectorAll('.type-pill-btn').forEach(btn => {
            if (btn.getAttribute('data-type-id') === typeId) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        // Highlight hardware section if computer/notebook/server
        const hwSection = document.getElementById('hardwareSpecsSection');
        const isComputer = selectedText.includes('คอมพิวเตอร์') || 
                           selectedText.includes('โน้ตบุ๊ก') || 
                           selectedText.includes('notebook') || 
                           selectedText.includes('all-in-one') || 
                           selectedText.includes('server');

        if (hwSection) {
            if (isComputer) {
                hwSection.style.border = '2px solid #0d9488';
                hwSection.style.boxShadow = '0 6px 20px rgba(13, 148, 136, 0.12)';
            } else {
                hwSection.style.border = '1px solid var(--border)';
                hwSection.style.boxShadow = '0 2px 8px rgba(0,0,0,0.02)';
            }
        }
    }

    // Quick fill helpers
    function setName(val) {
        const input = document.getElementById('name');
        if (input) input.value = val;
    }

    function setLocation(val) {
        const input = document.getElementById('location_detail');
        if (input) input.value = val;
    }

    // Status Radio Card Selector
    function selectStatusCard(cardElem) {
        document.querySelectorAll('.status-radio-card').forEach(c => c.classList.remove('active-status'));
        cardElem.classList.add('active-status');
        const radio = cardElem.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
    }

    // Auto Warranty Calculation
    function addWarrantyYears(years) {
        const purchaseInput = document.getElementById('purchase_date');
        const warrantyInput = document.getElementById('warranty_expire_date');
        if (!purchaseInput || !purchaseInput.value) {
            alert('กรุณาระบุ วันที่ตรวจรับ/ซื้อ ก่อนคำนวณวันหมดประกัน');
            return;
        }

        const date = new Date(purchaseInput.value);
        date.setFullYear(date.getFullYear() + years);
        warrantyInput.value = date.toISOString().split('T')[0];
    }

    function handlePurchaseDateChange(val) {
        const budgetYearInput = document.getElementById('budget_year');
        if (val && budgetYearInput && (!budgetYearInput.value || budgetYearInput.value === '2568')) {
            const date = new Date(val);
            const gregorianYear = date.getFullYear();
            const month = date.getMonth() + 1;
            // Thai Fiscal Year: Oct (month 10) starts new budget year
            const budgetYear = (month >= 10 ? gregorianYear + 1 : gregorianYear) + 543;
            budgetYearInput.value = budgetYear;
        }
    }

    // Image Upload & Preview
    function previewAssetImage(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(evt) {
                document.getElementById('imagePreviewImg').src = evt.target.result;
                document.getElementById('imageUploadPrompt').style.display = 'none';
                document.getElementById('imagePreviewBox').style.display = 'flex';
            };
            reader.readAsDataURL(file);
        }
    }

    function removeAssetImage(e) {
        if (e) e.stopPropagation();
        const input = document.getElementById('image');
        if (input) input.value = '';
        document.getElementById('imagePreviewImg').src = '';
        document.getElementById('imagePreviewBox').style.display = 'none';
        document.getElementById('imageUploadPrompt').style.display = 'block';
    }

    function handleReset() {
        setTimeout(() => {
            document.querySelectorAll('.type-pill-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.status-radio-card').forEach(c => c.classList.remove('active-status'));
            const activeCard = document.querySelector('.status-radio-card input[value="active"]')?.parentElement;
            if (activeCard) activeCard.classList.add('active-status');
            removeAssetImage();

            // Reset ICT Standard box
            const ictSelect = document.getElementById('ict_standard_select');
            if (ictSelect) ictSelect.value = '';
            const badge = document.getElementById('ictStandardBadge');
            if (badge) badge.style.display = 'none';
            const infoBox = document.getElementById('ictInfoBox');
            if (infoBox) infoBox.style.display = 'none';
        }, 50);
    }

    // ICT Standard Catalog Integration
    const ictCatalog = @json($ictStandardsAll ?? []);

    function selectIctByCode(code) {
        const select = document.getElementById('ict_standard_select');
        if (select) {
            select.value = code;
            handleIctStandardSelect(code);
        }
    }

    function handleIctStandardSelect(code) {
        if (!code) {
            document.getElementById('ictStandardBadge').style.display = 'none';
            document.getElementById('ictInfoBox').style.display = 'none';
            return;
        }

        const item = ictCatalog.find(i => i.code === code);
        if (!item) return;

        // 1. Set Asset Name
        const nameInput = document.getElementById('name');
        if (nameInput) {
            nameInput.value = item.name;
        }

        // 2. Select Matching Device Type
        if (item.device_type_code) {
            const devSelect = document.getElementById('device_type_id');
            if (devSelect) {
                const opt = Array.from(devSelect.options).find(o => o.getAttribute('data-code') === item.device_type_code);
                if (opt) {
                    devSelect.value = opt.value;
                    handleTypeDropdownChange(devSelect);
                }
            }
        }

        // 3. Recommend Standard Price if price is empty
        const priceInput = document.getElementById('price');
        if (priceInput && (!priceInput.value || priceInput.getAttribute('data-auto-filled') === 'true')) {
            priceInput.value = parseFloat(item.standard_price).toFixed(2);
            priceInput.setAttribute('data-auto-filled', 'true');
        }

        // 4. Fill Recommended Specs (if available)
        if (item.specs) {
            const setVal = (id, val) => {
                const elem = document.getElementById(id);
                if (elem && val !== undefined && val !== null && val !== '') {
                    elem.value = val;
                }
            };

            setVal('cpu_model', item.specs.cpu_model);
            setVal('cpu_speed', item.specs.cpu_speed);
            setVal('ram_capacity', item.specs.ram_capacity);
            setVal('ram_type', item.specs.ram_type);
            setVal('ram_bus', item.specs.ram_bus);
            setVal('ram_slots', item.specs.ram_slots);
            setVal('storage_type', item.specs.storage_type);
            setVal('storage_capacity', item.specs.storage_capacity);
            setVal('storage_second', item.specs.storage_second);
            setVal('os_name', item.specs.os_name);
            setVal('os_license', item.specs.os_license);
            setVal('gpu_model', item.specs.gpu_model);
            setVal('monitor_size', item.specs.monitor_size);

            if (typeof updateLiveSpecsPreview === 'function') {
                updateLiveSpecsPreview();
            }
        }

        // 5. Display ICT Info Box & Badge
        const badge = document.getElementById('ictStandardBadge');
        if (badge) {
            badge.style.display = 'inline-flex';
            badge.innerHTML = '<i class="bi bi-patch-check-fill text-success me-1"></i> เกณฑ์มาตรฐาน ICT (ราคากลาง ' + Number(item.standard_price).toLocaleString() + ' บาท)';
        }

        const infoBox = document.getElementById('ictInfoBox');
        if (infoBox) {
            infoBox.style.display = 'block';
            document.getElementById('ictInfoTitle').textContent = item.name;
            document.getElementById('ictInfoDesc').textContent = item.description || 'คุณลักษณะพื้นฐานตามเกณฑ์กระทรวงดิจิทัลเพื่อเศรษฐกิจและสังคม';
            document.getElementById('ictInfoPrice').textContent = Number(item.standard_price).toLocaleString() + ' บาท';
        }
    }

    function toggleRentalBox(type) {
        const box = document.getElementById('rentalContractBox');
        if (box) {
            box.style.display = (type === 'rented') ? 'block' : 'none';
        }
    }

    function handleAcquisitionMethodChange(select) {
        const selectedOption = select.options[select.selectedIndex];
        const code = selectedOption ? selectedOption.getAttribute('data-code') : '';
        const text = selectedOption ? selectedOption.text : '';
        
        if (code === 'RENTAL' || text.includes('เช่า')) {
            const ownershipSelect = document.getElementById('ownership_type');
            if (ownershipSelect) {
                ownershipSelect.value = 'rented';
                toggleRentalBox('rented');
            }
        }
    }
</script>
@endpush
